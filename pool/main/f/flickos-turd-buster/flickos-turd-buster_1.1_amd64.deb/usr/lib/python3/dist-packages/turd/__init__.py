"""Turd Buster (flickos-turd-buster): check a Reddit draft before you post."""

__version__ = "1.1"
