from turd.cli import main

raise SystemExit(main())
