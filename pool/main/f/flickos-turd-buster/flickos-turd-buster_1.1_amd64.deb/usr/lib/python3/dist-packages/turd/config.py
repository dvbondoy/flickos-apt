"""The settings: where the check runs, the local model, the time limit, and
whether the post is signed.

Built-in defaults, then /etc/xdg/flickos/turd-buster.conf, then
~/.config/flickos/turd-buster.conf. The user file is written only when a
setting changes. Absent means the default. A file that cannot be read is
ignored.
"""

import configparser
import sys

from turd import paths

# Keys the window and `turd-buster set` share. The system conf repeats these.
DEFAULTS = {
    "provider": "opencode",  # opencode (online, through tgpt) or ollama (this computer)
    "model": "llama3.2",     # an Ollama model; used only when provider is ollama
    "timeout": "120",        # seconds one model call may take, cold-loading a local model included
    "sign_off": "no",        # yes adds "Checked by Turd Buster using …" to the post
}
PROVIDERS = ("opencode", "ollama")
TIMEOUT_RANGE = (10, 3600)
YES_NO = ("yes", "no")
SECTION = "TurdBuster"
HEADER = (
    "# Turd Buster (flickos-turd-buster) writes this file when a setting changes.\n"
    "# Change it here, in the window, or with `turd-buster set KEY VALUE|default`.\n"
    "# Delete the file to go back to the defaults.\n\n"
)


class ConfigError(Exception):
    pass


def load():
    """The settings in effect: built-in, then system, then the user file."""
    values = dict(DEFAULTS)
    for path, label in ((paths.system_config_file(), "system"), (paths.config_file(), "user")):
        parsed = _read(path, label)
        if parsed:
            values.update(parsed)
    return values


def get(key):
    if key not in DEFAULTS:
        raise ConfigError(f"Unknown setting {key}.")
    return load()[key]


def timeout():
    return int(get("timeout"))


def signs():
    return get("sign_off") == "yes"


def set_value(key, value):
    """Store one user choice. `default` removes it so the system value applies."""
    if key not in DEFAULTS:
        raise ConfigError(f"Unknown setting {key}.")
    chosen = _user_values()
    if value == "default":
        chosen.pop(key, None)
    else:
        chosen[key] = _validate(key, value)
    path = paths.config_file()
    if not chosen:
        path.unlink(missing_ok=True)
        return
    lines = [HEADER, f"[{SECTION}]\n"]
    for name in DEFAULTS:
        if name in chosen:
            lines.append(f"{name} = {chosen[name]}\n")
    paths.write_atomic(path, "".join(lines))


def _validate(key, value):
    value = str(value).strip()
    if key == "provider":
        if value not in PROVIDERS:
            raise ConfigError("Provider must be opencode or ollama.")
        return value
    if key == "timeout":
        low, high = TIMEOUT_RANGE
        if not value.isdigit() or not low <= int(value) <= high:
            raise ConfigError(f"The time limit must be {low} to {high} seconds.")
        return str(int(value))
    if key == "sign_off":
        if value not in YES_NO:
            raise ConfigError("sign_off must be yes or no.")
        return value
    if not value or any(c in value for c in "\n\r"):
        raise ConfigError("Enter a model name.")
    return value


def _user_values():
    return _read(paths.config_file(), "user") or {}


def _read(path, label):
    if path is None or not path.is_file():
        return None
    parser = configparser.ConfigParser()
    try:
        parser.read(path, encoding="utf-8")
        section = parser[SECTION]
    except (configparser.Error, KeyError, UnicodeError, OSError):
        print(f"turd-buster: ignoring unreadable {label} settings in {path}", file=sys.stderr)
        return None
    found = {}
    for key in DEFAULTS:
        if key not in section:
            continue
        try:
            found[key] = _validate(key, section[key])
        except ConfigError:
            print(f"turd-buster: ignoring {key} in {path}", file=sys.stderr)
    return found
