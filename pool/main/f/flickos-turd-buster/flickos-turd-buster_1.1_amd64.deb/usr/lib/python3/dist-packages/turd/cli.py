"""turd-buster: check a Reddit draft against a community's published rules.

The window is the whole program. Nothing runs until it is opened. The
settings are commands as well as rows in the window.

Commands:
  turd-buster                         open the window
  turd-buster check [NAME] [--json]   stdin: title, body, a --- line, then the rules
  turd-buster get [KEY]               the setting in effect (all of them without KEY)
  turd-buster set KEY VALUE|default   store one setting

Settings: provider (opencode|ollama), model (an Ollama model), timeout
(seconds, 10 to 3600), sign_off (yes|no).

`check` prints one line per rule: id, status, part, rule, reason, separated
by tabs. With --json it prints the whole result, the fixed post included.

Exit codes: 0 ok, 1 error, 2 usage error.
"""

import argparse
import json
import sys

from turd import config
from turd.checker import CheckError

KEYS = tuple(config.DEFAULTS)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="turd-buster", description="Check a Reddit draft before you post.")
    commands = parser.add_subparsers(dest="command", metavar="COMMAND")

    check_parser = commands.add_parser("check", help="check a draft read from stdin")
    check_parser.add_argument("subreddit", nargs="?", default="", help="community name, such as python")
    check_parser.add_argument("--json", action="store_true", help="print the whole result as JSON")
    check_parser.set_defaults(func=cmd_check)

    get_parser = commands.add_parser("get", help="print a setting")
    get_parser.add_argument("key", nargs="?", choices=KEYS)
    get_parser.set_defaults(func=cmd_get)

    set_parser = commands.add_parser("set", help="change a setting")
    set_parser.add_argument("key", choices=KEYS)
    set_parser.add_argument("value", help="opencode, ollama, a model name, seconds, yes, no, or default")
    set_parser.set_defaults(func=cmd_set)

    opts = parser.parse_args(argv)
    if opts.command is None:
        from turd.window import run

        return run()
    try:
        return opts.func(opts)
    except (CheckError, config.ConfigError) as e:
        print(f"turd-buster: {e}", file=sys.stderr)
        return 1


def cmd_check(opts):
    from turd.checker import check

    title, body, rules = _draft(sys.stdin.read())
    result = check(opts.subreddit, title, body, rules)
    if opts.json:
        json.dump(_public(result), sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
        return 0
    for row in result["rows"]:
        fields = (row["id"], row["status"], row["part"] or "-", row["title"], row["reason"])
        print("\t".join(" ".join(field.split()) for field in fields))
    if result["fix_error"]:
        print(f"turd-buster: {result['fix_error']}", file=sys.stderr)
    return 0


def _public(result):
    return {
        "subreddit": result["community"]["name"],
        "summary": result["summary"],
        "provider": result["provider"],
        "model": result["model"] if result["provider"] == "ollama" else None,
        "verdicts": [
            {key: row[key] for key in ("id", "title", "status", "part", "reason")} for row in result["rows"]
        ],
        "sign_off": result["sign_off"] or None,
        "fixed": result["fixed"],
        "fix_error": result["fix_error"] or None,
    }


def cmd_get(opts):
    if opts.key:
        print(config.get(opts.key))
        return 0
    values = config.load()
    for key in KEYS:
        print(f"{key}\t{values[key]}")
    return 0


def cmd_set(opts):
    config.set_value(opts.key, opts.value)
    return 0


def _draft(text):
    """Title, then the body, then a line of ---, then the pasted rules."""
    draft, sep, rules = text.partition("\n---\n")
    if not sep:
        rules = ""
    title, line, body = draft.partition("\n")
    if not line:
        body = ""
    return title.strip(), body, rules
