# Turd Buster (flickos-turd-buster)

A FlickOS app that checks a Reddit draft against a community's published
rules before you post. Posting stays in the browser. It is free software,
GPL-3.0-or-later (`LICENSE`).

It is not part of the FlickOS desktop: `flickos-desktop` does not depend
on it or recommend it, and the image does not include it, so it lives here
and not under FlickOS's `packages/`. It is published in FlickOS's apt
repository, and people install it themselves:

```sh
sudo apt update && sudo apt install flickos-turd-buster
```

The window follows the GTK theme already in use, Arc-Dark or Arc. It does
not ship a theme of its own.

## What is where

- `src/turd/`: the program. `cli.py` is the command. `checker.py` runs a
  check, `models.py` calls the model, `window.py` is the window (GTK 3),
  loaded by nothing else.
- `third_party/tgpt/`: the pinned tgpt release the package includes, its
  `SHA256SUMS` and its license. `tools/fetch-tgpt` downloads the binary and
  its source; only `SHA256SUMS` and `LICENSE` are in git.
- `usr/share/applications/flickos-turd-buster.desktop`: Turd Buster in the
  apps menu.
- `etc/xdg/flickos/turd-buster.conf`: the defaults. An account's own
  choices are `~/.config/flickos/turd-buster.conf`.
- `tests/`: pytest. Every XDG folder points into a temporary folder, tgpt
  and Ollama are fakes, and there is no display and no network.

## What runs

Installing the package runs nothing and downloads nothing. It puts tgpt
2.15.0, as released upstream, in `/usr/libexec/flickos/turd-buster/`, and
its source next to the docs. Nothing runs until you open Turd Buster.

You paste the community's rules, including any rules about the title, and
Check sends the draft and the rules, as one JSON object, to the model:

- **Online** (default): through the bundled tgpt (`-q`, no tools) to
  OpenCode. The window says the draft is sent.
  The bundled tgpt is kept apart from any tgpt the user installed: it is
  not on PATH, runs with `--config /dev/null`, and gets only the locale,
  proxy and certificate variables, so a user's `~/.config/tgpt/config.conf`,
  `AI_API_KEY` or `OPENCODE_URL` never reaches it.
- **On this computer**: straight to Ollama's API at `OLLAMA_HOST`
  (`127.0.0.1:11434` unless set), held to a JSON schema. Ollama itself is
  not a Debian package; install it from ollama.com and `ollama pull` a
  model.

When a rule fails, the model writes a fixed post, and that post is checked
again, at most twice. A fixed post that passes every rule is offered as
the **Fixed post**; Copy and Post then use it, never the draft. When none
passes, the one that breaks the fewest rules is shown as a **Suggested
fix**, with the rules it still breaks: edit it, or press Use as Draft and
check again. Copy and Post stay off for it. A failing title is replaced.
Editing the draft after a check clears the result.

With the checked-by setting on, a post that passes ends with one line such
as "Checked by Turd Buster using OpenCode." The line is part of what is
checked, so a rule against it fails like any other. It is off by default.

Post opens Reddit's submit page in the browser, and nothing is posted until
you submit it there.

## Commands

```text
turd-buster                          open the window
turd-buster check [NAME] [--json]    stdin: title, body, a --- line, then the rules
turd-buster get [KEY]
turd-buster set provider ollama|opencode|default
turd-buster set model NAME|default
turd-buster set timeout SECONDS|default      10 to 3600, per model call
turd-buster set sign_off yes|no|default
```

`check` prints one tab-separated line per rule (id, status, part, rule,
reason). `--json` prints the whole result, the fixed post included.

## Build and test

```sh
python3 -m pytest -q
tools/fetch-tgpt            # once: the pinned tgpt and its source, checked
# the package, built in a copy so no build output lands here:
rm -rf /tmp/ft && rsync -a --exclude .git ./ /tmp/ft/ && (cd /tmp/ft && dpkg-buildpackage -us -uc -b)
lintian /tmp/flickos-turd-buster_*.deb
```

## Publish

From the FlickOS folder, after building (bump the version first; reprepro
refuses a changed file under a version it already has):

```sh
reprepro -b repo includedeb trixie /tmp/flickos-turd-buster_VERSION_amd64.deb
repo/upload.sh
```

This adds only this package to the repository. It does not go into the
ISO or into `flickos-desktop`.

The build stops when the tgpt files do not match `third_party/tgpt/SHA256SUMS`.
To move to a newer tgpt, change `VERSION` in `tools/fetch-tgpt` and
`TGPT_VERSION` in `debian/rules`, fetch, try it, and replace `SHA256SUMS`.
