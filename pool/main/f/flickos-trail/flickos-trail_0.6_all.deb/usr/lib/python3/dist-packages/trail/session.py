"""Trail in the desktop session: the switch, the clipboard watcher, the panel
button's signal and the daily prune (flickos-trail ADR-004 to ADR-006).

Nothing of Trail runs in the background except wl-clipboard's watcher, which
`trail clipboard` (autostart) becomes. Everything else runs when the user
does something and ends.
"""

import os
import shutil
import signal
import subprocess
import sys

from trail import config, paths, state

PROC = "/proc"
# The panel button's waybar signal: SIGRTMIN+11 (tiler 8, phone 9, recording 10).
PANEL_SIGNAL = 11
FLICKOS_LAYOUT = "flickos-layout"
WATCHER = ["wl-paste", "--type", "text", "--watch"]  # then the trail command, "ingest", "clip"
ADDON_README = "README"
ADDON_README_TEXT = """\
This empty folder hides Trail's keys and panel button while Trail is off.
`trail set enabled yes` turns it on again and deletes this folder.
"""


def in_session() -> bool:
    return bool(os.environ.get("WAYLAND_DISPLAY"))


def trail_command() -> list[str]:
    """How to run trail again: the installed command, else this Python."""
    found = shutil.which("trail")
    return [found] if found else [sys.executable, "-m", "trail"]


def _spawn(argv: list[str], nice: bool = False) -> None:
    """Start a detached child (its own session) and don't wait for it."""
    subprocess.Popen(
        argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        start_new_session=True, preexec_fn=(lambda: os.nice(19)) if nice else None,
    )


# --- the panel button --------------------------------------------------------------

def _own_process(pid: str) -> bool:
    try:
        return os.stat(os.path.join(PROC, pid)).st_uid == os.getuid()
    except OSError:
        return False


def signal_panel() -> None:
    """Make the user's waybars run `trail status --panel` again. A waybar
    without the button ignores the signal. PIDs from /proc, never pkill."""
    if not in_session():
        return
    try:
        entries = os.listdir(PROC)
    except OSError:
        return
    for pid in entries:
        if not pid.isdigit():
            continue
        try:
            with open(os.path.join(PROC, pid, "comm")) as f:
                if f.read().strip() != "waybar":
                    continue
        except OSError:
            continue
        if _own_process(pid):
            try:
                os.kill(int(pid), signal.SIGRTMIN + PANEL_SIGNAL)
            except OSError:
                pass


# --- the clipboard watcher -----------------------------------------------------------

def is_watcher(pid: int) -> bool:
    """True if `pid` is one of the user's `wl-paste --watch … ingest clip`."""
    try:
        with open(os.path.join(PROC, str(pid), "cmdline"), "rb") as f:
            argv = [a.decode(errors="replace") for a in f.read().split(b"\0") if a]
    except OSError:
        return False
    return (
        bool(argv) and os.path.basename(argv[0]) == "wl-paste" and "--watch" in argv
        and argv[-2:] == ["ingest", "clip"] and _own_process(str(pid))
    )


def watcher_pid() -> int | None:
    try:
        pid = int((paths.runtime_dir() / state.CLIPBOARD_PID).read_text())
    except (OSError, ValueError):
        return None
    return pid if is_watcher(pid) else None


def _mark(path, present: bool) -> None:
    if present:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch()
    else:
        path.unlink(missing_ok=True)


def sync(cfg: config.Config) -> bool:
    """Make trail.off, trail-shell.off and the add-on folder follow the
    settings, also for a trail.toml changed by hand. Returns True if the
    add-on folder changed (the keys and the panel need regenerating)."""
    _mark(paths.shell_off_file(), not (cfg.enabled and cfg.sources.shell))
    off = paths.off_file()
    if cfg.enabled == (not off.exists()):
        return False
    _mark(off, not cfg.enabled)
    if cfg.enabled:
        show_addon()
    else:
        hide_addon()
    return True


def run_clipboard() -> int:
    """`trail clipboard`, from autostart: become the clipboard watcher while
    Trail and its clipboard source are on, else end at once."""
    cfg = config.load()
    if sync(cfg):
        apply_desktop()
    if not cfg.enabled or not cfg.sources.clipboard:
        return 0
    if watcher_pid() is not None:
        return 0
    if not in_session():
        print("trail: not in a Wayland session, so the clipboard isn't recorded", file=sys.stderr)
        return 1
    # exec keeps the PID, so this is the watcher's.
    pid_file = paths.ensure_private_dir(paths.runtime_dir()) / state.CLIPBOARD_PID
    tmp = pid_file.with_name(f".{state.CLIPBOARD_PID}.{os.getpid()}")
    tmp.write_text(f"{os.getpid()}\n")
    os.replace(tmp, pid_file)
    signal_panel()
    argv = WATCHER + trail_command() + ["ingest", "clip"]
    os.execvp(argv[0], argv)


def start_clipboard() -> None:
    if in_session() and watcher_pid() is None:
        _spawn(trail_command() + ["clipboard"])


def stop_clipboard() -> None:
    if (pid := watcher_pid()) is not None:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    (paths.runtime_dir() / state.CLIPBOARD_PID).unlink(missing_ok=True)


# --- the switch ---------------------------------------------------------------------------

def _addon_override_is_ours() -> bool:
    """The user's flickos-trail add-on folder holds nothing but our README (or
    is missing), so Trail may create or delete it."""
    try:
        return set(os.listdir(paths.addon_override())) <= {ADDON_README}
    except FileNotFoundError:
        return True
    except OSError:
        return False


def hide_addon() -> str | None:
    """Hide the system add-on with an empty folder of the same name. Returns a
    warning when the user has an add-on folder of their own there."""
    folder = paths.addon_override()
    if not _addon_override_is_ours():
        return f"{folder} has your own add-on files, so Trail's keys stay"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / ADDON_README).write_text(ADDON_README_TEXT)
    return None


def show_addon() -> None:
    folder = paths.addon_override()
    if folder.is_dir() and _addon_override_is_ours():
        (folder / ADDON_README).unlink(missing_ok=True)
        folder.rmdir()


def apply_desktop() -> None:
    """Regenerate the keys and the panel (they come from the add-on folder)."""
    if not in_session() or not shutil.which(FLICKOS_LAYOUT):
        return
    for command in ("reconfigure", "reload-panel"):
        subprocess.run([FLICKOS_LAYOUT, command], stdin=subprocess.DEVNULL,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)


def change(name: str, value) -> tuple[config.Config, list[str]]:
    """`trail set NAME VALUE|default` (None): save it, then bring the rest in
    step: the switch files, the add-on, the clipboard watcher, the panel.
    Returns (the settings now, warnings)."""
    config.save(name, value)
    cfg = config.load()
    warnings = []
    if sync(cfg) or name == "enabled":
        if not cfg.enabled and not _addon_override_is_ours():
            warnings.append(f"{paths.addon_override()} has your own add-on files, so Trail's keys stay")
        apply_desktop()
    if cfg.enabled and cfg.sources.clipboard:
        start_clipboard()
    else:
        stop_clipboard()
    signal_panel()
    return cfg, warnings


def set_enabled(value: bool | None) -> tuple[bool, list[str]]:
    cfg, warnings = change("enabled", value)
    return cfg.enabled, warnings


# --- retention -------------------------------------------------------------------------

def maybe_prune() -> None:
    """The first ingest, search or pick of the day starts `trail prune` in a
    detached child at low priority, so nothing waits for it (ADR-006)."""
    try:
        due = state.prune_due()
    except OSError:
        return
    if due:
        try:
            _spawn(trail_command() + ["prune"], nice=True)
        except OSError:
            pass


# --- what the settings window shows ----------------------------------------------------

def bashrc_state(bashrc=None) -> str:
    """"ok" when ~/.bashrc sources the hook, "old" for trail 0.3's line, else "missing"."""
    from pathlib import Path

    bashrc = bashrc or Path.home() / ".bashrc"
    try:
        text = bashrc.read_text(errors="replace")
    except OSError:
        text = ""
    if str(paths.INSTALLED_HOOK) in text:
        return "ok"
    return "old" if OLD_HOOK in text else "missing"


OLD_HOOK = "/usr/share/trail/trail.bash"  # trail 0.3's


def history_size() -> tuple[int, int]:
    """(events, bytes on disk: the database and the archive)."""
    import sqlite3

    path = paths.db_file()
    count = 0
    if path.exists():
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            try:
                count = conn.execute("SELECT count(*) FROM events").fetchone()[0]
            finally:
                conn.close()
        except sqlite3.Error:
            pass
    size = 0
    for p in [path, path.with_name(path.name + "-wal"), *(paths.data_dir() / "archive").glob("*")]:
        try:
            size += p.stat().st_size
        except OSError:
            pass
    return count, size


def window_state() -> dict:
    """`trail state`: everything the settings window shows, in one run."""
    from trail import __version__, status

    cfg = config.load()
    st = status.current()
    events, size = history_size()
    builtin = config.CaptureConfig()
    return {
        "version": __version__,
        "status": st.state,
        "error": st.error,
        "paused": state.is_paused(),
        "settings": {name: config.get(cfg, name) for name, (_t, _k, kind) in config.SETTABLE.items() if kind is not list},
        "blocked": {
            "apps": config.get(cfg, "capture.blocked_apps"),
            "titles": config.get(cfg, "capture.blocked_titles"),
            "builtin_apps": list(builtin.blocked_apps),
            "builtin_titles": list(builtin.blocked_titles),
        },
        "hook": {"state": bashrc_state(), "line": paths.bashrc_line()},
        "history": {"events": events, "bytes": size, "archive": str(paths.data_dir() / "archive")},
        "clipboard_running": watcher_pid() is not None,
        "in_session": in_session(),
    }
