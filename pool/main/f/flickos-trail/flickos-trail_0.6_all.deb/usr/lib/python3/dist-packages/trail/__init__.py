"""Trail (flickos-trail): a searchable memory of what you did, for FlickOS."""

__version__ = "0.6"
