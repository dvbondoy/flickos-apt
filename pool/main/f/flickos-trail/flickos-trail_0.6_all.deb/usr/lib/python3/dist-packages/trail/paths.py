"""XDG locations, in FlickOS's places (flickos-trail ADR-002). Read from the
environment on every call so tests can override them."""

import os
from pathlib import Path

APP = "trail"
VENDOR = "flickos"


def _xdg(var: str, fallback: str) -> Path:
    value = os.environ.get(var)
    # The XDG spec says relative paths must be ignored.
    if value and os.path.isabs(value):
        return Path(value)
    return Path.home() / fallback


def config_dir() -> Path:
    """~/.config/flickos: trail.toml, trail.off and the add-on folder are here."""
    return _xdg("XDG_CONFIG_HOME", ".config") / VENDOR


def config_file() -> Path:
    return config_dir() / f"{APP}.toml"


def off_file() -> Path:
    """Exists exactly while Trail is turned off. The bash hook tests it, since
    bash can't read TOML cheaply (ADR-004)."""
    return config_dir() / f"{APP}.off"


def shell_off_file() -> Path:
    """Exists while terminal commands aren't recorded: Trail is off or
    sources.shell is. The bash hook's one file test per command."""
    return config_dir() / f"{APP}-shell.off"


def addon_override() -> Path:
    """The user's add-on folder of the same name, which hides the system one
    while Trail is off (ADR-005)."""
    return config_dir() / "addons" / "flickos-trail"


def data_dir() -> Path:
    return _xdg("XDG_DATA_HOME", ".local/share") / VENDOR / APP


def db_file() -> Path:
    override = os.environ.get("TRAIL_DB")
    return Path(override) if override else data_dir() / "trail.db"


def state_dir() -> Path:
    """The first-login marker and the date of the last prune."""
    return _xdg("XDG_STATE_HOME", ".local/state") / VENDOR / APP


def runtime_dir() -> Path:
    base = os.environ.get("XDG_RUNTIME_DIR")
    if base and os.path.isabs(base):
        return Path(base) / VENDOR / APP
    return Path(f"/tmp/{VENDOR}-{APP}-{os.getuid()}")


# trail 0.3's places, moved once by migrate().
def old_config_file() -> Path:
    return _xdg("XDG_CONFIG_HOME", ".config") / APP / "config.toml"


def old_data_dir() -> Path:
    return _xdg("XDG_DATA_HOME", ".local/share") / APP


def ensure_private_dir(path: Path) -> Path:
    """Create `path` (and parents) and make sure only the owner can enter it."""
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.stat().st_mode & 0o077:
        path.chmod(0o700)
    return path


def migrate() -> list[str]:
    """Move trail 0.3's database and settings to the new places, once: only
    while the new ones don't exist yet. A rename, so the database is never
    copied. Returns what was moved, for the one notice."""
    moved = []
    old, new = old_data_dir(), data_dir()
    if old.is_dir() and not new.exists() and "TRAIL_DB" not in os.environ:
        new.parent.mkdir(parents=True, exist_ok=True)
        os.rename(old, new)
        moved.append(f"{old} → {new}")
    old_cfg, new_cfg = old_config_file(), config_file()
    if old_cfg.is_file() and not new_cfg.exists():
        new_cfg.parent.mkdir(parents=True, exist_ok=True)
        os.rename(old_cfg, new_cfg)
        moved.append(f"{old_cfg} → {new_cfg}")
        try:
            old_cfg.parent.rmdir()
        except OSError:
            pass  # something else is in it; leave it
    return moved


# The bash hook (ADR-002): installed, or next to the source tree.
INSTALLED_HOOK = Path("/usr/share/flickos/trail/trail.bash")
HOOK_LOCATIONS = (
    Path(__file__).resolve().parents[2] / "usr" / "share" / "flickos" / "trail" / "trail.bash",
    INSTALLED_HOOK,
)


def hook_path() -> Path | None:
    return next((p for p in HOOK_LOCATIONS if p.exists()), None)


def bashrc_line(hook: Path = INSTALLED_HOOK) -> str:
    """The line ~/.bashrc needs. It tests -r first, so it does nothing once
    flickos-trail is removed."""
    return f"[[ -r {hook} ]] && source {hook}"
