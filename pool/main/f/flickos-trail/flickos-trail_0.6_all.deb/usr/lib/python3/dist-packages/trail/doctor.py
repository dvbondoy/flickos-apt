"""`trail doctor`: check the computer has what Trail needs, and how it is set up."""

import os
import re
import shutil
import sqlite3
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from trail import config, db, paths, session

OK, WARN, FAIL = "ok", "warn", "fail"


@dataclass
class Check:
    section: str
    name: str
    status: str
    detail: str = ""
    hint: str = ""


def _run(*argv: str) -> str | None:
    """Run a command and return stdout+stderr, or None if it can't be run."""
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=3)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return (p.stdout + p.stderr).strip()


def _first_line(s: str | None) -> str:
    return s.splitlines()[0].strip() if s else ""


# --- core ---------------------------------------------------------------------


def check_core() -> list[Check]:
    s = "core"
    out = []
    v = sys.version_info
    out.append(
        Check(s, "python", OK if v >= (3, 13) else FAIL, f"{v.major}.{v.minor}.{v.micro}", "trail needs Python 3.13+")
    )
    fts = db.fts5_available()
    out.append(
        Check(s, "sqlite", OK if fts else FAIL, f"{sqlite3.sqlite_version}" + (" (FTS5)" if fts else " (no FTS5)"))
    )

    cfg_path = paths.config_file()
    if not cfg_path.exists():
        out.append(Check(s, "config", OK, "defaults (no config file)", "optional: trail config init"))
    else:
        try:
            config.load(cfg_path)
            out.append(Check(s, "config", OK, str(cfg_path)))
        except config.ConfigError as e:
            out.append(Check(s, "config", FAIL, str(e)))

    out.append(check_database(paths.db_file()))

    rt = os.environ.get("XDG_RUNTIME_DIR")
    out.append(
        Check(s, "runtime dir", OK if rt else WARN, str(paths.runtime_dir()), "" if rt else "XDG_RUNTIME_DIR is not set")
    )
    return out


def check_database(path: Path) -> Check:
    s = "core"
    if not path.exists():
        return Check(s, "database", WARN, f"{path} (not created yet)", "run: trail db init")
    problems = []
    for p in (path.parent, path):
        mode = p.stat().st_mode & 0o777
        want = 0o700 if p.is_dir() else 0o600
        if mode & 0o077:
            problems.append(f"{p} is {oct(mode)}, should be {oct(want)}")
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            version = db.schema_version(conn)
            journal = conn.execute("PRAGMA journal_mode").fetchone()[0]
            auto_vacuum = conn.execute("PRAGMA auto_vacuum").fetchone()[0]
            count = conn.execute("SELECT count(*) FROM events").fetchone()[0] if version else 0
        finally:
            conn.close()
    except sqlite3.Error as e:
        return Check(s, "database", FAIL, f"{path}: {e}")
    if version < db.SCHEMA_VERSION:
        problems.append(f"schema v{version}, current is v{db.SCHEMA_VERSION} (run: trail db init)")
    if version > db.SCHEMA_VERSION:
        problems.append(f"schema v{version} is newer than this trail (v{db.SCHEMA_VERSION})")
    if journal != "wal":
        problems.append(f"journal mode is {journal}, expected wal")
    if auto_vacuum != db.AUTO_VACUUM_INCREMENTAL:
        problems.append("auto_vacuum is not incremental (run: trail db init)")
    detail = f"{path} (schema v{version}, {count} events)"
    if problems:
        return Check(s, "database", FAIL, detail, "; ".join(problems))
    return Check(s, "database", OK, detail)


# --- session ------------------------------------------------------------------


def check_session() -> list[Check]:
    s = "session"
    out = []
    wd = os.environ.get("WAYLAND_DISPLAY")
    out.append(Check(s, "wayland", OK if wd else FAIL, wd or "WAYLAND_DISPLAY not set", "" if wd else "run inside the labwc session"))
    desk = os.environ.get("XDG_CURRENT_DESKTOP", "")
    out.append(
        Check(s, "compositor", OK if "labwc" in desk.lower() else WARN, desk or "unknown", "" if "labwc" in desk.lower() else "trail is built for labwc")
    )
    out.extend(check_protocols())
    return out


# Protocol -> (what needs it, alternatives that also satisfy it)
PROTOCOLS = {
    "zwlr_screencopy_manager_v1": ("screenshots (grim)", ("ext_image_copy_capture_manager_v1",)),
    "zwlr_data_control_manager_v1": ("clipboard (wl-paste --watch)", ("ext_data_control_manager_v1",)),
    "zwlr_foreign_toplevel_manager_v1": ("focused window", ()),
    "zwlr_layer_shell_v1": ("fuzzel popup and waybar", ()),
}


def wayland_globals() -> set[str] | None:
    out = _run("wayland-info")
    if out is None:
        return None
    return set(re.findall(r"interface: '([a-z0-9_]+)'", out))


def check_protocols(globals_: set[str] | None = ...) -> list[Check]:
    s = "session"
    if globals_ is ...:
        globals_ = wayland_globals()
    if globals_ is None:
        return [Check(s, "protocols", WARN, "can't check: wayland-info not found", "sudo apt install wayland-utils")]
    out = []
    for proto, (purpose, alternatives) in PROTOCOLS.items():
        have = proto in globals_ or any(a in globals_ for a in alternatives)
        out.append(Check(s, proto, OK if have else FAIL, purpose, "" if have else "the compositor doesn't offer this protocol"))
    return out


# --- tools --------------------------------------------------------------------

# name, apt package, needed (False: only `trail search --fzf` uses it)
TOOLS = [
    ("wl-paste", "wl-clipboard", True),
    ("wl-copy", "wl-clipboard", True),
    ("fuzzel", "fuzzel", True),
    ("notify-send", "libnotify-bin", True),
    ("xdg-open", "xdg-utils", True),
    ("grim", "grim", True),
    ("slurp", "slurp", True),
    ("tesseract", "tesseract-ocr", True),
    ("fzf", "fzf", False),
]

BASH_PREEXEC_LOCATIONS = (
    Path.home() / ".bash-preexec.sh",
    Path("/usr/share/flickos/trail/bash-preexec.sh"),  # bundled by the .deb
)


def check_tools() -> list[Check]:
    out = []
    for name, package, needed in TOOLS:
        if not shutil.which(name):
            out.append(Check("tools", name, FAIL if needed else WARN, "not found", f"sudo apt install {package}"))
            continue
        extra = {"fuzzel": check_fuzzel, "tesseract": check_tesseract}.get(name)
        out.append(extra() if extra else Check("tools", name, OK, shutil.which(name) or ""))

    out.append(check_pillow())
    out.append(check_focus())

    found = next((p for p in BASH_PREEXEC_LOCATIONS if p.exists()), None)
    out.append(
        Check(
            "tools",
            "bash-preexec",
            OK if found else FAIL,
            str(found) if found else "not found",
            "" if found else "reinstall flickos-trail",
        )
    )
    return out


def check_fuzzel() -> Check:
    version = _first_line(_run("fuzzel", "--version"))
    help_text = _run("fuzzel", "--help") or ""
    missing = [flag for flag in ("--prompt-only", "--index") if flag not in help_text]
    if missing:
        return Check("tools", "fuzzel", FAIL, version, f"missing {', '.join(missing)}, which trail pick needs: install a newer fuzzel")
    return Check("tools", "fuzzel", OK, version)


def check_pillow() -> Check:
    try:
        import PIL
    except ImportError:
        return Check("tools", "pillow", FAIL, "not importable", "sudo apt install python3-pil")
    return Check("tools", "pillow", OK, PIL.__version__)


def check_focus() -> Check:
    """trail's own Wayland client (ADR-016) can see the windows and which has focus."""
    from trail import focus

    try:
        tracker = focus.connect()
    except (focus.WaylandError, OSError) as e:
        return Check("session", "focus tracking", FAIL, str(e), "run inside the labwc session")
    w, n = tracker.focused, len(tracker.windows())
    tracker.close()
    return Check("session", "focus tracking", OK, f"{n} windows; focused: {w.app_id if w else 'none'}")


def check_tesseract() -> Check:
    version = _first_line(_run("tesseract", "--version"))
    langs = (_run("tesseract", "--list-langs") or "").splitlines()[1:]
    if "eng" not in [l.strip() for l in langs]:
        return Check("tools", "tesseract", FAIL, version, "no English language data: sudo apt install tesseract-ocr-eng")
    return Check("tools", "tesseract", OK, f"{version} ({', '.join(l.strip() for l in langs)})")


# --- per-user setup ------------------------------------------------------------

def check_hook(bashrc: Path | None = None) -> Check:
    bashrc = bashrc or Path.home() / ".bashrc"
    line = paths.bashrc_line()
    found = session.bashrc_state(bashrc)
    if found == "ok":
        return Check("setup", "shell hook", OK, f"sourced in {bashrc}")
    if found == "old":
        return Check("setup", "shell hook", WARN, f"{bashrc} has trail 0.3's line, which does nothing now",
                     f"replace it with: {line}")
    return Check("setup", "shell hook", WARN, "not in ~/.bashrc, so commands aren't recorded",
                 f"add to the end of ~/.bashrc: {line}")


def check_switch(cfg: config.Config | None = None) -> list[Check]:
    s = "setup"
    try:
        cfg = cfg or config.load()
    except config.ConfigError:
        return []  # check_core reports it
    out = [Check(s, "enabled", OK if cfg.enabled else WARN, "on" if cfg.enabled else "off",
                 "" if cfg.enabled else "trail set enabled yes")]
    if cfg.enabled == paths.off_file().exists() or (cfg.enabled and cfg.sources.shell) == paths.shell_off_file().exists():
        out.append(Check(s, "switch files", WARN, "trail.off or trail-shell.off doesn't match trail.toml",
                         "log out and in, or: trail set enabled default"))
    if cfg.enabled and not cfg.sources.shell:
        out.append(Check(s, "terminal commands", OK, "off (sources.shell)"))
    if cfg.enabled and cfg.sources.clipboard:
        pid = session.watcher_pid()
        if pid:
            out.append(Check(s, "clipboard", OK, f"recording (wl-paste, PID {pid})"))
        elif session.in_session():
            out.append(Check(s, "clipboard", FAIL, "recording stopped", "run: trail clipboard"))
        else:
            out.append(Check(s, "clipboard", WARN, "not in a desktop session"))
    elif cfg.enabled:
        out.append(Check(s, "clipboard", OK, "off (sources.clipboard)"))
    for old, what in ((paths.config_dir() / "addons" / "trail", "trail 0.3's experimental add-on"),
                      (Path.home() / ".config" / "autostart" / "trail.desktop", "trail 0.3's autostart entry")):
        if old.exists():
            out.append(Check(s, "trail 0.3", WARN, f"{old} is still there ({what})",
                             f"sh experimental/trail/setup.sh remove, or delete {old}"))
    return out


def run_all() -> list[Check]:
    return check_core() + check_session() + check_tools() + [check_hook()] + check_switch()
