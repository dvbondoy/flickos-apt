"""Trail's settings window: `trail settings`, *Trail* in the apps menu
(flickos-trail phase 2).

It owns no settings: every control runs a `trail` command (HIG SET-2), and
the window reads everything back with one `trail state`, in a thread, when
it opens and after each change (WIN-11). GTK is imported only here, so the
commands the shell hook and the clipboard watcher run never load it.
"""

import fcntl
import json
import os
import subprocess
import sys
import threading

from trail import paths, session

TITLE = "Trail"
APP_ID = "flickos-trail"  # the desktop file's name, so the panel shows its icon
SIZE = (620, 640)  # HIG WIN-3: at most 1280×680
LOCK = "window.lock"

# HIG WIN-7: named values, not a spin button. 0 is "Forever".
RETENTION_CHOICES = [(30, "1 month"), (90, "3 months"), (182, "6 months"), (365, "1 year"),
                     (730, "2 years"), (0, "Forever")]
ARCHIVE_CHOICES = [(12, "1 year"), (24, "2 years"), (60, "5 years"), (0, "Forever")]
RETENTION_ROWS = [
    ("retention.shell", "Terminal commands"),
    ("retention.clip", "Copied text"),
    ("retention.screen", "Screen text"),
    ("retention.mark", "Marks"),
]


# --- what the window shows, without GTK (tested) -----------------------------------

def choices(options: list[tuple[int, str]], current: int, unit: str = "days") -> list[tuple[int, str]]:
    """The named values, plus the current one when it isn't among them (set
    with `trail set` or by hand)."""
    if any(value == current for value, _ in options):
        return options
    label = f"1 {unit[:-1]}" if current == 1 else f"{current} {unit}"
    return sorted(options + [(current, label)], key=lambda c: (c[0] == 0, c[0]))


def size_text(size: int) -> str:
    for unit in ("bytes", "KB", "MB", "GB"):
        if size < 1000 or unit == "GB":
            return f"{size} {unit}" if unit == "bytes" else f"{size:.1f} {unit}"
        size /= 1000
    return ""


def history_text(events: int) -> str:
    return "1 entry" if events == 1 else f"{events:,} entries"


def hook_message(hook: dict) -> str | None:
    """The warning about ~/.bashrc, or None when the line is there."""
    if hook["state"] == "ok":
        return None
    if hook["state"] == "old":
        return "~/.bashrc still has trail 0.3's line, so terminal commands aren't recorded. Replace it with this one:"
    return "Terminal commands are recorded only once this line is at the end of ~/.bashrc:"


def run_trail(*argv: str) -> tuple[bool, str]:
    """Run a trail command: (ok, its message)."""
    try:
        r = subprocess.run(session.trail_command() + list(argv), stdin=subprocess.DEVNULL,
                           capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, str(e)
    message = (r.stderr.strip() or r.stdout.strip()) if r.returncode else r.stdout.strip()
    return r.returncode == 0, message.removeprefix("trail: ")


def open_app_ids() -> list[str]:
    """The app IDs of the open windows, for the blocked list's suggestions."""
    from trail import focus

    try:
        tracker = focus.connect()
    except (focus.WaylandError, OSError):
        return []
    try:
        return sorted({w.app_id for w in tracker.windows() if w.app_id and w.app_id != APP_ID})
    finally:
        tracker.close()


# --- one window per session (HIG WIN-2) ---------------------------------------------

def take_lock():
    """The open lock file, or None while another Trail window holds it."""
    folder = paths.ensure_private_dir(paths.runtime_dir())
    f = open(folder / LOCK, "a")
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        f.close()
        return None
    return f


def run() -> int:
    lock = take_lock()
    if lock is None:
        print(f"{TITLE} is already open.")
        return 0
    try:
        import gi

        gi.require_version("Gtk", "3.0")
        from gi.repository import GLib

        GLib.set_prgname(APP_ID)
        from gi.repository import Gtk
    except (ImportError, ValueError) as e:
        print(f"trail: GTK 3 is not available ({e})", file=sys.stderr)
        return 1
    if not Gtk.init_check(sys.argv[:1])[0]:
        print("trail: cannot open a window (no display)", file=sys.stderr)
        return 1
    Window(Gtk, GLib).window.show_all()
    Gtk.main()
    lock.close()
    return 0


# --- the window ---------------------------------------------------------------------

class Window:
    def __init__(self, Gtk, GLib):
        self.Gtk, self.GLib = Gtk, GLib
        self.state = None
        self.updating = False  # True while apply_state sets controls: their signals are not the user's
        self.generation = 0  # newest `trail state` wins

        w = self.window = Gtk.Window(title=TITLE)
        w.set_default_size(*SIZE)
        w.set_icon_name("document-open-recent")
        w.connect("destroy", Gtk.main_quit)
        accel = Gtk.AccelGroup()
        accel.connect(*Gtk.accelerator_parse("<Control>w"), 0, lambda *a: w.close() or True)
        w.add_accel_group(accel)

        self.stack = Gtk.Stack()
        w.add(self.stack)
        loading = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, valign=Gtk.Align.CENTER)
        self.spinner = Gtk.Spinner()
        self.spinner.start()
        loading.add(self.spinner)
        loading.add(Gtk.Label(label="Loading…"))
        self.stack.add_named(loading, "loading")

        scroll = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        self.stack.add_named(scroll, "page")
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18, margin=24)
        scroll.add(page)
        self.build(page)
        self.load()

    # pieces (HIG WIN-5, WIN-6)

    def label(self, text, dim=False, selectable=False, bold=False):
        Gtk = self.Gtk
        lab = Gtk.Label(label=text, xalign=0, wrap=True, max_width_chars=60, selectable=selectable)
        if dim:
            lab.get_style_context().add_class("dim-label")
        if bold:
            lab.set_markup(f"<b>{self.GLib.markup_escape_text(text)}</b>")
        return lab

    def group(self, page, heading):
        Gtk = self.Gtk
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.add(self.label(heading, bold=True))
        frame = Gtk.Frame()
        listbox = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        frame.add(listbox)
        box.add(frame)
        page.add(box)
        return listbox

    def row(self, listbox, title, subtitle=None, control=None):
        Gtk = self.Gtk
        row = Gtk.ListBoxRow(activatable=False)
        box = Gtk.Box(spacing=12, margin=10)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, hexpand=True, valign=Gtk.Align.CENTER)
        row.title = self.label(title)
        texts.add(row.title)
        row.subtitle = self.label(subtitle or "", dim=True)
        row.subtitle.set_no_show_all(not subtitle)
        row.subtitle_text = subtitle
        texts.add(row.subtitle)
        box.add(texts)
        if control is not None:
            control.set_valign(Gtk.Align.CENTER)
            if isinstance(control, (Gtk.Switch, Gtk.ComboBox)):
                control.get_accessible().set_name(title)  # HIG A11Y-8: named by its row
            box.add(control)
        row.add(box)
        listbox.add(row)
        return row

    def switch_row(self, listbox, title, subtitle, on_change):
        switch = self.Gtk.Switch()
        row = self.row(listbox, title, subtitle, switch)
        switch.connect("notify::active", lambda s, _p: self.updating or on_change(row, s.get_active()))
        row.control = switch
        return row

    def combo_row(self, listbox, title, on_change):
        combo = self.Gtk.ComboBoxText()
        row = self.row(listbox, title, None, combo)
        combo.connect("changed", lambda c: self.updating or on_change(row, int(c.get_active_id())))
        row.control = combo
        return row

    def notice_bar(self, page, kind):
        Gtk = self.Gtk
        bar = Gtk.InfoBar(message_type=kind, no_show_all=True)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        bar.text = self.label("", selectable=True)
        bar.detail = self.label("", selectable=True)
        box.add(bar.text)
        box.add(bar.detail)
        box.show_all()
        bar.get_content_area().add(box)
        page.add(bar)
        return bar

    def show_notice(self, bar, text, detail=""):
        bar.text.set_text(text)
        bar.detail.set_text(detail)
        bar.detail.set_visible(bool(detail))
        bar.set_visible(True)

    # the page

    def build(self, page):
        Gtk = self.Gtk
        self.error_bar = self.notice_bar(page, Gtk.MessageType.ERROR)
        self.problem_bar = self.notice_bar(page, Gtk.MessageType.WARNING)
        self.hook_bar = self.notice_bar(page, Gtk.MessageType.WARNING)
        copy = Gtk.Button.new_with_mnemonic("_Copy Line")
        copy.connect("clicked", lambda _b: self.copy_line())
        self.hook_bar.add_action_widget(copy, Gtk.ResponseType.OK)
        copy.show()

        recording = self.group(page, "Recording")
        self.enabled_row = self.switch_row(
            recording, "Record activity",
            "When this is off, nothing is recorded, and Trail's keyboard shortcuts and panel button are gone.",
            lambda row, on: self.change(row, "set", "enabled", "yes" if on else "no"))
        self.pause_row = self.switch_row(
            recording, "Pause", "Nothing is recorded until you turn this off. Super+Shift+P does the same.",
            lambda row, on: self.change(row, "pause" if on else "resume", "--quiet"))
        self.shell_row = self.switch_row(
            recording, "Terminal commands", "Each command, with its folder, whether it worked and how long it took.",
            lambda row, on: self.change(row, "set", "sources.shell", "yes" if on else "no"))
        self.clip_row = self.switch_row(
            recording, "Copied text", "Copies from password managers are left out.",
            lambda row, on: self.change(row, "set", "sources.clipboard", "yes" if on else "no"))
        self.row(recording, "Screen text",
                 "Read only when you press Super+` and choose an area. The picture is never saved.")

        keep = self.group(page, "Keep")
        self.retention_rows = {}
        for key, title in RETENTION_ROWS:
            self.retention_rows[key] = self.combo_row(
                keep, title, lambda row, days, key=key: self.change(row, "set", key, str(days)))
        self.archive_row = self.switch_row(
            keep, "Archive before deleting",
            "Older entries go into compressed files instead of being deleted. Search them with trail search --archive.",
            lambda row, on: self.change(row, "set", "archive.enabled", "yes" if on else "no"))
        self.archive_keep_row = self.combo_row(
            keep, "Keep archive files", lambda row, months: self.change(row, "set", "archive.keep_months", str(months)))

        self.blocked_list = self.group(page, "Never read the screen of")
        self.blocked_rows = []
        self.row(self.blocked_list, "Password managers, password prompts and private browser windows",
                 "Always left out.")
        add_box = Gtk.Box(spacing=6)
        self.blocked_entry = Gtk.ComboBoxText.new_with_entry()
        self.blocked_entry.set_hexpand(True)
        entry = self.blocked_entry.get_child()
        entry.set_placeholder_text("App ID, like org.example.Bank")
        entry.set_activates_default(False)
        entry.connect("activate", lambda _e: self.add_blocked())
        add = Gtk.Button.new_with_mnemonic("_Add")
        add.connect("clicked", lambda _b: self.add_blocked())
        add_box.add(self.blocked_entry)
        add_box.add(add)
        self.add_row = self.row(self.blocked_list, "Add an app",
                                "Open windows are suggested. * matches anything: *bank*.", None)
        self.add_row.get_child().add(add_box)
        self.blocked_entry.get_accessible().set_name("App to add")

        history = self.group(page, "Your history")
        delete = Gtk.Button.new_with_mnemonic("_Delete Everything…")
        delete.get_style_context().add_class("destructive-action")
        delete.connect("clicked", lambda _b: self.confirm_delete())
        self.history_row = self.row(history, "", None, delete)

    # reading

    def load(self):
        """Read `trail state` in a thread; the newest answer wins."""
        self.generation += 1
        generation = self.generation

        def work():
            ok, text = run_trail("state")
            try:
                result = json.loads(text) if ok else None
            except ValueError:
                result, ok = None, False
            self.GLib.idle_add(self.loaded, generation, result, None if ok else text)

        threading.Thread(target=work, daemon=True).start()
        if self.state is None:
            threading.Thread(target=self.suggest_apps, daemon=True).start()

    def suggest_apps(self):
        ids = open_app_ids()
        self.GLib.idle_add(lambda: [self.blocked_entry.append_text(i) for i in ids] and False)

    def loaded(self, generation, result, error):
        if generation != self.generation:
            return False
        if result is None:
            self.show_notice(self.error_bar, "Trail's settings couldn't be read.", error or "")
        else:
            self.state = result
            self.apply_state(result)
        self.show_page()
        return False

    def show_page(self):
        # A started spinner draws every frame even while hidden (HIG PERF-5).
        self.spinner.stop()
        self.stack.set_visible_child_name("page")

    def apply_state(self, st):
        settings = st["settings"]
        self.updating = True
        try:
            enabled = settings["enabled"]
            self.enabled_row.control.set_active(enabled)
            self.pause_row.control.set_active(st["paused"])
            self.shell_row.control.set_active(settings["sources.shell"])
            self.clip_row.control.set_active(settings["sources.clipboard"])
            for row in (self.pause_row, self.shell_row, self.clip_row):
                row.set_sensitive(enabled)  # HIG WIN-9: depends on the switch above
            for key, row in self.retention_rows.items():
                self.fill_combo(row.control, choices(RETENTION_CHOICES, settings[key]), settings[key])
            self.archive_row.control.set_active(settings["archive.enabled"])
            self.fill_combo(self.archive_keep_row.control,
                            choices(ARCHIVE_CHOICES, settings["archive.keep_months"], "months"),
                            settings["archive.keep_months"])
            self.archive_keep_row.set_sensitive(settings["archive.enabled"])
            self.fill_blocked(st["blocked"])
            history = st["history"]
            self.history_row.title.set_text(history_text(history["events"]))
            self.set_subtitle(self.history_row, f"{size_text(history['bytes'])} on this computer. "
                                                "Nothing leaves it.")
        finally:
            self.updating = False
        message = hook_message(st["hook"]) if enabled and settings["sources.shell"] else None
        if message:
            self.show_notice(self.hook_bar, message, st["hook"]["line"])
        else:
            self.hook_bar.set_visible(False)
        if enabled and st["error"]:
            self.show_notice(self.problem_bar, "Trail can't record everything right now.", st["error"])
        else:
            self.problem_bar.set_visible(False)

    def fill_combo(self, combo, options, current):
        combo.remove_all()
        for value, label in options:
            combo.append(str(value), label)
        combo.set_active_id(str(current))

    def fill_blocked(self, blocked):
        Gtk = self.Gtk
        for row in self.blocked_rows:
            self.blocked_list.remove(row)
        self.blocked_rows = []
        entries = [(g, "app") for g in blocked["apps"]] + [(g, "title") for g in blocked["titles"]]
        for position, (glob, kind) in enumerate(entries, start=1):
            remove = Gtk.Button.new_from_icon_name("list-remove-symbolic", Gtk.IconSize.BUTTON)
            remove.set_relief(Gtk.ReliefStyle.NONE)
            remove.set_tooltip_text(f"Remove {glob}")
            row = self.row(self.blocked_list, glob, "Window title" if kind == "title" else None, remove)
            remove.get_accessible().set_name(f"Remove {glob}")
            remove.connect("clicked", lambda _b, g=glob, k=kind, r=row: self.change(
                r, "blocked", "remove", *(["--title"] if k == "title" else []), g))
            self.blocked_list.remove(row)
            self.blocked_list.insert(row, position)
            row.show_all()
            self.blocked_rows.append(row)

    # changing

    def set_subtitle(self, row, text):
        row.subtitle.set_text(text or "")
        row.subtitle.set_visible(bool(text))

    def change(self, row, *argv):
        """Run a trail command for a control; "Applying…" in its row meanwhile
        (HIG WIN-8), then read everything again."""
        row.set_sensitive(False)
        self.set_subtitle(row, "Applying…")
        self.error_bar.set_visible(False)

        def work():
            ok, message = run_trail(*argv)
            self.GLib.idle_add(done, ok, message)

        def done(ok, message):
            self.set_subtitle(row, row.subtitle_text)
            row.set_sensitive(True)
            if not ok:
                self.show_notice(self.error_bar, "The change couldn't be made.", message)
            self.load()  # puts a failed control back, too
            return False

        threading.Thread(target=work, daemon=True).start()

    def add_blocked(self):
        glob = self.blocked_entry.get_child().get_text().strip()
        if not glob:
            return
        self.blocked_entry.get_child().set_text("")
        self.change(self.add_row, "blocked", "add", glob)

    def copy_line(self):
        try:
            subprocess.run(["wl-copy"], input=self.state["hook"]["line"].encode(), check=True, timeout=5)
        except (OSError, subprocess.SubprocessError, TypeError) as e:
            self.show_notice(self.error_bar, "The line couldn't be copied. Select it and copy it by hand.", str(e))

    def confirm_delete(self):
        """HIG WIN-13: ask, Cancel by default, the verb in red."""
        Gtk = self.Gtk
        events = self.state["history"]["events"] if self.state else 0
        dialog = Gtk.MessageDialog(transient_for=self.window, modal=True, message_type=Gtk.MessageType.QUESTION,
                                   buttons=Gtk.ButtonsType.NONE, text="Delete everything Trail recorded?")
        dialog.format_secondary_text(
            f"{history_text(events).capitalize()} and the archive are deleted for good. "
            "Recording goes on unless you turn it off.")
        dialog.add_button("_Cancel", Gtk.ResponseType.CANCEL)
        button = dialog.add_button("_Delete", Gtk.ResponseType.ACCEPT)
        button.get_style_context().add_class("destructive-action")
        dialog.set_default_response(Gtk.ResponseType.CANCEL)
        answer = dialog.run()
        dialog.destroy()
        if answer == Gtk.ResponseType.ACCEPT:
            self.change(self.history_row, "forget", "--all", "--yes")
