"""Retention and the optional archive (ADR-017).

`prune()` deletes rows past their source's retention. With the archive turned
on, it first appends them as a new xz stream to archive/YYYY-MM.jsonl.xz (UTC
month of the event), reads the bytes back from disk to check them, and only
then deletes the rows. A file with several xz streams is still one valid .xz
file, so archive files are only ever appended to.
"""

import json
import lzma
import os
import re
import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from trail import db, paths
from trail.config import Config
from trail.redact import Redactor
from trail.search import Query, flat

BATCH = 5000
DAY_MS = 86_400_000
_MONTH_FILE = re.compile(r"^(\d{4}-\d{2})\.jsonl\.xz$")
COLUMNS = (
    "id", "ts", "ts_end", "source", "method", "app_id", "title", "url", "cwd",
    "exit_code", "duration_ms", "text", "bookmarked", "meta",
)


class ArchiveError(Exception):
    pass


def archive_dir() -> Path:
    return paths.data_dir() / "archive"


def month_of(ts_ms: int) -> str:
    return datetime.fromtimestamp(ts_ms / 1000, UTC).strftime("%Y-%m")


def month_file(month: str) -> Path:
    return archive_dir() / f"{month}.jsonl.xz"


def _row_to_json(row: sqlite3.Row) -> str:
    ev = {k: row[k] for k in COLUMNS}
    if ev["meta"]:
        try:
            ev["meta"] = json.loads(ev["meta"])
        except ValueError:
            pass
    return json.dumps(ev, ensure_ascii=False, separators=(",", ":"))


def append_chunk(path: Path, lines: list[str]) -> None:
    """Append `lines` as one xz stream, then prove they are on disk before returning."""
    paths.ensure_private_dir(path.parent)
    chunk = lzma.compress(("\n".join(lines) + "\n").encode(), format=lzma.FORMAT_XZ)
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_APPEND, 0o600)
    try:
        before = os.fstat(fd).st_size
        try:
            os.write(fd, chunk)
            os.fsync(fd)
            written = os.pread(fd, len(chunk), before)
            if written != chunk:
                raise ArchiveError(f"{path}: read-back doesn't match what was written")
            count = lzma.decompress(written).decode().count("\n")
            if count != len(lines):
                raise ArchiveError(f"{path}: wrote {len(lines)} events but read back {count}")
        except BaseException:
            os.ftruncate(fd, before)  # leave the file as it was
            raise
    finally:
        os.close(fd)
    if path.stat().st_mode & 0o077:
        path.chmod(0o600)


def read_month(path: Path):
    """Yield the events in one archive file."""
    with lzma.open(path, "rt", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


@dataclass
class PruneResult:
    deleted: dict[str, int]
    archived: int
    archive_files_removed: list[str]
    pages_freed: int


def expired_count(conn: sqlite3.Connection, cfg: Config, now_ms: int | None = None) -> dict[str, int]:
    now_ms = now_ms or db.now_ms()
    out = {}
    for source in db.SOURCES:
        days = cfg.retention.days_for(source)
        if days:
            out[source] = conn.execute(
                "SELECT count(*) FROM events WHERE source = ? AND ts < ? AND bookmarked = 0",
                (source, now_ms - days * DAY_MS),
            ).fetchone()[0]
    return out


def prune(conn: sqlite3.Connection, cfg: Config, now_ms: int | None = None) -> PruneResult:
    """Apply retention. Bookmarked events are never deleted."""
    now_ms = now_ms or db.now_ms()
    deleted: dict[str, int] = {}
    archived = 0
    for source in db.SOURCES:
        days = cfg.retention.days_for(source)
        if not days:
            continue
        cutoff = now_ms - days * DAY_MS
        while True:
            rows = conn.execute(
                "SELECT * FROM events WHERE source = ? AND ts < ? AND bookmarked = 0 ORDER BY id LIMIT ?",
                (source, cutoff, BATCH),
            ).fetchall()
            if not rows:
                break
            if cfg.archive.enabled:
                by_month: dict[str, list[str]] = {}
                for r in rows:
                    by_month.setdefault(month_of(r["ts"]), []).append(_row_to_json(r))
                for month, lines in sorted(by_month.items()):
                    append_chunk(month_file(month), lines)
                archived += len(rows)
            ids = [r["id"] for r in rows]
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.executemany("DELETE FROM events WHERE id = ?", [(i,) for i in ids])
                conn.execute("COMMIT")
            except BaseException:
                conn.execute("ROLLBACK")
                raise
            deleted[source] = deleted.get(source, 0) + len(ids)
    removed = remove_old_archives(cfg.archive.keep_months, now_ms)
    freed = conn.execute("PRAGMA freelist_count").fetchone()[0]
    # The pragma frees pages one step at a time; fetch to run it to the end.
    conn.execute("PRAGMA incremental_vacuum").fetchall()
    return PruneResult(deleted, archived, removed, freed)


def _months_between(a: str, b: str) -> int:
    ya, ma = map(int, a.split("-"))
    yb, mb = map(int, b.split("-"))
    return (yb - ya) * 12 + (mb - ma)


def remove_old_archives(keep_months: int, now_ms: int | None = None) -> list[str]:
    if not keep_months:
        return []
    current = month_of(now_ms or db.now_ms())
    removed = []
    for month, path in list_files():
        if _months_between(month, current) > keep_months:
            path.unlink()
            removed.append(month)
    return removed


def list_files() -> list[tuple[str, Path]]:
    d = archive_dir()
    if not d.is_dir():
        return []
    out = []
    for p in d.iterdir():
        if m := _MONTH_FILE.match(p.name):
            out.append((m.group(1), p))
    return sorted(out)


def restore(conn: sqlite3.Connection, redactor: Redactor, month: str) -> tuple[int, int]:
    """Put a month's archived events back, keeping their IDs. Returns (restored, already there).

    Text is redacted again, so patterns added since archiving apply too.
    """
    path = month_file(month)
    if not path.exists():
        raise ArchiveError(f"no archive for {month} ({path})")
    restored = present = 0
    conn.execute("BEGIN IMMEDIATE")
    try:
        for ev in read_month(path):
            if conn.execute("SELECT 1 FROM events WHERE id = ?", (ev["id"],)).fetchone():
                present += 1
                continue
            text = redactor.redact(ev["text"])
            meta = ev.get("meta")
            conn.execute(
                f"INSERT INTO events ({', '.join(COLUMNS)}, text_hash) VALUES ({', '.join('?' * (len(COLUMNS) + 1))})",
                (
                    ev["id"], ev["ts"], ev.get("ts_end"), ev["source"], ev.get("method"), ev.get("app_id"),
                    redactor.redact(ev["title"]) if ev.get("title") else ev.get("title"),
                    redactor.redact(ev["url"]) if ev.get("url") else ev.get("url"),
                    ev.get("cwd"), ev.get("exit_code"), ev.get("duration_ms"), text,
                    int(ev.get("bookmarked") or 0),
                    json.dumps(meta) if isinstance(meta, dict) else meta,
                    db.text_hash(text),
                ),
            )
            restored += 1
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    return restored, present


def search_archive(query: Query, limit: int = 50) -> list[dict]:
    """Slow scan of archive files in the query's time range. Every word must appear."""
    words = [w.lower() for w in query.terms if w.strip()] + [p.lower() for p in query.phrases]
    lo = month_of(query.since) if query.since is not None else "0000-00"
    hi = month_of(query.until - 1) if query.until is not None else "9999-99"
    results = []
    for month, path in reversed(list_files()):
        if not lo <= month <= hi:
            continue
        for ev in read_month(path):
            if query.since is not None and ev["ts"] < query.since:
                continue
            if query.until is not None and ev["ts"] >= query.until:
                continue
            if query.sources and ev["source"] not in query.sources:
                continue
            if any(a.lower() not in (ev.get("app_id") or "").lower() for a in query.apps):
                continue
            if query.cwd and not (ev.get("cwd") == query.cwd or (ev.get("cwd") or "").startswith(query.cwd.rstrip("/") + "/")):
                continue
            if query.marked and not ev.get("bookmarked"):
                continue
            hay = " ".join(flat(ev.get(k) or "") for k in ("text", "title", "app_id", "url")).lower()
            if all(w in hay for w in words):
                ev["archived"] = True
                ev["n"] = 1
                results.append(ev)
    results.sort(key=lambda e: e["ts"], reverse=True)
    return results[:limit]


def summary() -> list[tuple[str, int, int]]:
    """(month, bytes, events) for each archive file."""
    return [(m, p.stat().st_size, sum(1 for _ in read_month(p))) for m, p in list_files()]
