"""Which window has focus, from the compositor (ADR-016).

A small read-only Wayland client in pure Python. It speaks the wire protocol
over the compositor's socket, binds zwlr_foreign_toplevel_manager_v1 (and
wl_output, for output names) and follows each window's app ID, title, outputs
and activated state. No libwayland, no generated bindings.

Wire format (wayland.freedesktop.org/docs/html/ch04.html): every message is
a header of two 32-bit words in host byte order, the object ID and
(size << 16 | opcode), followed by the arguments, each padded to 4 bytes.
The opcodes below come from wayland.xml and
wlr-foreign-toplevel-management-unstable-v1.xml.
"""

import os
import select
import socket
import struct
import sys
from dataclasses import dataclass, field

MANAGER = "zwlr_foreign_toplevel_manager_v1"
OUTPUT = "wl_output"
MANAGER_VERSION = 3
OUTPUT_VERSION = 4  # the name event

DISPLAY_ID = 1
# wl_display requests / events
_SYNC, _GET_REGISTRY = 0, 1
_ERROR, _DELETE_ID = 0, 1
# wl_registry request / events
_BIND = 0
_GLOBAL, _GLOBAL_REMOVE = 0, 1
# wl_output event
_OUTPUT_NAME = 4
# manager events
_TOPLEVEL, _FINISHED = 0, 1
# handle events / request
_TITLE, _APP_ID, _OUTPUT_ENTER, _OUTPUT_LEAVE, _STATE, _DONE, _CLOSED = range(7)
_HANDLE_DESTROY = 7
_STATE_ACTIVATED = 2


class WaylandError(Exception):
    pass


@dataclass
class Window:
    handle: int  # object ID; stable for the window's lifetime
    app_id: str = ""
    title: str = ""
    outputs: tuple[str, ...] = ()
    activated: bool = False


@dataclass
class _Handle:
    window: Window
    pending: dict = field(default_factory=dict)
    outputs: set = field(default_factory=set)  # wl_output object IDs


def socket_path() -> str:
    display = os.environ.get("WAYLAND_DISPLAY", "wayland-0")
    if display.startswith("/"):
        return display
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    if not runtime:
        raise WaylandError("XDG_RUNTIME_DIR is not set")
    return os.path.join(runtime, display)


# --- encoding ------------------------------------------------------------------

def _pad(n: int) -> int:
    return (n + 3) & ~3


def _string(s: str) -> bytes:
    data = s.encode() + b"\0"
    return struct.pack("=I", len(data)) + data.ljust(_pad(len(data)), b"\0")


def message(obj: int, opcode: int, payload: bytes = b"") -> bytes:
    return struct.pack("=II", obj, ((8 + len(payload)) << 16) | opcode) + payload


class _Args:
    def __init__(self, data: bytes):
        self.data, self.pos = data, 0

    def uint(self) -> int:
        (v,) = struct.unpack_from("=I", self.data, self.pos)
        self.pos += 4
        return v

    def int(self) -> int:
        (v,) = struct.unpack_from("=i", self.data, self.pos)
        self.pos += 4
        return v

    def bytes(self) -> bytes:
        n = self.uint()
        v = self.data[self.pos : self.pos + n]
        self.pos += _pad(n)
        return v

    def string(self) -> str:
        return self.bytes().rstrip(b"\0").decode(errors="replace")


# --- the client -------------------------------------------------------------------

class FocusTracker:
    """Follows windows and focus. Call dispatch() when fileno() is readable."""

    def __init__(self, sock: socket.socket | None = None):
        if sock is None:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM | socket.SOCK_CLOEXEC)
            try:
                sock.connect(socket_path())
            except OSError as e:
                sock.close()
                raise WaylandError(f"can't connect to the compositor: {e}") from None
        self.sock = sock
        self._buf = b""
        self._next_id = 2
        self._kinds: dict[int, str] = {DISPLAY_ID: "display"}
        self._handles: dict[int, _Handle] = {}
        self._output_names: dict[int, str] = {}
        self._syncs: set[int] = set()
        self.manager_bound = False
        self.finished = False
        self.focused: Window | None = None
        self.changes = 0  # bumped whenever the focused window, its app ID or title changes
        self.registry = self._new("registry")
        self._send(message(DISPLAY_ID, _GET_REGISTRY, struct.pack("=I", self.registry)))

    # objects and requests

    def _new(self, kind: str) -> int:
        obj = self._next_id
        self._next_id += 1
        self._kinds[obj] = kind
        return obj

    def _send(self, data: bytes) -> None:
        self.sock.sendall(data)

    def _bind(self, name: int, interface: str, version: int, kind: str) -> int:
        obj = self._new(kind)
        payload = struct.pack("=I", name) + _string(interface) + struct.pack("=II", version, obj)
        self._send(message(self.registry, _BIND, payload))
        return obj

    def fileno(self) -> int:
        return self.sock.fileno()

    def close(self) -> None:
        self.sock.close()

    def windows(self) -> list[Window]:
        return [h.window for h in self._handles.values()]

    # reading

    def dispatch(self, timeout: float | None = 0) -> bool:
        """Read and handle whatever the compositor sent. False on timeout."""
        ready, _, _ = select.select([self.sock], [], [], timeout)
        if not ready:
            return False
        data = self.sock.recv(65536)
        if not data:
            raise WaylandError("the compositor closed the connection")
        self._buf += data
        while len(self._buf) >= 8:
            obj, word = struct.unpack_from("=II", self._buf)
            size, opcode = word >> 16, word & 0xFFFF
            if size < 8:
                raise WaylandError(f"bad message size {size}")
            if len(self._buf) < size:
                break
            body, self._buf = self._buf[8:size], self._buf[size:]
            self._handle(obj, opcode, _Args(body))
        return True

    def roundtrip(self, timeout: float = 2.0) -> None:
        """Wait until the compositor has answered everything sent so far."""
        callback = self._new("callback")
        self._syncs.add(callback)
        self._send(message(DISPLAY_ID, _SYNC, struct.pack("=I", callback)))
        while callback in self._syncs:
            if not self.dispatch(timeout):
                raise WaylandError("the compositor didn't answer")

    def _handle(self, obj: int, opcode: int, a: _Args) -> None:
        kind = self._kinds.get(obj)
        if kind is None and obj >= 0xFF000000:
            kind = "handle" if obj in self._handles else None
        if kind == "display":
            if opcode == _ERROR:
                target, code, msg = a.uint(), a.uint(), a.string()
                raise WaylandError(f"protocol error on object {target} (code {code}): {msg}")
        elif kind == "registry" and opcode == _GLOBAL:
            name, interface, version = a.uint(), a.string(), a.uint()
            if interface == MANAGER and not self.manager_bound:
                self._bind(name, interface, min(version, MANAGER_VERSION), "manager")
                self.manager_bound = True
            elif interface == OUTPUT and version >= OUTPUT_VERSION:
                self._bind(name, interface, OUTPUT_VERSION, "output")
        elif kind == "callback":
            self._syncs.discard(obj)
        elif kind == "output" and opcode == _OUTPUT_NAME:
            self._output_names[obj] = a.string()
        elif kind == "manager":
            if opcode == _TOPLEVEL:
                handle = a.uint()
                self._handles[handle] = _Handle(Window(handle))
            elif opcode == _FINISHED:
                self.finished = True
        elif kind == "handle":
            self._handle_event(obj, opcode, a)

    def _handle_event(self, obj: int, opcode: int, a: _Args) -> None:
        h = self._handles[obj]
        if opcode == _TITLE:
            h.pending["title"] = a.string()
        elif opcode == _APP_ID:
            h.pending["app_id"] = a.string()
        elif opcode == _OUTPUT_ENTER:
            h.outputs.add(a.uint())
        elif opcode == _OUTPUT_LEAVE:
            h.outputs.discard(a.uint())
        elif opcode == _STATE:
            raw = a.bytes()
            states = struct.unpack(f"={len(raw) // 4}I", raw[: len(raw) // 4 * 4])
            h.pending["activated"] = _STATE_ACTIVATED in states
        elif opcode == _DONE:
            w = h.window
            for key, value in h.pending.items():
                setattr(w, key, value)
            h.pending.clear()
            w.outputs = tuple(sorted(self._output_names.get(o, "") for o in h.outputs if o in self._output_names))
            self._update_focus()
        elif opcode == _CLOSED:
            del self._handles[obj]
            self._send(message(obj, _HANDLE_DESTROY))
            self._update_focus()

    def _update_focus(self) -> None:
        active = [h.window for h in self._handles.values() if h.window.activated]
        new = active[-1] if active else None
        old = self.focused
        key = lambda w: (w.handle, w.app_id, w.title) if w else None  # noqa: E731
        if key(new) != key(old):
            self.changes += 1
        self.focused = Window(**vars(new)) if new else None


def connect() -> FocusTracker:
    """Connect and wait for the initial window list. Raises WaylandError."""
    tracker = FocusTracker()
    tracker.roundtrip()  # the globals, and our binds
    if not tracker.manager_bound:
        tracker.close()
        raise WaylandError(f"the compositor doesn't offer {MANAGER}")
    tracker.roundtrip()  # the toplevels and their first done events
    return tracker


def watch(out=sys.stdout) -> None:
    """`trail focus --watch`: print every focus change."""
    tracker = connect()
    seen = None
    try:
        while True:
            if tracker.changes != seen:
                seen = tracker.changes
                w = tracker.focused
                if w is None:
                    print("(no focused window)", file=out, flush=True)
                else:
                    outputs = ",".join(w.outputs) or "?"
                    print(f"{w.app_id or '?'}\t{w.title}\t[{outputs}]", file=out, flush=True)
            tracker.dispatch(None)
    finally:
        tracker.close()
