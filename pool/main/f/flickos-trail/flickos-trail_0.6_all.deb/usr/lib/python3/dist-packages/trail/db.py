"""The SQLite store (ADR-002): events table, FTS5 index, migrations, private file mode."""

import hashlib
import json
import os
import sqlite3
import time
from pathlib import Path

from trail import paths
from trail.redact import Redactor

SOURCES = ("shell", "screen", "clip", "mark")

# Each entry moves the schema from version i to i+1. Never edit an entry
# once released; append a new one instead.
MIGRATIONS: list[str] = [
    """
    CREATE TABLE events (
      id          INTEGER PRIMARY KEY,
      ts          INTEGER NOT NULL,        -- unix ms, UTC
      ts_end      INTEGER,
      source      TEXT NOT NULL,           -- shell | screen | clip | mark
      method      TEXT,                    -- atspi | ocr | hook | atuin | ...
      app_id      TEXT,
      title       TEXT,
      url         TEXT,
      cwd         TEXT,
      exit_code   INTEGER,
      duration_ms INTEGER,
      text        TEXT NOT NULL,
      text_hash   TEXT NOT NULL,
      bookmarked  INTEGER NOT NULL DEFAULT 0,
      meta        TEXT                     -- JSON
    );
    CREATE INDEX events_ts ON events(ts);
    CREATE INDEX events_src_ts ON events(source, ts);

    CREATE VIRTUAL TABLE events_fts USING fts5(
      text, title, app_id, url,
      content='events', content_rowid='id',
      tokenize='unicode61 remove_diacritics 2'
    );

    CREATE TRIGGER events_ai AFTER INSERT ON events BEGIN
      INSERT INTO events_fts(rowid, text, title, app_id, url)
      VALUES (new.id, new.text, new.title, new.app_id, new.url);
    END;
    CREATE TRIGGER events_ad AFTER DELETE ON events BEGIN
      INSERT INTO events_fts(events_fts, rowid, text, title, app_id, url)
      VALUES ('delete', old.id, old.text, old.title, old.app_id, old.url);
    END;
    CREATE TRIGGER events_au AFTER UPDATE OF text, title, app_id, url ON events BEGIN
      INSERT INTO events_fts(events_fts, rowid, text, title, app_id, url)
      VALUES ('delete', old.id, old.text, old.title, old.app_id, old.url);
      INSERT INTO events_fts(rowid, text, title, app_id, url)
      VALUES (new.id, new.text, new.title, new.app_id, new.url);
    END;
    """,
    # v2: AUTOINCREMENT, so an id is never reused after the newest rows are
    # deleted. Archive files and `archive restore` rely on ids staying unique.
    # Rows keep their ids, so the FTS index stays valid.
    """
    CREATE TABLE events_v2 (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      ts          INTEGER NOT NULL,
      ts_end      INTEGER,
      source      TEXT NOT NULL,
      method      TEXT,
      app_id      TEXT,
      title       TEXT,
      url         TEXT,
      cwd         TEXT,
      exit_code   INTEGER,
      duration_ms INTEGER,
      text        TEXT NOT NULL,
      text_hash   TEXT NOT NULL,
      bookmarked  INTEGER NOT NULL DEFAULT 0,
      meta        TEXT
    );
    INSERT INTO events_v2 SELECT * FROM events;
    DROP TABLE events;
    ALTER TABLE events_v2 RENAME TO events;
    CREATE INDEX events_ts ON events(ts);
    CREATE INDEX events_src_ts ON events(source, ts);

    CREATE TRIGGER events_ai AFTER INSERT ON events BEGIN
      INSERT INTO events_fts(rowid, text, title, app_id, url)
      VALUES (new.id, new.text, new.title, new.app_id, new.url);
    END;
    CREATE TRIGGER events_ad AFTER DELETE ON events BEGIN
      INSERT INTO events_fts(events_fts, rowid, text, title, app_id, url)
      VALUES ('delete', old.id, old.text, old.title, old.app_id, old.url);
    END;
    CREATE TRIGGER events_au AFTER UPDATE OF text, title, app_id, url ON events BEGIN
      INSERT INTO events_fts(events_fts, rowid, text, title, app_id, url)
      VALUES ('delete', old.id, old.text, old.title, old.app_id, old.url);
      INSERT INTO events_fts(rowid, text, title, app_id, url)
      VALUES (new.id, new.text, new.title, new.app_id, new.url);
    END;
    """,
]

SCHEMA_VERSION = len(MIGRATIONS)


def _create_private_file(path: Path) -> None:
    """Create the database file as 0600 before SQLite touches it, and tighten an existing one."""
    paths.ensure_private_dir(path.parent)
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    os.close(fd)
    for p in (path, Path(f"{path}-wal"), Path(f"{path}-shm")):
        if p.exists() and p.stat().st_mode & 0o077:
            p.chmod(0o600)


def connect(path: Path | None = None, migrate: bool = True) -> sqlite3.Connection:
    path = path or paths.db_file()
    _create_private_file(path)
    conn = sqlite3.connect(path, autocommit=True)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 5000")
    # Must be set before the first table exists; ensure_auto_vacuum() fixes older files.
    conn.execute("PRAGMA auto_vacuum = INCREMENTAL")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA foreign_keys = ON")
    if migrate:
        migrate_db(conn)
        ensure_auto_vacuum(conn)
    return conn


AUTO_VACUUM_INCREMENTAL = 2


def ensure_auto_vacuum(conn: sqlite3.Connection) -> None:
    """Switch a database created without incremental auto-vacuum (ADR-002).

    Changing the mode on a file that already has tables needs a full VACUUM.
    That only happens once, for databases made before this setting existed.
    """
    if conn.execute("PRAGMA auto_vacuum").fetchone()[0] != AUTO_VACUUM_INCREMENTAL:
        conn.execute("PRAGMA auto_vacuum = INCREMENTAL")
        conn.execute("VACUUM")


def schema_version(conn: sqlite3.Connection) -> int:
    return conn.execute("PRAGMA user_version").fetchone()[0]


def migrate_db(conn: sqlite3.Connection) -> int:
    """Apply pending migrations, each in its own transaction. Returns the new version."""
    current = schema_version(conn)
    if current > SCHEMA_VERSION:
        raise RuntimeError(
            f"database schema v{current} is newer than this trail (v{SCHEMA_VERSION}); upgrade trail"
        )
    for version in range(current, SCHEMA_VERSION):
        conn.execute("BEGIN IMMEDIATE")
        try:
            # Re-check inside the lock in case another process migrated first.
            if schema_version(conn) != version:
                conn.execute("ROLLBACK")
                continue
            for stmt in _split_sql(MIGRATIONS[version]):
                conn.execute(stmt)
            conn.execute(f"PRAGMA user_version = {version + 1}")
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
    return schema_version(conn)


def _split_sql(script: str) -> list[str]:
    """Split a script into complete statements (handles trigger bodies)."""
    stmts, start = [], 0
    for i, ch in enumerate(script):
        if ch == ";" and sqlite3.complete_statement(script[start : i + 1]):
            stmts.append(script[start : i + 1].strip())
            start = i + 1
    if script[start:].strip():
        stmts.append(script[start:].strip())
    return stmts


def now_ms() -> int:
    return time.time_ns() // 1_000_000


def insert_event(
    conn: sqlite3.Connection,
    redactor: Redactor,
    *,
    source: str,
    text: str,
    ts: int | None = None,
    ts_end: int | None = None,
    method: str | None = None,
    app_id: str | None = None,
    title: str | None = None,
    url: str | None = None,
    cwd: str | None = None,
    exit_code: int | None = None,
    duration_ms: int | None = None,
    bookmarked: bool = False,
    meta: dict | None = None,
) -> int:
    """Redact and store one event. The only way events should be written."""
    if source not in SOURCES:
        raise ValueError(f"unknown source {source!r}")
    text = redactor.redact(text)
    title = redactor.redact(title) if title else title
    url = redactor.redact(url) if url else url
    cur = conn.execute(
        """
        INSERT INTO events (ts, ts_end, source, method, app_id, title, url, cwd,
                            exit_code, duration_ms, text, text_hash, bookmarked, meta)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            ts if ts is not None else now_ms(),
            ts_end,
            source,
            method,
            app_id,
            title,
            url,
            cwd,
            exit_code,
            duration_ms,
            text,
            text_hash(text),
            int(bookmarked),
            json.dumps(meta) if meta else None,
        ),
    )
    return cur.lastrowid


def text_hash(text: str) -> str:
    return hashlib.blake2b(text.encode(), digest_size=16).hexdigest()


def fts5_available() -> bool:
    c = sqlite3.connect(":memory:")
    try:
        c.execute("CREATE VIRTUAL TABLE t USING fts5(x)")
        return True
    except sqlite3.OperationalError:
        return False
    finally:
        c.close()
