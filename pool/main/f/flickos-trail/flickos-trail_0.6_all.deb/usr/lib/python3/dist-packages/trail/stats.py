"""`trail stats --storage`: how big each source is and how fast it grows.

Used to replace the estimates in PLAN.md (Growth and limits) with real
numbers and to tune the retention defaults.
"""

import sqlite3
from dataclasses import dataclass

from trail import archive, db, paths

DAY_MS = 86_400_000
WINDOW_DAYS = 7  # growth is averaged over the last week


@dataclass
class SourceStats:
    source: str
    events: int
    text_bytes: int
    oldest_ms: int | None
    week_events: int
    week_bytes: int
    days: float  # the span the week_* numbers cover: the last week, or less for newer data

    @property
    def per_day_bytes(self) -> float:
        return self.week_bytes / self.days


def source_stats(conn: sqlite3.Connection, now_ms: int | None = None) -> list[SourceStats]:
    now_ms = now_ms or db.now_ms()
    since = now_ms - WINDOW_DAYS * DAY_MS
    out = []
    for source in db.SOURCES:
        n, size, oldest = conn.execute(
            "SELECT count(*), coalesce(sum(length(CAST(text AS BLOB))), 0), min(ts) FROM events WHERE source = ?",
            (source,),
        ).fetchone()
        wn, wsize = conn.execute(
            "SELECT count(*), coalesce(sum(length(CAST(text AS BLOB))), 0) FROM events WHERE source = ? AND ts >= ?",
            (source, since),
        ).fetchone()
        days = max(1.0, (now_ms - max(since, oldest or now_ms)) / DAY_MS)
        out.append(SourceStats(source, n, size, oldest, wn, wsize, days))
    return out


def table_sizes(conn: sqlite3.Connection) -> dict[str, int] | None:
    """Bytes per table and index, grouping the FTS shadow tables. None without dbstat."""
    try:
        rows = conn.execute("SELECT name, sum(pgsize) FROM dbstat GROUP BY name").fetchall()
    except sqlite3.OperationalError:
        return None
    out: dict[str, int] = {}
    for name, size in rows:
        key = "keyword index (FTS5)" if name.startswith("events_fts") else (
            "events" if name == "events" else "time indexes" if name.startswith("events_") else "other")
        out[key] = out.get(key, 0) + size
    return out


def human(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


def report(conn: sqlite3.Connection) -> list[str]:
    path = paths.db_file()
    files = sum(p.stat().st_size for p in (path, path.with_name(path.name + "-wal")) if p.exists())
    lines = [f"database {path}: {human(files)} on disk (with WAL)"]
    stats = source_stats(conn)
    total_text = sum(s.text_bytes for s in stats) or 1
    sizes = table_sizes(conn)
    # Text is only part of the file: spread the rest (index, metadata) by text share.
    db_bytes = sum(sizes.values()) if sizes else files
    lines.append("")
    lines.append(f"{'source':<8}{'events':>9}{'text':>11}{'~on disk':>11}{'per day':>11}{'per year':>11}  (growth: last {WINDOW_DAYS} days, or since the first event)")
    for s in stats:
        share = s.text_bytes / total_text
        overhead = db_bytes / total_text if s.text_bytes else 0
        per_day = s.per_day_bytes * overhead if overhead else 0
        lines.append(
            f"{s.source:<8}{s.events:>9}{human(s.text_bytes):>11}{human(db_bytes * share):>11}"
            f"{human(per_day):>11}{human(per_day * 365):>11}"
        )
    if sizes:
        lines.append("")
        for name, size in sorted(sizes.items(), key=lambda kv: -kv[1]):
            lines.append(f"{name:<22}{human(size):>11}")
    arc = archive.list_files()
    if arc:
        lines.append("")
        lines.append(f"archive: {len(arc)} files, {human(sum(p.stat().st_size for _, p in arc))}")
    return lines
