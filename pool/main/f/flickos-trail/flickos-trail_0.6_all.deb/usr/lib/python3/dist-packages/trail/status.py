"""`trail status`: whether Trail records, for people and for the panel button.

The panel runs `trail status --panel` once at start and again on
SIGRTMIN+11, which the commands that change the state send (session.signal_panel);
nothing polls (flickos-trail ADR-006).
"""

import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime

from trail import config, paths, search, session, state

RECORDING, PAUSED, ERROR, OFF = "recording", "paused", "error", "off"


@dataclass
class Status:
    state: str
    reasons: dict[str, int] = field(default_factory=dict)
    error: str | None = None
    events_today: int | None = None
    last: dict | None = None
    notes: list[str] = field(default_factory=list)


def current() -> Status:
    try:
        cfg = config.load()
    except config.ConfigError as e:
        return Status(ERROR, error=f"settings: {e}")
    if not cfg.enabled:
        return Status(OFF)
    reasons = state.pause_reasons()
    error = state.last_error()
    today = last = None
    notes = []
    path = paths.db_file()
    if path.exists():
        try:
            conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            try:
                start = int(datetime.combine(datetime.now().date(), datetime.min.time()).timestamp() * 1000)
                today = conn.execute("SELECT count(*) FROM events WHERE ts >= ?", (start,)).fetchone()[0]
                row = conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT 1").fetchone()
                last = dict(row) if row else None
            finally:
                conn.close()
        except sqlite3.Error as e:
            error = error or f"database: {e}"
    else:
        notes.append("nothing recorded yet")
    if cfg.sources.clipboard and session.in_session() and session.watcher_pid() is None:
        error = error or "clipboard recording stopped (run: trail clipboard)"
    if not cfg.sources.clipboard:
        notes.append("copied text is not recorded")
    if error:
        s = ERROR
    elif reasons:
        s = PAUSED
    else:
        s = RECORDING
    return Status(s, reasons, error, today, last, notes)


def describe(st: Status) -> list[str]:
    if st.state == OFF:
        return ["Trail is off (trail set enabled yes)"]
    lines = [f"Trail: {st.state}"]
    if st.error:
        lines.append(st.error)
    for _reason, since in st.reasons.items():
        lines.append(f"paused since {datetime.fromtimestamp(since / 1000):%H:%M}")
    if st.events_today is not None:
        lines.append(f"{st.events_today} events today")
    if st.last:
        where = search.where_label(st.last)
        lines.append(f"last: {st.last['source']}{' in ' + where if where else ''}, {search.ago(st.last['ts'])}")
    lines.extend(st.notes)
    return lines


def panel_json(st: Status) -> str:
    """One line for waybar. Its text is the state, and the add-on's style
    shows an icon for it; while off the text is empty, which hides the button."""
    if st.state == OFF:
        return json.dumps({"text": ""})
    return json.dumps(
        {"text": st.state, "alt": st.state, "class": st.state, "tooltip": "\n".join(describe(st))},
        ensure_ascii=False,
    )
