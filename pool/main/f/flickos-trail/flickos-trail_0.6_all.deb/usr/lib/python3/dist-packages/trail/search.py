"""Search: query parsing, FTS5 queries, and one-line formatting shared by the CLI and pick."""

import json
import os
import re
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime

from trail import db, timeparse

# key:value filters understood inside a query, e.g. "docker src:shell since:yesterday".
FILTER_KEYS = {"src", "source", "app", "cwd", "since", "until", "is"}

_TOKEN = re.compile(r'(?P<key>[a-z]+):(?:"(?P<qval>[^"]*)"|(?P<val>\S*))|"(?P<phrase>[^"]*)"?|(?P<word>\S+)')


class QueryError(ValueError):
    pass


@dataclass
class Query:
    terms: list[str] = field(default_factory=list)  # words, matched as prefixes
    phrases: list[str] = field(default_factory=list)  # "quoted phrases", matched exactly
    sources: list[str] = field(default_factory=list)
    apps: list[str] = field(default_factory=list)
    cwd: str | None = None
    since: int | None = None  # unix ms, inclusive
    until: int | None = None  # unix ms, exclusive
    marked: bool = False

    @property
    def has_text(self) -> bool:
        return bool(self.terms or self.phrases)


def parse_query(text: str, now=None) -> Query:
    q = Query()
    for m in _TOKEN.finditer(text or ""):
        key = m.group("key")
        if key in FILTER_KEYS:
            value = m.group("qval") if m.group("qval") is not None else m.group("val")
            apply_filter(q, key, value, now=now)
        elif m.group("phrase") is not None:
            if m.group("phrase").strip():
                q.phrases.append(m.group("phrase"))
        else:
            q.terms.append(m.group(0))
    return q


def apply_filter(q: Query, key: str, value: str, now=None) -> None:
    if not value:
        raise QueryError(f"{key}: needs a value")
    if key in ("src", "source"):
        for s in value.split(","):
            if s not in db.SOURCES:
                raise QueryError(f"unknown source {s!r} (one of {', '.join(db.SOURCES)})")
            q.sources.append(s)
    elif key == "app":
        q.apps.append(value)
    elif key == "cwd":
        q.cwd = os.path.abspath(os.path.expanduser(value))
    elif key in ("since", "until"):
        try:
            ms = timeparse.parse(value, end=(key == "until"), now=now)
        except ValueError as e:
            raise QueryError(str(e)) from None
        setattr(q, key, ms)
    elif key == "is":
        if value not in ("marked", "bookmarked"):
            raise QueryError("is: only understands is:marked")
        q.marked = True


def fts_expression(q: Query) -> str | None:
    """Build a safe FTS5 MATCH string: every word becomes a quoted prefix term.

    User input never reaches FTS5 syntax directly, so `foo-bar`, `a.b` or a
    lone `"` can't cause a syntax error.
    """
    parts = []
    for word in q.terms:
        if re.search(r"\w", word):
            parts.append('"' + word.replace('"', '""') + '"*')
    for phrase in q.phrases:
        if re.search(r"\w", phrase):
            parts.append('"' + phrase.replace('"', '""') + '"')
    return " ".join(parts) or None


def id_range(conn: sqlite3.Connection, since: int | None, until: int | None) -> tuple[int, int] | None:
    """The event-ID range covering a time window (see PLAN.md, Growth and limits).

    FTS5 can't use the ts index, but it filters on rowid cheaply. Computed as
    min/max over the window, so imported rows with old timestamps still count.
    """
    row = conn.execute(
        "SELECT min(id), max(id) FROM events WHERE ts >= ? AND ts < ?",
        (since if since is not None else -(2**62), until if until is not None else 2**62),
    ).fetchone()
    return None if row[0] is None else (row[0], row[1])


def _like_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def search(
    conn: sqlite3.Connection,
    q: Query,
    *,
    limit: int = 50,
    order: str = "time",
    dedupe: bool = True,
) -> list[dict]:
    """Events matching `q`, newest first (or best match first with order='rank').

    With dedupe, repeated texts (the same command run many times) collapse into
    their newest instance, with `n` set to the number of copies.
    """
    where, params = [], []
    expr = fts_expression(q)
    if expr is None and q.has_text:
        return []  # only punctuation: nothing FTS5 could match

    if q.since is not None or q.until is not None:
        rng = id_range(conn, q.since, q.until)
        if rng is None:
            return []
        if q.since is not None:
            where.append("e.ts >= ?")
            params.append(q.since)
        if q.until is not None:
            where.append("e.ts < ?")
            params.append(q.until)
    else:
        rng = None

    if q.sources:
        where.append(f"e.source IN ({','.join('?' * len(q.sources))})")
        params += q.sources
    for app in q.apps:
        where.append("e.app_id LIKE ? ESCAPE '\\'")
        params.append(f"%{_like_escape(app)}%")
    if q.cwd:
        where.append("(e.cwd = ? OR e.cwd LIKE ? ESCAPE '\\')")
        params += [q.cwd, _like_escape(q.cwd.rstrip("/")) + "/%"]
    if q.marked:
        where.append("e.bookmarked = 1")

    cap = max(limit * 20, 2000)
    if expr:
        sql = "SELECT e.*, bm25(events_fts) AS score FROM events_fts JOIN events e ON e.id = events_fts.rowid WHERE events_fts MATCH ?"
        head = [expr]
        if rng:
            sql += " AND events_fts.rowid BETWEEN ? AND ?"
            head += list(rng)
        inner_order = "score" if order == "rank" else "e.ts DESC"
    else:
        sql = "SELECT e.*, 0.0 AS score FROM events e WHERE 1"
        head = []
        inner_order = "e.ts DESC"
    for w in where:
        sql += f" AND {w}"
    sql += f" ORDER BY {inner_order} LIMIT {int(cap)}"

    if dedupe:
        # Bare columns come from the row holding max(ts): the newest copy.
        sql = f"SELECT *, count(*) AS n, max(ts) AS _newest FROM ({sql}) GROUP BY source, text_hash"
    else:
        sql = f"SELECT *, 1 AS n, ts AS _newest FROM ({sql})"
    sql += " ORDER BY " + ("score, _newest DESC" if order == "rank" else "_newest DESC") + " LIMIT ?"
    rows = [dict(r) for r in conn.execute(sql, head + params + [limit])]
    for r in rows:
        del r["_newest"]
    return rows


def get_event(conn: sqlite3.Connection, event_id: int) -> dict | None:
    row = conn.execute("SELECT *, 1 AS n FROM events WHERE id = ?", (event_id,)).fetchone()
    return dict(row) if row else None


def context(conn: sqlite3.Connection, event: dict, minutes: float = 5) -> list[dict]:
    """Events within ±`minutes` of `event`, oldest first."""
    span = int(minutes * 60_000)
    rows = conn.execute(
        "SELECT *, 1 AS n FROM events WHERE ts BETWEEN ? AND ? ORDER BY ts, id",
        (event["ts"] - span, event["ts"] + span),
    )
    return [dict(r) for r in rows]


# --- formatting --------------------------------------------------------------

_HOME = os.path.expanduser("~")


def short_path(p: str | None) -> str:
    if not p:
        return ""
    if p == _HOME or p.startswith(_HOME + "/"):
        return "~" + p[len(_HOME):]
    return p


def ago(ts: int, now: float | None = None) -> str:
    seconds = max(0, (now or time.time()) - ts / 1000)
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        return f"{int(seconds // 60)}m ago"
    if seconds < 86400:
        return f"{int(seconds // 3600)}h ago"
    if seconds < 7 * 86400:
        return f"{int(seconds // 86400)}d ago"
    return datetime.fromtimestamp(ts / 1000).strftime("%Y-%m-%d")


def flat(text: str) -> str:
    return " ".join((text or "").split())


def where_label(ev: dict) -> str:
    """Where the event happened: the cwd for commands, the app for everything else."""
    if ev.get("cwd"):
        return short_path(ev["cwd"])
    return ev.get("app_id") or ""


def one_line(ev: dict, width: int | None = None) -> str:
    """`2026-09-29 14:03  shell  docker compose up   ~/proj [exit 1] ×3`"""
    when = datetime.fromtimestamp(ev["ts"] / 1000).strftime("%Y-%m-%d %H:%M")
    extra = []
    if label := where_label(ev):
        extra.append(label)
    if ev.get("exit_code"):
        extra.append(f"[exit {ev['exit_code']}]")
    if ev.get("n", 1) > 1:
        extra.append(f"×{ev['n']}")
    if ev.get("archived"):
        extra.append("(archive)")
    tail = ("   " + " ".join(extra)) if extra else ""
    head = f"{when}  {ev['source']:<6} "
    body = flat(ev["text"])
    if width:
        room = width - len(head) - len(tail)
        if room < 20:
            tail, room = "", width - len(head)
        if len(body) > room:
            body = body[: max(room - 1, 1)] + "…"
    return head + body + tail


def to_json(ev: dict) -> str:
    out = {k: v for k, v in ev.items() if k not in ("score", "text_hash")}
    if isinstance(out.get("meta"), str):
        try:
            out["meta"] = json.loads(out["meta"])
        except ValueError:
            pass
    return json.dumps(out, ensure_ascii=False)
