"""Secret removal (ADR-006). Every source runs its text through this before storage.

A pattern either replaces its whole match, or only the named group `secret`
when it has one (so `--password=hunter2` keeps the flag name).
"""

import math
import re
from collections import Counter
from dataclasses import dataclass

from trail.config import RedactConfig

MARKER = "[REDACTED:{}]"

# Don't redact a value that is a shell variable or has already been redacted.
_VALUE_GUARD = r"(?!\$|\[REDACTED)"

_PATTERNS: dict[str, str] = {
    "private_key": r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?(?:-----END [A-Z ]*PRIVATE KEY-----|\Z)",
    "aws_key": r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b",
    "github_token": r"\b(?:gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{22,})\b",
    "gitlab_token": r"\bglpat-[A-Za-z0-9_-]{20,}",
    "api_key": r"\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{20,}",
    "stripe_key": r"\b[rs]k_(?:live|test)_[A-Za-z0-9]{16,}\b",
    "google_api_key": r"\bAIza[0-9A-Za-z_-]{35}",
    "slack_token": r"\bxox[abprs]-[A-Za-z0-9-]{10,}",
    "slack_webhook": r"https://hooks\.slack\.com/services/\S+",
    "jwt": r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}",
    # scheme://user:password@host -> keep the user, drop the password
    "url_password": r"://[^/\s:@]+:(?P<secret>[^/\s@]+)@",
    "bearer": r"(?i)\b(?:bearer|basic|token)\s+" + _VALUE_GUARD + r"(?P<secret>[A-Za-z0-9._~+/=-]{16,})",
    "cli_password": (
        r"(?i)--(?:password|passwd|pass|token|secret|api[-_]?key|client[-_]secret|auth[-_]token)"
        r"(?:=|\s+)" + _VALUE_GUARD + r"(?P<secret>'[^']*'|\"[^\"]*\"|[^\s'\"]+)"
    ),
    "mysql_password": r"\b(?:mysql|mariadb|mysqldump|mysqladmin)\b[^\n|;&]*?\s-p" + _VALUE_GUARD + r"(?P<secret>[^\s]+)",
    "sshpass": r"\bsshpass\s+-p\s*" + _VALUE_GUARD + r"(?P<secret>\S+)",
    # NAME=value / NAME: value where NAME looks like it holds a secret
    "assignment": (
        r"(?i)\b[\w.-]*?(?:token|secret|passw(?:or)?d|passphrase|api[_-]?key|apikey|private[_-]?key|access[_-]?key)\w*"
        r"[\"']?\s*[=:]\s*" + _VALUE_GUARD + r"(?P<secret>\"[^\"\n]*\"|'[^'\n]*'|[^\s\"',;]{3,})"
    ),
}

# 13–19 digits, optionally grouped with spaces or dashes.
_CARD_CANDIDATE = re.compile(r"(?<![\d-])\d(?:[ -]?\d){12,18}(?![\d-])")
# Known issuer prefixes, so timestamps and other long numbers don't match.
_CARD_PREFIX = re.compile(r"^(?:4|5[1-5]|2(?:2[2-9]|[3-6]|7[01]|720)|3[47]|6(?:011|5|4[4-9])|35(?:2[89]|[3-8])|3(?:0[0-5]|[68]))")

# Candidate tokens for the entropy check.
# `=` only as base64 padding, so NAME=value splits into two tokens.
_TOKEN = re.compile(r"[A-Za-z0-9+/_-]+={0,2}")
_HEX = re.compile(r"^[0-9a-fA-F-]+$")


@dataclass(frozen=True)
class Finding:
    kind: str
    start: int
    end: int


def luhn_ok(digits: str) -> bool:
    total = 0
    for i, ch in enumerate(reversed(digits)):
        n = int(ch)
        if i % 2:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def shannon_entropy(s: str) -> float:
    counts = Counter(s)
    n = len(s)
    return -sum(c / n * math.log2(c / n) for c in counts.values())


class Redactor:
    def __init__(self, config: RedactConfig | None = None):
        self.config = config or RedactConfig()
        patterns = dict(_PATTERNS)
        patterns.update(self.config.extra)
        self._patterns = [(kind, re.compile(rx)) for kind, rx in patterns.items()]
        self._allow = [re.compile(rx) for rx in self.config.allow]

    def scan(self, text: str) -> list[Finding]:
        """Find secrets. Overlapping findings are resolved: earliest first, then longest."""
        found: list[Finding] = []
        for kind, rx in self._patterns:
            for m in rx.finditer(text):
                if "secret" in rx.groupindex and m.group("secret") is not None:
                    start, end = m.span("secret")
                else:
                    start, end = m.span()
                found.append(Finding(kind, start, end))
        for m in _CARD_CANDIDATE.finditer(text):
            digits = re.sub(r"[ -]", "", m.group())
            if _CARD_PREFIX.match(digits) and luhn_ok(digits):
                found.append(Finding("card_number", *m.span()))
        if self.config.entropy:
            found.extend(self._entropy_findings(text))

        found = [f for f in found if not self._allowed(text[f.start : f.end])]
        found.sort(key=lambda f: (f.start, -(f.end - f.start)))
        result: list[Finding] = []
        for f in found:
            if result and f.start < result[-1].end:
                continue
            result.append(f)
        return result

    def redact(self, text: str) -> str:
        out, pos = [], 0
        for f in self.scan(text):
            out.append(text[pos : f.start])
            out.append(MARKER.format(f.kind))
            pos = f.end
        out.append(text[pos:])
        return "".join(out)

    def _allowed(self, s: str) -> bool:
        return any(rx.search(s) for rx in self._allow)

    def _entropy_findings(self, text: str):
        cfg = self.config
        for m in _TOKEN.finditer(text):
            tok = m.group()
            if len(tok) < cfg.entropy_min_length:
                continue
            # Hex (git SHAs, checksums, UUIDs) and paths are expected and harmless.
            if _HEX.match(tok) or tok.startswith("/") or "//" in tok:
                continue
            # Random tokens mix lower case, upper case and digits; long identifiers usually don't.
            if not (re.search(r"[a-z]", tok) and re.search(r"[A-Z]", tok) and re.search(r"\d", tok)):
                continue
            if shannon_entropy(tok) >= cfg.entropy_threshold:
                yield Finding("high_entropy", *m.span())
