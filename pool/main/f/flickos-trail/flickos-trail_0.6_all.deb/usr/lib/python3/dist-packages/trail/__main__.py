from trail.cli import main

raise SystemExit(main())
