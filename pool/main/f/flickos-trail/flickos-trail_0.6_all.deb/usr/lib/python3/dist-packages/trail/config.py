"""Configuration: built-in defaults, overridden by ~/.config/flickos/trail.toml.

`trail set` changes one value in that file and keeps everything else in it,
comments too (set_value)."""

import dataclasses
import fnmatch
import os
import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

from trail import paths

# Always blocked, whatever the user config says. Matched case-insensitively
# as globs against the window's app ID.
DEFAULT_BLOCKED_APPS = (
    "org.keepassxc.keepassxc",
    "keepassxc",
    "*bitwarden*",
    "*1password*",
    "*pinentry*",
    "gcr-prompter",
    "*polkit*",
    "org.gnome.seahorse*",
    "fuzzel",  # trail's own popup
)

# Globs matched case-insensitively against the window title.
DEFAULT_BLOCKED_TITLES = (
    "*private browsing*",
    "*incognito*",
)

# trail 0.3's continuous capture settings. Read and ignored, so a moved
# config.toml still loads (flickos-trail ADR-002).
OBSOLETE_CAPTURE_KEYS = {"default_interval", "cpu_budget", "intervals"}


class ConfigError(Exception):
    pass


@dataclass(frozen=True)
class CaptureConfig:
    """What `trail snap` refuses to read. The table keeps trail 0.3's name."""

    blocked_apps: tuple[str, ...] = DEFAULT_BLOCKED_APPS
    blocked_titles: tuple[str, ...] = DEFAULT_BLOCKED_TITLES

    def is_blocked(self, app_id: str | None, title: str | None) -> bool:
        app, ttl = (app_id or "").lower(), (title or "").lower()
        return any(fnmatch.fnmatchcase(app, p.lower()) for p in self.blocked_apps) or any(
            fnmatch.fnmatchcase(ttl, p.lower()) for p in self.blocked_titles
        )


@dataclass(frozen=True)
class RedactConfig:
    # Extra patterns: kind -> regex. A named group `secret` limits what is replaced.
    extra: dict[str, str] = field(default_factory=dict)
    # Regexes for strings that must never be redacted (e.g. a known-safe ID format).
    allow: tuple[str, ...] = ()
    entropy: bool = True
    entropy_min_length: int = 32
    entropy_threshold: float = 4.0


@dataclass(frozen=True)
class RetentionConfig:
    """Days to keep each source; 0 keeps it forever (ADR-017)."""

    shell: int = 0
    mark: int = 0
    clip: int = 730
    screen: int = 365
    vectors: int = 365  # embeddings only; their events follow their own source

    def days_for(self, source: str) -> int:
        return getattr(self, source)


@dataclass(frozen=True)
class ArchiveConfig:
    enabled: bool = False
    keep_months: int = 0  # 0 keeps archive files forever


@dataclass(frozen=True)
class SourcesConfig:
    """What is recorded while Trail is on. Shell commands also need the ~/.bashrc line."""

    shell: bool = True
    clipboard: bool = True


@dataclass(frozen=True)
class Config:
    enabled: bool = True  # the switch (ADR-004); `trail set enabled`
    sources: SourcesConfig = field(default_factory=SourcesConfig)
    retention: RetentionConfig = field(default_factory=RetentionConfig)
    archive: ArchiveConfig = field(default_factory=ArchiveConfig)
    capture: CaptureConfig = field(default_factory=CaptureConfig)
    redact: RedactConfig = field(default_factory=RedactConfig)


def load(path: Path | None = None) -> Config:
    path = path or paths.config_file()
    if not path.exists():
        return Config()
    try:
        with path.open("rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(f"{path}: {e}") from e
    return from_dict(data, source=str(path))


def from_dict(data: dict, source: str = "<config>") -> Config:
    def take(table: dict, prefix: str, allowed: set[str]) -> dict:
        unknown = set(table) - allowed
        if unknown:
            keys = ", ".join(sorted(f"{prefix}{k}" for k in unknown))
            raise ConfigError(f"{source}: unknown key(s): {keys}")
        return table

    def typed(value, kind, name):
        # bool is a subclass of int; don't let `true` pass as a number.
        if isinstance(value, bool) and kind is not bool:
            raise ConfigError(f"{source}: {name} must be {kind.__name__}")
        if kind is float and isinstance(value, int):
            return float(value)
        if not isinstance(value, kind):
            raise ConfigError(f"{source}: {name} must be {kind.__name__}")
        return value

    if "retention_days" in data:
        raise ConfigError(f"{source}: retention_days was replaced by a [retention] table with one entry per source")
    top = take(data, "", {"enabled", "sources", "retention", "archive", "capture", "redact"})
    kwargs = {"enabled": typed(top.get("enabled", True), bool, "enabled")}
    src = take(top.get("sources", {}), "sources.", {"shell", "clipboard"})
    kwargs["sources"] = SourcesConfig(
        shell=typed(src.get("shell", SourcesConfig.shell), bool, "sources.shell"),
        clipboard=typed(src.get("clipboard", SourcesConfig.clipboard), bool, "sources.clipboard"),
    )

    def days(value, name):
        value = typed(value, int, name)
        if value < 0:
            raise ConfigError(f"{source}: {name} must be 0 (forever) or more")
        return value

    ret_fields = {f.name for f in dataclasses.fields(RetentionConfig)}
    ret = take(top.get("retention", {}), "retention.", ret_fields)
    rdefaults = RetentionConfig()
    kwargs["retention"] = RetentionConfig(
        **{k: days(ret.get(k, getattr(rdefaults, k)), f"retention.{k}") for k in ret_fields}
    )

    arc = take(top.get("archive", {}), "archive.", {"enabled", "keep_months"})
    adefaults = ArchiveConfig()
    kwargs["archive"] = ArchiveConfig(
        enabled=typed(arc.get("enabled", adefaults.enabled), bool, "archive.enabled"),
        keep_months=days(arc.get("keep_months", adefaults.keep_months), "archive.keep_months"),
    )

    cap = take(top.get("capture", {}), "capture.", {"blocked_apps", "blocked_titles"} | OBSOLETE_CAPTURE_KEYS)
    defaults = CaptureConfig()
    kwargs["capture"] = CaptureConfig(
        # User entries are added to the defaults, never replace them.
        blocked_apps=defaults.blocked_apps + tuple(_str_list(cap.get("blocked_apps", []), "capture.blocked_apps", source)),
        blocked_titles=defaults.blocked_titles + tuple(_str_list(cap.get("blocked_titles", []), "capture.blocked_titles", source)),
    )

    red = take(
        top.get("redact", {}),
        "redact.",
        {"extra", "allow", "entropy", "entropy_min_length", "entropy_threshold"},
    )
    rdef = RedactConfig()
    kwargs["redact"] = RedactConfig(
        extra={k: typed(v, str, f"redact.extra.{k}") for k, v in red.get("extra", {}).items()},
        allow=tuple(_str_list(red.get("allow", []), "redact.allow", source)),
        entropy=typed(red.get("entropy", rdef.entropy), bool, "redact.entropy"),
        entropy_min_length=typed(red.get("entropy_min_length", rdef.entropy_min_length), int, "redact.entropy_min_length"),
        entropy_threshold=typed(red.get("entropy_threshold", rdef.entropy_threshold), float, "redact.entropy_threshold"),
    )
    return Config(**kwargs)


def _str_list(value, name: str, source: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(v, str) for v in value):
        raise ConfigError(f"{source}: {name} must be a list of strings")
    return value


TEMPLATE = """\
# Trail's settings. Every setting is optional; the values shown are the defaults.
# `trail set KEY VALUE|default` changes them for you (trail set --help lists the keys).

# Off: nothing is recorded, and Trail's keys and panel button are gone.
# enabled = true

[sources]
# Record the commands you run in the terminal (they also need the ~/.bashrc line).
# shell = true
# Record copied text.
# clipboard = true

[retention]
# Days to keep each source. 0 = keep forever.
# shell = 0
# mark = 0
# clip = 730
# screen = 365
# Embeddings for meaning-based search (a later version). Older events stay searchable by keyword.
# vectors = 365

[archive]
# Before deleting old rows, append them to ~/.local/share/flickos/trail/archive/YYYY-MM.jsonl.xz.
# Note: archived data stays on disk (unencrypted until database encryption lands).
# enabled = false
# Delete archive files older than this many months. 0 = keep forever.
# keep_months = 0

[capture]
# Extra apps (app ID globs) and window titles (globs) `trail snap` never reads.
# These are added to the built-in list, which covers password managers,
# pinentry, polkit prompts and private browser windows.
# blocked_apps = ["org.example.Secrets"]
# blocked_titles = ["*bank*"]

[redact]
# Turn off the check for long random-looking strings.
# entropy = true
# entropy_min_length = 32
# entropy_threshold = 4.0

# Regexes for strings that must never be redacted.
# allow = ['^build-[0-9a-z]+$']

[redact.extra]
# Extra secret patterns: kind = regex. A named group `secret` limits what is replaced.
# internal_token = 'acme_[A-Za-z0-9]{24}'
"""


def write_template(path: Path | None = None) -> Path:
    path = path or paths.config_file()
    if path.exists():
        raise ConfigError(f"{path} already exists")
    paths.ensure_private_dir(path.parent)
    path.write_text(TEMPLATE)
    return path


# --- trail set ----------------------------------------------------------------------

# Settings `trail set` changes: name -> (table or None for the top, key, type).
# The blocked lists change with `trail blocked` (lists of strings).
SETTABLE = {
    "enabled": (None, "enabled", bool),
    "sources.shell": ("sources", "shell", bool),
    "sources.clipboard": ("sources", "clipboard", bool),
    "retention.shell": ("retention", "shell", int),
    "retention.clip": ("retention", "clip", int),
    "retention.screen": ("retention", "screen", int),
    "retention.mark": ("retention", "mark", int),
    "archive.enabled": ("archive", "enabled", bool),
    "archive.keep_months": ("archive", "keep_months", int),
    "capture.blocked_apps": ("capture", "blocked_apps", list),
    "capture.blocked_titles": ("capture", "blocked_titles", list),
}


def toml_value(value) -> str:
    """bool, int or list of str as TOML. JSON's strings are TOML basic strings."""
    import json

    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    return "[" + ", ".join(json.dumps(v, ensure_ascii=False) for v in value) + "]"


def get(cfg: Config, name: str):
    """A setting's value. For the blocked lists only the user's entries, not
    the built-in ones."""
    table, key, _kind = SETTABLE[name]
    if table == "capture":
        defaults = getattr(CaptureConfig(), key)
        return list(getattr(cfg.capture, key)[len(defaults):])
    return getattr(cfg if table is None else getattr(cfg, table), key)
_TABLE = re.compile(r"^\s*\[\s*([^\]]+?)\s*\]")


def _table_lines(lines: list[str], table: str | None) -> tuple[int, int] | None:
    """[start, end) of the key lines of `table` (None: the top, before the first
    table), or None when the table isn't there."""
    headers = [(i, m.group(1)) for i, line in enumerate(lines) if (m := _TABLE.match(line))]
    if table is None:
        return 0, headers[0][0] if headers else len(lines)
    for n, (i, name) in enumerate(headers):
        if name == table:
            return i + 1, headers[n + 1][0] if n + 1 < len(headers) else len(lines)
    return None


def _bracket_depth(line: str) -> int:
    """[ minus ] outside strings and comments: how far an array is still open."""
    depth, quote = 0, None
    for i, c in enumerate(line):
        if quote:
            if c == quote and (quote == "'" or line[i - 1] != "\\"):
                quote = None
        elif c in "\"'":
            quote = c
        elif c == "#":
            break
        elif c == "[":
            depth += 1
        elif c == "]":
            depth -= 1
    return depth


def set_value(text: str, name: str, value) -> str:
    """`text` (a trail.toml) with one setting changed, or removed for None (the
    default). Comments and everything else are kept. The key goes at the end
    of its table, which is added when missing."""
    table, key, _kind = SETTABLE[name]
    lines = text.splitlines(keepends=True)
    if lines and not lines[-1].endswith("\n"):
        lines[-1] += "\n"
    pattern = re.compile(rf"^\s*{re.escape(key)}\s*=")
    if found := _table_lines(lines, table):
        start, end = found
        kept, depth = [], 0
        for line in lines[start:end]:
            if depth > 0 or pattern.match(line):
                depth = max(0, depth + _bracket_depth(line))  # a multi-line array goes as a whole
                continue
            kept.append(line)
        lines = lines[:start] + kept + lines[end:]
    if value is None:
        return "".join(lines)
    new = f"{key} = {toml_value(value)}\n"
    found = _table_lines(lines, table)
    if found is None:
        gap = "\n" if lines and lines[-1].strip() else ""
        return "".join(lines) + gap + f"[{table}]\n" + new
    start, end = found
    while end > start and not lines[end - 1].strip():
        end -= 1  # before the blank lines that end the table
    lines.insert(end, new + ("\n" if table is None and end < len(lines) and _TABLE.match(lines[end]) else ""))
    return "".join(lines)


def save(name: str, value, path: Path | None = None) -> None:
    """Change one setting in trail.toml, atomically. The result must load."""
    path = path or paths.config_file()
    try:
        text = path.read_text()
    except FileNotFoundError:
        text = ""
    new = set_value(text, name, value)
    try:
        from_dict(tomllib.loads(new), source=str(path))
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(f"{path}: {e}") from e
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}")
    tmp.write_text(new)
    os.replace(tmp, path)
