"""Turn `since:`/`until:` expressions into unix ms, without an LLM (ADR-008).

Understands: now, today, yesterday, weekday names, 30m / 2h / 3d / 1w,
"3 days ago", 2026-09-28, 2026-09-28 14:00, 14:00. Falls back to dateparser
when it is installed (Phase 4 dependency).

A day-sized expression means the start of that day for `since` and the end
of it for `until`, so `until:yesterday` includes all of yesterday.
"""

import re
from datetime import date, datetime, time, timedelta

_UNITS = {
    "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
    "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
    "h": 3600, "hr": 3600, "hrs": 3600, "hour": 3600, "hours": 3600,
    "d": 86400, "day": 86400, "days": 86400,
    "w": 604800, "wk": 604800, "week": 604800, "weeks": 604800,
}
_RELATIVE = re.compile(r"^(\d+)\s*([a-z]+?)(?:\s+ago)?$")
_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def _ms(dt: datetime) -> int:
    return int(dt.timestamp() * 1000)


def _day(d: date, end: bool) -> int:
    start = datetime.combine(d, time.min)
    return _ms(start + timedelta(days=1)) if end else _ms(start)


def parse(expr: str, *, end: bool = False, now: datetime | None = None) -> int:
    """Return unix ms for `expr`, in local time. Raises ValueError if not understood."""
    now = now or datetime.now()
    s = expr.strip().lower().replace("_", " ")
    if not s:
        raise ValueError("empty time")
    if s == "now":
        return _ms(now)
    if s == "today":
        return _day(now.date(), end)
    if s == "yesterday":
        return _day(now.date() - timedelta(days=1), end)
    for i, name in enumerate(_WEEKDAYS):
        if s in (name, name[:3]):
            back = (now.weekday() - i) % 7
            return _day(now.date() - timedelta(days=back), end)
    if m := _RELATIVE.match(s):
        unit = _UNITS.get(m.group(2))
        if unit is None:
            raise ValueError(f"unknown time unit in {expr!r}")
        return _ms(now - timedelta(seconds=int(m.group(1)) * unit))
    if re.fullmatch(r"\d{1,2}:\d{2}", s):
        h, mi = map(int, s.split(":"))
        return _ms(datetime.combine(now.date(), time(h, mi)))
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return _day(date.fromisoformat(s), end)
    try:
        return _ms(datetime.fromisoformat(s))
    except ValueError:
        pass
    try:
        import dateparser  # optional
    except ImportError:
        raise ValueError(f"can't understand time {expr!r}") from None
    dt = dateparser.parse(expr, settings={"RELATIVE_BASE": now, "PREFER_DATES_FROM": "past"})
    if dt is None:
        raise ValueError(f"can't understand time {expr!r}")
    return _ms(dt)
