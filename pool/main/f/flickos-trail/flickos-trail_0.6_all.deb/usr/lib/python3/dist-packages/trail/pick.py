"""`trail pick`: the fuzzel popup (ADR-014)."""

import re
import sqlite3

from trail import db, desktop, search, state

ICONS = {"shell": "$", "clip": "⎘", "mark": "★", "screen": "▭"}
RECENT = 300
MARKED = 30
RESULTS = 100
LINE_TEXT = 140

_URL = re.compile(r"https?://\S+")


def entry(ev: dict) -> str:
    """One fuzzel line: icon, text, then where and when."""
    text = search.flat(ev["text"])
    if len(text) > LINE_TEXT:
        text = text[: LINE_TEXT - 1] + "…"
    bits = [b for b in (search.where_label(ev), search.ago(ev["ts"])) if b]
    if ev.get("n", 1) > 1:
        bits.append(f"×{ev['n']}")
    return f"{ICONS.get(ev['source'], '·')} {text}    {' · '.join(bits)}"


def url_of(ev: dict) -> str | None:
    if ev.get("url"):
        return ev["url"]
    text = (ev.get("text") or "").strip()
    return text if _URL.fullmatch(text) else None


def candidates(conn: sqlite3.Connection, query: str) -> list[dict]:
    """Bookmarks then recent events for an empty query, otherwise search results."""
    if not query.strip():
        marked = search.search(conn, search.Query(marked=True), limit=MARKED)
        seen = {e["id"] for e in marked}
        recent = [e for e in search.search(conn, search.Query(), limit=RECENT) if e["id"] not in seen]
        return marked + recent
    return search.search(conn, search.parse_query(query), limit=RESULTS)


def copy(ev: dict) -> None:
    text = ev["text"]
    # Tell the clipboard watcher to skip this; it is already stored.
    state.mark_picked(db.text_hash(text.rstrip("\n")))
    desktop.copy(text)
    desktop.notify("Copied", search.flat(text)[:120])


def default_action(ev: dict) -> None:
    if ev.get("url"):
        desktop.open_url(ev["url"])
    else:
        copy(ev)


def actions_for(ev: dict) -> list[tuple[str, callable]]:
    out = [("Copy", lambda: copy(ev))]
    if url := url_of(ev):
        out.append(("Open URL", lambda: desktop.open_url(url)))
    if ev.get("cwd"):
        out.append((f"Open terminal in {search.short_path(ev['cwd'])}", lambda: desktop.open_terminal(ev["cwd"])))
    out.append(("Show context (±5 minutes)", None))  # handled by _choose()
    return out


def run(connect, *, with_actions: bool = False) -> int:
    """`connect` opens the database; it is called only after the prompt is shown."""
    query = desktop.fuzzel_prompt("trail › ")
    if query is None:
        return 1
    conn = connect()
    try:
        return _choose(conn, query, with_actions)
    finally:
        conn.close()


def _choose(conn: sqlite3.Connection, query: str, with_actions: bool) -> int:
    try:
        events = candidates(conn, query)
    except search.QueryError as e:
        desktop.notify("trail: bad query", str(e), urgency="normal")
        return 2
    if not events:
        desktop.notify("trail", f"Nothing found for {query!r}")
        return 1
    prompt = f"{query} › " if query.strip() else "recent › "
    i = desktop.fuzzel_choose([entry(e) for e in events], prompt)
    if i is None:
        return 1
    ev = events[i]
    if not with_actions:
        default_action(ev)
        return 0

    actions = actions_for(ev)
    j = desktop.fuzzel_choose([name for name, _ in actions], "action › ")
    if j is None:
        return 1
    name, fn = actions[j]
    if fn is not None:
        fn()
        return 0
    around = search.context(conn, ev)
    k = desktop.fuzzel_choose(
        [("▶ " if e["id"] == ev["id"] else "  ") + entry(e) for e in around], "context › "
    )
    if k is None:
        return 1
    copy(around[k])
    return 0
