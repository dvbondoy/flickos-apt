"""Screen text through OCR, on demand only: `trail snap` (trail ADR-004,
ADR-013, ADR-018).

One grab of the screen, an area or the focused window's output with `grim`
straight into memory, one tesseract run, then the text is stored as a marked
event. Nothing touches the disk: grim writes to a pipe, Pillow works in
memory, and the image goes to tesseract on stdin. trail 0.3's continuous
capture is not part of flickos-trail (its design, section 2).
"""

import io
import os
import re
import subprocess
from dataclasses import dataclass

from PIL import Image, ImageOps, ImageStat

from trail import db
from trail.focus import Window

MIN_WORDS = 3  # less is stored as nothing
TESSERACT = ["tesseract", "stdin", "stdout", "--psm", "11", "-l", "eng", "-c", "tessedit_do_invert=0"]


# --- images --------------------------------------------------------------------

def grab(output: str | None = None, area: str | None = None) -> Image.Image:
    """Screenshot of an area ("X,Y WxH"), one output, or all, as greyscale, in memory only."""
    where = ["-g", area] if area else ["-o", output] if output else []
    cmd = ["grim", "-t", "ppm", *where, "-"]
    raw = subprocess.run(cmd, capture_output=True, check=True, timeout=10).stdout
    return ImageOps.grayscale(Image.open(io.BytesIO(raw)))


def prepare(gray: Image.Image) -> Image.Image:
    """Tesseract reads dark text on a light background best, so invert dark screens."""
    return ImageOps.invert(gray) if ImageStat.Stat(gray).mean[0] < 128 else gray


def ocr(gray: Image.Image) -> str:
    buf = io.BytesIO()
    prepare(gray).save(buf, "PPM")  # PGM for greyscale: no compression work
    env = {**os.environ, "OMP_THREAD_LIMIT": "1"}  # threads cost 2.5× the CPU for the same text
    r = subprocess.run(TESSERACT, input=buf.getvalue(), capture_output=True, env=env, timeout=120)
    if r.returncode != 0:
        raise RuntimeError(f"tesseract failed: {r.stderr.decode(errors='replace').strip()}")
    return r.stdout.decode(errors="replace")


# --- text ----------------------------------------------------------------------

_WORD = re.compile(r"\w{2,}")


def clean(text: str) -> str:
    """Drop OCR lines without a real word and squeeze spaces."""
    lines = []
    for line in text.splitlines():
        line = " ".join(line.split())
        if re.search(r"[A-Za-z0-9]{2,}", line):
            lines.append(line)
    return "\n".join(lines)


def words(text: str) -> set[str]:
    return {w.lower() for w in _WORD.findall(text)}


def cpu_seconds() -> float:
    """CPU used by this process and its finished children (grim, tesseract)."""
    t = os.times()
    return t.user + t.system + t.children_user + t.children_system


# --- on demand: trail snap -------------------------------------------------------------

def select_area() -> str | None:
    """Let the user drag a rectangle with slurp. The area for grab(), or None if cancelled."""
    try:
        r = subprocess.run(["slurp"], stdin=subprocess.DEVNULL, capture_output=True, text=True)
    except FileNotFoundError:
        raise RuntimeError("slurp is not installed (sudo apt install slurp)") from None
    return r.stdout.strip() or None if r.returncode == 0 else None


@dataclass
class Snapped:
    event_id: int | None  # None: too little text to store
    words: int
    cpu: float


def store_snap(conn, redactor, gray: Image.Image, window: Window | None, *, note: str = "",
               area: str | None = None, ocr=ocr, cpu=cpu_seconds, wall_ms=db.now_ms) -> Snapped:
    """Read a screenshot the user asked for and store it as a marked screen event.

    Marked, so it ranks higher in search and retention never deletes it. The
    note, if any, is the first line of the text, so it is searched too.
    """
    cpu0 = cpu()
    text = clean(ocr(gray))
    cost = cpu() - cpu0
    found = words(text)
    if len(found) < MIN_WORDS:
        return Snapped(None, len(found), cost)
    meta = {"trigger": "snap"}
    if area:
        meta["area"] = area
    elif window and len(window.outputs) == 1:
        meta["output"] = window.outputs[0]
    if note:
        text = f"{note}\n\n{text}"
    now = wall_ms()
    eid = db.insert_event(
        conn, redactor, source="screen", method="ocr", text=text, ts=now, ts_end=now,
        app_id=window.app_id or None if window else None, title=window.title or None if window else None,
        bookmarked=True, meta=meta,
    )
    return Snapped(eid, len(found), cost)
