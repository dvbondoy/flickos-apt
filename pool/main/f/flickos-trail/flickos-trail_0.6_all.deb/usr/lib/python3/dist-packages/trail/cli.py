"""The `trail` command."""

import argparse
import dataclasses
import os
import shutil
import sys
from pathlib import Path

from trail import __version__, config, db, paths, search, session, state
from trail.redact import Redactor


def cmd_doctor(args) -> int:
    from trail import doctor

    checks = doctor.run_all()
    color = sys.stdout.isatty()
    marks = {doctor.OK: ("✓", "32"), doctor.WARN: ("!", "33"), doctor.FAIL: ("✗", "31")}
    section = None
    for c in checks:
        if c.section != section:
            section = c.section
            print(f"\n{section}")
        mark, code = marks[c.status]
        if color:
            mark = f"\033[{code}m{mark}\033[0m"
        print(f"  {mark} {c.name:<34} {c.detail}")
        if c.hint and c.status != doctor.OK:
            print(f"    {'':<34} → {c.hint}")
    fails = sum(c.status == doctor.FAIL for c in checks)
    warns = sum(c.status == doctor.WARN for c in checks)
    print(f"\n{fails} failed, {warns} warnings")
    return 1 if fails else 0


def cmd_db_init(args) -> int:
    conn = db.connect()
    print(f"{paths.db_file()} (schema v{db.schema_version(conn)})")
    conn.close()
    return 0


def cmd_db_path(args) -> int:
    print(paths.db_file())
    return 0


def cmd_config_init(args) -> int:
    print(f"wrote {config.write_template()}")
    return 0


def cmd_config_path(args) -> int:
    print(paths.config_file())
    return 0


def cmd_config_show(args) -> int:
    cfg = config.load()
    print(f"# from {paths.config_file()}" + ("" if paths.config_file().exists() else " (not present; defaults)"))
    print(f"enabled = {str(cfg.enabled).lower()}")
    print("\n[sources]")
    print(f"clipboard = {str(cfg.sources.clipboard).lower()}")
    print("\n[retention]")
    for f in dataclasses.fields(cfg.retention):
        print(f"{f.name} = {getattr(cfg.retention, f.name)}")
    print("\n[archive]")
    print(f"enabled = {str(cfg.archive.enabled).lower()}")
    print(f"keep_months = {cfg.archive.keep_months}")
    print("\n[capture]")
    print(f"blocked_apps = {list(cfg.capture.blocked_apps)}")
    print(f"blocked_titles = {list(cfg.capture.blocked_titles)}")
    r = cfg.redact
    print("\n[redact]")
    print(f"entropy = {str(r.entropy).lower()}")
    print(f"entropy_min_length = {r.entropy_min_length}")
    print(f"entropy_threshold = {r.entropy_threshold:g}")
    print(f"allow = {list(r.allow)}")
    print("\n[redact.extra]")
    for k, v in r.extra.items():
        print(f"{k} = {v!r}")
    return 0


def cmd_redact(args) -> int:
    """Filter stdin through the secret remover; handy for testing patterns."""
    redactor = Redactor(config.load().redact)
    text = sys.stdin.read()
    if args.explain:
        for f in redactor.scan(text):
            print(f"{f.kind:<16} {f.start:>6}-{f.end:<6} {text[f.start:f.end]!r}")
    else:
        sys.stdout.write(redactor.redact(text))
    return 0


# --- capture ---------------------------------------------------------------------

def _redactor() -> Redactor:
    return Redactor(config.load().redact)


def _record_errors(fn):
    """Show ingest failures in `trail status` (and the panel) until the next success."""
    try:
        result = fn()
    except Exception as e:
        if state.set_error(f"{type(e).__name__}: {e}"):
            session.signal_panel()
        raise
    if state.clear_error():
        session.signal_panel()
    return result


def _off_message() -> str:
    return "Trail is off (trail set enabled yes)"


def cmd_ingest_shell(args) -> int:
    from trail import ingest

    if paths.shell_off_file().exists() or paths.off_file().exists():
        # Written before terminal commands were turned off (or by a hook that
        # didn't know yet, after an upgrade from 0.4): never stored.
        for spool in paths.runtime_dir().glob(f"{ingest.SPOOL}*"):
            spool.unlink(missing_ok=True)
        return 0
    conn = db.connect()
    n = _record_errors(lambda: ingest.drain_shell_spool(conn, _redactor()))
    conn.close()
    session.maybe_prune()
    if args.verbose:
        print(f"stored {n} commands")
    return 0


def cmd_ingest_clip(args) -> int:
    from trail import ingest

    if paths.off_file().exists():
        return 0  # the watcher is stopped when Trail is turned off; this is a late copy
    clip_state = os.environ.get("CLIPBOARD_STATE")
    data = sys.stdin.buffer.read() if clip_state in (None, "data") else b""
    conn = db.connect()
    outcome = _record_errors(lambda: ingest.ingest_clip(conn, _redactor(), data, clip_state))
    conn.close()
    session.maybe_prune()
    if args.verbose:
        print(outcome)
    return 0


def cmd_import_atuin(args) -> int:
    from trail import ingest

    path = Path(args.db) if args.db else ingest.default_atuin_db()
    if not path.exists():
        print(f"trail: no Atuin database at {path}", file=sys.stderr)
        return 1
    conn = db.connect()
    imported, skipped = ingest.import_atuin(conn, _redactor(), path)
    conn.close()
    print(f"imported {imported} commands, skipped {skipped} (already stored or empty)")
    return 0


def cmd_pause(args) -> int:
    if args.toggle and state.is_paused():
        return _resume(args.quiet)
    return _pause(args.quiet)


def cmd_resume(args) -> int:
    return _resume(args.quiet)


def _pause(quiet: bool) -> int:
    from trail import desktop

    was_running = state.pause()
    session.signal_panel()
    if was_running and not quiet:
        desktop.notify("Trail paused", "Nothing is recorded until you resume.")
    return 0


def _resume(quiet: bool) -> int:
    from trail import desktop

    # Every reason: trail 0.3's idle and lock reasons are gone with idle pausing.
    before = state.is_paused()
    for reason in list(state.pause_reasons()) or ["manual"]:
        state.resume(reason)
    session.signal_panel()
    if before and not quiet:
        desktop.notify("Trail recording", "Recording resumed.")
    return 0


def cmd_status(args) -> int:
    from trail import status

    st = status.current()
    if args.panel:
        print(status.panel_json(st))
    else:
        print("\n".join(status.describe(st)))
    return 0


# --- the switch (ADR-004) -------------------------------------------------------------

YES, NO, DEFAULT = ("yes", "on", "true"), ("no", "off", "false"), ("default",)


def _bool_word(word: str) -> bool | None:
    word = word.lower()
    if word in YES:
        return True
    if word in NO:
        return False
    if word in DEFAULT:
        return None
    raise SystemExit(f"trail: {word!r}: use yes, no or default")


# Settings `trail set` and `get` take; the blocked lists have `trail blocked`.
SCALAR_SETTINGS = tuple(k for k, (_t, _k, kind) in config.SETTABLE.items() if kind is not list)


def _show(value) -> str:
    return ("yes" if value else "no") if isinstance(value, bool) else str(value)


def _parse_value(name: str, word: str):
    """yes|no|default for a switch, a whole number (0 = forever) or default."""
    kind = config.SETTABLE[name][2]
    if kind is bool:
        return _bool_word(word)
    if word.lower() in DEFAULT:
        return None
    try:
        value = int(word)
    except ValueError:
        value = -1
    if value < 0:
        raise SystemExit(f"trail: {word!r}: use a whole number (0 keeps forever) or default")
    return value


def cmd_get(args) -> int:
    """One setting's value, or every setting as KEY<tab>VALUE."""
    cfg = config.load()
    if args.key:
        print(_show(config.get(cfg, args.key)))
        return 0
    for name in SCALAR_SETTINGS:
        print(f"{name}\t{_show(config.get(cfg, name))}")
    return 0


SET_MESSAGES = {
    ("enabled", True): "Trail is on",
    ("enabled", False): "Trail is off: nothing is recorded, and its keys and panel button are gone",
    ("sources.shell", True): "terminal commands are recorded",
    ("sources.shell", False): "terminal commands are not recorded",
    ("sources.clipboard", True): "copied text is recorded",
    ("sources.clipboard", False): "copied text is not recorded",
}


def cmd_set(args) -> int:
    value = _parse_value(args.key, args.value)
    cfg, warnings = session.change(args.key, value)
    for warning in warnings:
        print(f"trail: {warning}", file=sys.stderr)
    now = config.get(cfg, args.key)
    print(SET_MESSAGES.get((args.key, now), f"{args.key} = {_show(now)}"))
    return 0


def cmd_blocked(args) -> int:
    """The apps and window titles `trail snap` never reads: built in, or added."""
    name = "capture.blocked_titles" if args.title else "capture.blocked_apps"
    cfg = config.load()
    added = config.get(cfg, name)
    builtin = list(getattr(config.CaptureConfig(), name.split(".")[1]))
    if args.action == "list":
        kinds = ("app", "title") if args.title is None else (("title",) if args.title else ("app",))
        for kind in kinds:
            key = f"capture.blocked_{kind}s"
            for glob in getattr(config.CaptureConfig(), key.split(".")[1]):
                print(f"{glob}\t{kind}\tbuilt-in")
            for glob in config.get(cfg, key):
                print(f"{glob}\t{kind}\tadded")
        return 0
    glob = (args.glob or "").strip()
    if not glob:
        print("trail: say which app ID or title (a glob like '*bank*')", file=sys.stderr)
        return 2
    if args.action == "add":
        if glob.lower() in (g.lower() for g in builtin + added):
            return 0
        session.change(name, added + [glob])
        return 0
    if glob in builtin:
        print(f"trail: {glob} is built in and can't be removed", file=sys.stderr)
        return 1
    if glob not in added:
        print(f"trail: {glob} isn't in the list", file=sys.stderr)
        return 1
    session.change(name, [g for g in added if g != glob] or None)
    return 0


def cmd_state(args) -> int:
    """Everything the settings window shows, as one JSON object (HIG SET-2)."""
    import json

    print(json.dumps(session.window_state(), ensure_ascii=False))
    return 0


def cmd_settings(args) -> int:
    """The settings window. GTK is loaded only here."""
    from trail import window

    return window.run()


def cmd_clipboard(args) -> int:
    """autostart: the first-login notice, then become the clipboard watcher."""
    cfg = config.load()
    if not cfg.enabled:
        session.sync(cfg)
        return 0
    db.connect().close()  # the panel shows "recording" from the first login
    if state.first_time():
        _welcome()
    return session.run_clipboard()


def _welcome() -> None:
    from trail import desktop

    body = ("Trail keeps the commands you run in the terminal and the text you copy, and the "
            "screen's text when you press Super+`. Everything stays on this computer.\n"
            "Super+S searches it. Super+Shift+P pauses. trail set enabled no turns it off.")
    if (hook := paths.hook_path()) is not None:
        try:
            sourced = str(hook) in (Path.home() / ".bashrc").read_text(errors="replace")
        except OSError:
            sourced = False
        if not sourced:
            body += f"\nTo record terminal commands, add this line to ~/.bashrc:\n{paths.bashrc_line(hook)}"
    desktop.notify("Trail is recording", body, urgency="normal", expire_ms=0)


def cmd_forget(args) -> int:
    """Delete everything Trail recorded: the database, the archive and the spool."""
    from trail import archive

    if not args.all:
        print("trail: say what to forget: --all", file=sys.stderr)
        return 2
    path = paths.db_file()
    count = 0
    if path.exists():
        conn = db.connect()
        count = conn.execute("SELECT count(*) FROM events").fetchone()[0]
        conn.close()
    if not args.yes:
        if not sys.stdin.isatty():
            print("trail: forget --all asks first; add --yes to skip that", file=sys.stderr)
            return 2
        answer = input(f"Delete everything Trail recorded ({count} events and the archive)? Type yes: ")
        if answer.strip().lower() != "yes":
            print("nothing deleted")
            return 1
    with state.locked("shell.lock"):
        for p in (path, path.with_name(path.name + "-wal"), path.with_name(path.name + "-shm")):
            p.unlink(missing_ok=True)
        shutil.rmtree(archive.archive_dir(), ignore_errors=True)
        for spool in paths.runtime_dir().glob("shell.spool*"):
            spool.unlink(missing_ok=True)
    session.signal_panel()
    print(f"deleted {count} events and the archive")
    return 0


def cmd_mark(args) -> int:
    from trail import desktop

    if paths.off_file().exists():
        print(f"trail: {_off_message()}", file=sys.stderr)
        return 1
    note = " ".join(args.note).strip()
    if args.prompt:
        answer = desktop.fuzzel_prompt("mark › ")
        if answer is None:
            return 1
        note = answer.strip()
    conn = db.connect()
    eid = db.insert_event(
        conn, _redactor(), source="mark", method="manual", text=note or "(mark)",
        cwd=os.getcwd() if sys.stdin.isatty() else None, bookmarked=True,
    )
    conn.close()
    session.signal_panel()
    if args.prompt or not sys.stdout.isatty():
        desktop.notify("Marked", note)
    else:
        print(f"marked #{eid}")
    return 0


# --- search ------------------------------------------------------------------------

def _build_query(args) -> search.Query:
    q = search.parse_query(" ".join(args.query))
    for key in ("since", "until", "app"):
        if getattr(args, key):
            search.apply_filter(q, key, getattr(args, key))
    for s in args.source or ():
        search.apply_filter(q, "src", s)
    if args.cwd:
        search.apply_filter(q, "cwd", args.cwd)
    if args.marked:
        q.marked = True
    return q


def cmd_search(args) -> int:
    q = _build_query(args)
    conn = db.connect()
    results = search.search(conn, q, limit=args.limit, order="rank" if args.rank else "time", dedupe=not args.all)
    conn.close()
    session.maybe_prune()
    if args.archive:
        from trail import archive

        results += archive.search_archive(q, limit=args.limit)
    if args.fzf:
        return _fzf(results)
    if args.json:
        for ev in results:
            print(search.to_json(ev))
        return 0
    width = shutil.get_terminal_size().columns if sys.stdout.isatty() else None
    for ev in results:
        print(search.one_line(ev, width))
    return 0 if results else 1


def _fzf(results: list[dict]) -> int:
    import shlex
    import subprocess

    if not shutil.which("fzf"):
        print("trail: fzf is not installed (sudo apt install fzf)", file=sys.stderr)
        return 1
    by_id = {str(e["id"]): e for e in results if not e.get("archived")}
    lines = [f"{e['id']}\t{search.one_line(e)}" for e in results if not e.get("archived")]
    preview = f"{shlex.quote(sys.executable)} -m trail show {{1}}"
    r = subprocess.run(
        ["fzf", "--delimiter=\t", "--with-nth=2..", "--no-sort", "--preview", preview,
         "--preview-window=down,40%,wrap"],
        input="\n".join(lines), stdout=subprocess.PIPE, text=True,
    )
    if r.returncode != 0 or not r.stdout.strip():
        return 1
    print(by_id[r.stdout.split("\t", 1)[0]]["text"])
    return 0


def cmd_show(args) -> int:
    conn = db.connect()
    ev = search.get_event(conn, args.id)
    if ev is None:
        print(f"trail: no event #{args.id}", file=sys.stderr)
        return 1
    if args.context is not None:
        for e in search.context(conn, ev, args.context):
            print(("▶ " if e["id"] == ev["id"] else "  ") + search.one_line(e))
        return 0
    from datetime import datetime

    fields = [
        ("id", ev["id"]),
        ("time", datetime.fromtimestamp(ev["ts"] / 1000).strftime("%Y-%m-%d %H:%M:%S")),
        ("source", ev["source"] + (f" ({ev['method']})" if ev["method"] else "")),
        ("app", ev["app_id"]), ("title", ev["title"]), ("url", ev["url"]),
        ("cwd", search.short_path(ev["cwd"])), ("exit", ev["exit_code"]),
        ("duration", f"{ev['duration_ms']} ms" if ev["duration_ms"] is not None else None),
        ("marked", "yes" if ev["bookmarked"] else None),
    ]
    for name, value in fields:
        if value not in (None, ""):
            print(f"{name:<9}{value}")
    print()
    print(ev["text"])
    return 0


def cmd_pick(args) -> int:
    from trail import pick

    session.maybe_prune()
    return pick.run(db.connect, with_actions=args.actions)


# --- retention ---------------------------------------------------------------------

def cmd_prune(args) -> int:
    from trail import archive

    cfg = config.load()
    conn = db.connect()
    if args.dry_run:
        counts = archive.expired_count(conn, cfg)
        for source, n in counts.items():
            print(f"{source:<7} {n} events past {cfg.retention.days_for(source)} days")
        print("would archive them first" if cfg.archive.enabled else "archive is off: they would be deleted")
        return 0
    result = archive.prune(conn, cfg)
    conn.close()
    total = sum(result.deleted.values())
    detail = ", ".join(f"{s} {n}" for s, n in result.deleted.items()) or "nothing past retention"
    print(f"deleted {total} events ({detail})" + (f", archived {result.archived}" if result.archived else ""))
    if result.archive_files_removed:
        print(f"removed archive files: {', '.join(result.archive_files_removed)}")
    return 0


def cmd_archive_list(args) -> int:
    from trail import archive

    rows = archive.summary()
    if not rows:
        print(f"no archive files in {archive.archive_dir()}")
        return 0
    for month, size, count in rows:
        print(f"{month}  {size / 1024:>9.1f} KiB  {count:>8} events")
    return 0


def cmd_archive_restore(args) -> int:
    from trail import archive

    cfg = config.load()
    conn = db.connect()
    try:
        restored, present = archive.restore(conn, _redactor(), args.month)
    except archive.ArchiveError as e:
        print(f"trail: {e}", file=sys.stderr)
        return 1
    print(f"restored {restored} events ({present} were already in the database)")
    if restored and archive.expired_count(conn, cfg):
        print("note: some are past retention and the next `trail prune` will remove them again; "
              "raise [retention] in the config to keep them")
    conn.close()
    return 0


# --- screen text on demand ------------------------------------------------------

def cmd_snap(args) -> int:
    """Read the screen now and keep the text (ADR-018). Made for a keybinding, so it reports
    with notifications unless run in a terminal."""
    import subprocess

    from trail import desktop, focus, screen

    tty = sys.stdout.isatty()

    def fail(message: str) -> int:
        if tty:
            print(f"trail: {message}", file=sys.stderr)
        else:
            desktop.notify("Not saved", message, urgency="normal")
        return 1

    if paths.off_file().exists():
        return fail(_off_message())
    cfg = config.load()
    try:
        tracker = focus.connect()
        w = tracker.focused
        tracker.close()
    except (focus.WaylandError, OSError) as e:
        return fail(f"can't see the windows: {e}")
    if w is not None and cfg.capture.is_blocked(w.app_id, w.title):
        return fail(f"{w.app_id or 'this window'} is blocked in the config")
    try:
        area = None
        if args.select:
            area = screen.select_area()
            if area is None:
                return 1  # cancelled
        # Grab before anything of trail's own (a note prompt, a notification) is on screen.
        gray = screen.grab(None if area or w is None or len(w.outputs) != 1 else w.outputs[0], area)
    except (RuntimeError, subprocess.SubprocessError, OSError) as e:
        return fail(f"screenshot failed: {e}")
    note = " ".join(args.note).strip()
    if args.prompt:
        answer = desktop.fuzzel_prompt("note › ")
        if answer is None:
            return 1
        note = answer.strip()

    notice = None if tty else desktop.notify_id("Reading screen…")
    conn = db.connect()
    try:
        snapped = screen.store_snap(conn, _redactor(), gray, w, note=note, area=area, ocr=screen.ocr)
    except (RuntimeError, subprocess.SubprocessError, OSError) as e:
        if notice:
            desktop.notify("Not saved", str(e), urgency="normal", replace=notice)
            return 1
        return fail(str(e))
    finally:
        conn.close()
    app = w.app_id if w and w.app_id else "the screen"
    if snapped.event_id is None:
        message = f"found only {snapped.words} words"
        if tty:
            print(f"trail: {message}; nothing saved", file=sys.stderr)
        else:
            desktop.notify("Not saved", message, urgency="normal", replace=notice)
        return 1
    session.signal_panel()
    if tty:
        print(f"saved #{snapped.event_id}: {snapped.words} words from {app} ({snapped.cpu:.1f}s CPU)")
    else:
        desktop.notify("Saved", f"{snapped.words} words from {app}", replace=notice)
    return 0


def cmd_focus(args) -> int:
    from trail import focus

    try:
        if args.watch:
            focus.watch()
            return 0
        tracker = focus.connect()
    except focus.WaylandError as e:
        print(f"trail: {e}", file=sys.stderr)
        return 1
    for w in tracker.windows():
        mark = "*" if tracker.focused and w.handle == tracker.focused.handle else " "
        print(f"{mark} {w.app_id or '?'}\t{w.title}\t[{','.join(w.outputs) or '?'}]")
    tracker.close()
    return 0


def cmd_stats(args) -> int:
    from trail import stats

    conn = db.connect()
    print("\n".join(stats.report(conn)))
    conn.close()
    return 0


def cmd_shell_init(args) -> int:
    hook = paths.hook_path()
    if hook is None:
        print("trail: trail.bash not found", file=sys.stderr)
        return 1
    print(f"# Add to the end of ~/.bashrc:\n{paths.bashrc_line(hook)}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="trail", description="Trail: a searchable memory of what you did.")
    p.add_argument("--version", action="version", version=f"trail {__version__}")
    sub = p.add_subparsers(dest="command", required=True, metavar="COMMAND")

    sub.add_parser("doctor", help="check dependencies and setup").set_defaults(func=cmd_doctor)

    d = sub.add_parser("db", help="database commands").add_subparsers(dest="db_command", required=True, metavar="ACTION")
    d.add_parser("init", help="create or migrate the database").set_defaults(func=cmd_db_init)
    d.add_parser("path", help="print the database path").set_defaults(func=cmd_db_path)

    c = sub.add_parser("config", help="configuration commands").add_subparsers(dest="config_command", required=True, metavar="ACTION")
    c.add_parser("init", help="write a commented config file").set_defaults(func=cmd_config_init)
    c.add_parser("path", help="print the config file path").set_defaults(func=cmd_config_path)
    c.add_parser("show", help="print the effective configuration").set_defaults(func=cmd_config_show)

    r = sub.add_parser("redact", help="remove secrets from stdin")
    r.add_argument("--explain", action="store_true", help="list what would be removed instead")
    r.set_defaults(func=cmd_redact)

    s = sub.add_parser("search", help="search what was recorded")
    s.add_argument("query", nargs="*", help="words, \"phrases\" and filters like src:shell since:yesterday")
    s.add_argument("--since", help="e.g. 2h, yesterday, monday, 2026-09-28")
    s.add_argument("--until")
    s.add_argument("-s", "--source", action="append", help="shell, clip, mark or screen (repeatable)")
    s.add_argument("--app", help="app ID contains this")
    s.add_argument("--cwd", nargs="?", const=".", help="in this directory or below (default: here)")
    s.add_argument("--marked", action="store_true", help="only marked events")
    s.add_argument("-n", "--limit", type=int, default=50)
    s.add_argument("--rank", action="store_true", help="best match first instead of newest first")
    s.add_argument("--all", action="store_true", help="don't merge repeated texts")
    s.add_argument("--archive", action="store_true", help="also search archive files (slow)")
    out = s.add_mutually_exclusive_group()
    out.add_argument("--json", action="store_true", help="one JSON object per line")
    out.add_argument("--fzf", action="store_true", help="choose a result in fzf and print its text")
    s.set_defaults(func=cmd_search)

    sh = sub.add_parser("show", help="show one event in full")
    sh.add_argument("id", type=int)
    sh.add_argument("--context", type=float, nargs="?", const=5, metavar="MINUTES",
                    help="list the events around it instead")
    sh.set_defaults(func=cmd_show)

    pk = sub.add_parser("pick", help="the fuzzel popup")
    pk.add_argument("--actions", action="store_true", help="choose what to do with the result")
    pk.set_defaults(func=cmd_pick)

    m = sub.add_parser("mark", help="bookmark this moment")
    m.add_argument("note", nargs="*")
    m.add_argument("--prompt", action="store_true", help="ask for the note with fuzzel")
    m.set_defaults(func=cmd_mark)

    pa = sub.add_parser("pause", help="stop recording for now")
    pa.add_argument("--toggle", action="store_true", help="resume if paused, otherwise pause")
    pa.add_argument("-q", "--quiet", action="store_true", help="no notification")
    pa.set_defaults(func=cmd_pause)
    re_ = sub.add_parser("resume", help="start recording again")
    re_.add_argument("-q", "--quiet", action="store_true", help="no notification")
    re_.set_defaults(func=cmd_resume)

    st = sub.add_parser("status", help="show whether Trail is recording")
    st.add_argument("--panel", action="store_true", help="print the panel button's JSON (waybar)")
    st.set_defaults(func=cmd_status)

    ge = sub.add_parser("get", help="print one setting, or all of them")
    ge.add_argument("key", nargs="?", choices=SCALAR_SETTINGS, metavar="KEY")
    ge.set_defaults(func=cmd_get)
    se = sub.add_parser("set", help="change a setting: " + ", ".join(SCALAR_SETTINGS))
    se.add_argument("key", choices=SCALAR_SETTINGS, metavar="KEY")
    se.add_argument("value", metavar="yes|no|DAYS|MONTHS|default",
                    help="yes or no for a switch; days (retention.*) or months (archive.keep_months), 0 = forever")
    se.set_defaults(func=cmd_set)

    bl = sub.add_parser("blocked", help="apps and window titles trail snap never reads")
    bl.add_argument("action", choices=("list", "add", "remove"))
    bl.add_argument("glob", nargs="?", help="an app ID or a window title; * matches anything")
    bl.add_argument("--title", action="store_true", default=None, help="a window title, not an app ID")
    bl.set_defaults(func=cmd_blocked)

    sub.add_parser("state", help="everything the settings window shows, as JSON").set_defaults(func=cmd_state)
    sub.add_parser("settings", help="open the settings window").set_defaults(func=cmd_settings)

    cb = sub.add_parser("clipboard", help="record copied text until logout (autostart)")
    cb.set_defaults(func=cmd_clipboard)

    fg = sub.add_parser("forget", help="delete what was recorded")
    fg.add_argument("--all", action="store_true", help="everything: the database and the archive")
    fg.add_argument("--yes", action="store_true", help="don't ask first")
    fg.set_defaults(func=cmd_forget)

    ing = sub.add_parser("ingest", help="store events (used by the shell hook and the clipboard watcher)")
    ing = ing.add_subparsers(dest="ingest_command", required=True, metavar="SOURCE")
    i1 = ing.add_parser("shell", help="drain the shell hook's spool")
    i1.add_argument("-v", "--verbose", action="store_true")
    i1.set_defaults(func=cmd_ingest_shell)
    i2 = ing.add_parser("clip", help="store stdin as a clipboard change (for wl-paste --watch)")
    i2.add_argument("-v", "--verbose", action="store_true")
    i2.set_defaults(func=cmd_ingest_clip)

    im = sub.add_parser("import", help="import history from other tools")
    im = im.add_subparsers(dest="import_command", required=True, metavar="TOOL")
    ia = im.add_parser("atuin", help="import Atuin's shell history")
    ia.add_argument("--db", help="path to Atuin's history.db")
    ia.set_defaults(func=cmd_import_atuin)

    pr = sub.add_parser("prune", help="apply retention (and archive first, if turned on); runs once a day by itself")
    pr.add_argument("--dry-run", action="store_true", help="only count what would go")
    pr.set_defaults(func=cmd_prune)

    ar = sub.add_parser("archive", help="archive files").add_subparsers(dest="archive_command", required=True, metavar="ACTION")
    ar.add_parser("list", help="months, sizes and event counts").set_defaults(func=cmd_archive_list)
    rs = ar.add_parser("restore", help="put a month back into the database")
    rs.add_argument("month", help="YYYY-MM")
    rs.set_defaults(func=cmd_archive_restore)

    sn = sub.add_parser("snap", help="read the screen now and keep its text (for a keybinding)")
    sn.add_argument("note", nargs="*", help="saved as the first line of the text")
    sn.add_argument("--select", action="store_true", help="drag a rectangle to read (slurp)")
    sn.add_argument("--prompt", action="store_true", help="ask for a note with fuzzel")
    sn.set_defaults(func=cmd_snap)

    fo = sub.add_parser("focus", help="list windows, * marks the focused one")
    fo.add_argument("--watch", action="store_true", help="print every focus or title change")
    fo.set_defaults(func=cmd_focus)

    sa = sub.add_parser("stats", help="statistics")
    sa.add_argument("--storage", action="store_true", required=True, help="size and growth per source")
    sa.set_defaults(func=cmd_stats)

    si = sub.add_parser("shell", help="shell integration").add_subparsers(dest="shell_command", required=True, metavar="ACTION")
    si.add_parser("init", help="print the line to add to ~/.bashrc").set_defaults(func=cmd_shell_init)
    return p


def _migrate() -> None:
    """trail 0.3's files move once (ADR-002), and the user is told once."""
    try:
        moved = paths.migrate()
    except OSError as e:
        print(f"trail: could not move trail 0.3's files: {e}", file=sys.stderr)
        return
    if moved:
        from trail import desktop

        message = "Moved trail 0.3's files: " + "; ".join(moved)
        print(f"trail: {message}", file=sys.stderr)
        desktop.notify("Trail", message, urgency="normal")


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    _migrate()
    try:
        return args.func(args)
    except config.ConfigError as e:
        print(f"trail: config error: {e}", file=sys.stderr)
        return 2
    except search.QueryError as e:
        print(f"trail: {e}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130
