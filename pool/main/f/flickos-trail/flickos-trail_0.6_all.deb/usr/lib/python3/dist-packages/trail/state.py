"""Runtime state in $XDG_RUNTIME_DIR/flickos/trail: pause reasons, the last
error, the pick marker, the clipboard watcher's PID. Kept across logins in
$XDG_STATE_HOME/flickos/trail: the first-login marker and the last prune's date.

The bash hook only checks whether `paused` exists, so that file exists exactly
while at least one pause reason is set.
"""

import contextlib
import fcntl
import json
import os
import time
from datetime import date
from pathlib import Path

from trail import paths

PAUSED = "paused"
ERROR = "error"
PICKED = "picked"
CLIPBOARD_PID = "clipboard.pid"
# In state_dir():
WELCOMED = "welcomed"  # the first-login notice was shown (ADR-004)
PRUNED = "pruned"  # the date retention last ran (ADR-006)

# How long a text copied by `trail pick` is ignored by the clipboard watcher.
PICK_IGNORE_SECONDS = 10


def _dir() -> Path:
    return paths.ensure_private_dir(paths.runtime_dir())


@contextlib.contextmanager
def locked(name: str = "state.lock"):
    fd = os.open(_dir() / name, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)


def _write_json(path: Path, data) -> None:
    tmp = path.with_name(f".{path.name}.{os.getpid()}")
    fd = os.open(tmp, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, ValueError):
        return default


def pause_reasons() -> dict[str, int]:
    """Reason -> unix ms when it was set."""
    return _read_json(paths.runtime_dir() / PAUSED, {})


def is_paused() -> bool:
    return (paths.runtime_dir() / PAUSED).exists()


def pause(reason: str = "manual") -> bool:
    """Returns True if capture was running before."""
    with locked():
        reasons = pause_reasons()
        was_running = not reasons
        reasons.setdefault(reason, time.time_ns() // 1_000_000)
        _write_json(_dir() / PAUSED, reasons)
    return was_running


def resume(reason: str = "manual") -> bool:
    """Clears one reason. Returns True if capture is running afterwards."""
    with locked():
        reasons = pause_reasons()
        reasons.pop(reason, None)
        path = _dir() / PAUSED
        if reasons:
            _write_json(path, reasons)
        else:
            path.unlink(missing_ok=True)
    return not reasons


def set_error(message: str) -> bool:
    """Returns True if there was no error before (the panel shows the change)."""
    was = (paths.runtime_dir() / ERROR).exists()
    _write_json(_dir() / ERROR, {"message": message, "ts": time.time_ns() // 1_000_000})
    return not was


def clear_error() -> bool:
    """Returns True if there was an error."""
    try:
        (paths.runtime_dir() / ERROR).unlink()
    except FileNotFoundError:
        return False
    return True


def last_error() -> str | None:
    return _read_json(paths.runtime_dir() / ERROR, {}).get("message")


def mark_picked(text_hash: str) -> None:
    """Remember what `trail pick` just copied so the clipboard watcher skips it."""
    _write_json(_dir() / PICKED, {"hash": text_hash, "ts": time.time()})


def take_picked(text_hash: str) -> bool:
    """True (and forget the marker) if `text_hash` is what pick copied moments ago."""
    path = paths.runtime_dir() / PICKED
    data = _read_json(path, {})
    if data.get("hash") == text_hash and time.time() - data.get("ts", 0) < PICK_IGNORE_SECONDS:
        path.unlink(missing_ok=True)
        return True
    return False


# --- kept across logins ------------------------------------------------------------

def first_time(name: str = WELCOMED) -> bool:
    """True once: creates the marker `name` in the state dir."""
    try:
        fd = os.open(paths.ensure_private_dir(paths.state_dir()) / name, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        return False
    os.close(fd)
    return True


def prune_due(today: date | None = None) -> bool:
    """True for the first call of the day, which records the day."""
    today = (today or date.today()).isoformat()
    path = paths.state_dir() / PRUNED
    try:
        if path.read_text().strip() == today:
            return False
    except FileNotFoundError:
        pass
    paths.ensure_private_dir(path.parent)
    tmp = path.with_name(f".{PRUNED}.{os.getpid()}")
    tmp.write_text(today + "\n")
    os.replace(tmp, path)
    return True
