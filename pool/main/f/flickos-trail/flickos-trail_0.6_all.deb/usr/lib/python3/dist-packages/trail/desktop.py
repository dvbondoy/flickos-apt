"""Thin wrappers around the desktop tools Trail drives: fuzzel, wl-copy, notify-send, xdg-open."""

import os
import shutil
import subprocess

FUZZEL_WIDTH = 100
FUZZEL_LINES = 15


def _notify_cmd(summary: str, body: str, urgency: str, expire_ms: int, replace: int | None) -> list[str]:
    cmd = ["notify-send", "--app-name=Trail", f"--urgency={urgency}", f"--expire-time={expire_ms}"]
    if replace:
        cmd.append(f"--replace-id={replace}")
    return cmd + [summary, body]


def notify(summary: str, body: str = "", *, urgency: str = "low", replace: int | None = None,
           expire_ms: int = 3000) -> None:
    """Best effort: never fails and never waits. `replace` updates a notification
    from notify_id(); `expire_ms` 0 keeps it until clicked."""
    if not shutil.which("notify-send"):
        return
    try:
        subprocess.Popen(
            _notify_cmd(summary, body, urgency, expire_ms, replace),
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError:
        pass


def notify_id(summary: str, body: str = "") -> int | None:
    """A notification that stays up until replaced. Waits briefly for its ID; None if that fails."""
    if not shutil.which("notify-send"):
        return None
    try:
        r = subprocess.run(
            _notify_cmd(summary, body, "low", 30000, None) + ["--print-id"],
            stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=2,
        )
        return int(r.stdout.strip())
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return None


def fuzzel_prompt(prompt: str) -> str | None:
    """Ask for one line of text. None if cancelled."""
    try:
        r = subprocess.run(
            ["fuzzel", "--dmenu", f"--prompt-only={prompt}", f"--width={FUZZEL_WIDTH}"],
            stdin=subprocess.DEVNULL, capture_output=True, text=True,
        )
    except FileNotFoundError:
        raise SystemExit("trail: fuzzel is not installed (sudo apt install fuzzel)") from None
    if r.returncode != 0:
        return None
    return r.stdout.rstrip("\n")


def fuzzel_choose(lines: list[str], prompt: str) -> int | None:
    """Show `lines` and return the chosen index. None if cancelled or nothing matched."""
    if not lines:
        return None
    try:
        r = subprocess.run(
            ["fuzzel", "--dmenu", "--index", f"--prompt={prompt}", f"--width={FUZZEL_WIDTH}",
             f"--lines={min(FUZZEL_LINES, len(lines))}", "--no-sort"],
            input="\n".join(lines) + "\n", capture_output=True, text=True,
        )
    except FileNotFoundError:
        raise SystemExit("trail: fuzzel is not installed (sudo apt install fuzzel)") from None
    if r.returncode != 0:
        return None
    try:
        index = int(r.stdout.strip())
    except ValueError:
        return None
    return index if 0 <= index < len(lines) else None


def copy(text: str) -> None:
    # wl-copy forks to keep serving the clipboard, so this returns at once.
    subprocess.run(["wl-copy"], input=text.encode(), check=True)


def _spawn(argv: list[str], cwd: str | None = None) -> None:
    subprocess.Popen(
        argv, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL, start_new_session=True,
    )


def open_url(url: str) -> None:
    _spawn(["xdg-open", url])


def open_terminal(cwd: str) -> None:
    terminal = os.environ.get("TERMINAL") or "x-terminal-emulator"
    _spawn([terminal], cwd=cwd)
