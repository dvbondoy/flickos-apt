"""Getting events in: the shell spool, the clipboard, and an Atuin import."""

import os
import sqlite3
import time
from pathlib import Path

from trail import db, paths, state
from trail.redact import Redactor

# --- shell (ADR-003) -----------------------------------------------------------
#
# trail.bash appends one record per command to $XDG_RUNTIME_DIR/trail/shell.spool
# using only bash builtins, then starts `trail ingest shell` in the background.
# A record is five fields separated by \x1f and ended by \x1e:
#   start_ms, duration_ms, exit_code, cwd, command
# The hook strips \x1e and \x1f from the command, so they never occur in data.

FIELD, RECORD = "\x1f", "\x1e"
SPOOL = "shell.spool"


def parse_spool(data: str) -> tuple[list[dict], int]:
    """Parse spool text into events. Returns (events, number of malformed records)."""
    events, bad = [], 0
    chunks = data.split(RECORD)
    # Anything after the last separator is an unfinished write; count it as bad.
    tail = chunks.pop()
    if tail.strip():
        bad += 1
    for chunk in chunks:
        parts = chunk.split(FIELD)
        if len(parts) != 5:
            bad += 1
            continue
        start, duration, exit_code, cwd, cmd = parts
        cmd = cmd.strip()
        try:
            ts = int(start)
            dur = int(duration)
            code = int(exit_code)
        except ValueError:
            bad += 1
            continue
        if not cmd:
            continue
        events.append({"ts": ts, "duration_ms": dur, "exit_code": code, "cwd": cwd or None, "text": cmd})
    return events, bad


def drain_shell_spool(conn: sqlite3.Connection, redactor: Redactor) -> int:
    """Move everything in the spool into the database. Safe to run concurrently."""
    run = paths.ensure_private_dir(paths.runtime_dir())
    stored = 0
    with state.locked("shell.lock"):
        spool = run / SPOOL
        if spool.exists():
            # New hook writes go to a fresh spool while we work on this one.
            spool.rename(run / f"{SPOOL}.{time.time_ns()}")
        for f in sorted(run.glob(f"{SPOOL}.*")):
            events, _bad = parse_spool(f.read_text(errors="replace"))
            conn.execute("BEGIN IMMEDIATE")
            try:
                for ev in events:
                    db.insert_event(
                        conn, redactor, source="shell", method="hook",
                        ts_end=ev["ts"] + ev["duration_ms"], **ev,
                    )
                conn.execute("COMMIT")
            except BaseException:
                conn.execute("ROLLBACK")
                raise
            f.unlink()
            stored += len(events)
    return stored


# --- clipboard -------------------------------------------------------------------

CLIP_MAX_BYTES = 64 * 1024  # longer text is cut to this size


def ingest_clip(conn: sqlite3.Connection, redactor: Redactor, data: bytes, clipboard_state: str | None) -> str:
    """Store one clipboard change. Returns what happened, for logging and tests.

    Run by `wl-paste --type text --watch trail ingest clip`, which sets
    CLIPBOARD_STATE. "sensitive" is what password managers mark with
    x-kde-passwordManagerHint; those are dropped without being read.
    """
    if clipboard_state not in (None, "data"):
        return f"skipped: {clipboard_state}"
    if state.is_paused():
        return "skipped: paused"
    truncated = len(data) > CLIP_MAX_BYTES
    if truncated:
        data = data[:CLIP_MAX_BYTES]
    try:
        text = data.decode("utf-8", errors="strict" if not truncated else "ignore")
    except UnicodeDecodeError:
        return "skipped: not text"
    if "\0" in text:
        return "skipped: not text"
    text = text.rstrip("\n")
    if not text.strip():
        return "skipped: empty"
    if state.take_picked(db.text_hash(text)):
        return "skipped: copied by trail pick"
    clean = redactor.redact(text)
    last = conn.execute(
        "SELECT text_hash FROM events WHERE source = 'clip' ORDER BY id DESC LIMIT 1"
    ).fetchone()
    if last and last[0] == db.text_hash(clean):
        return "skipped: same as last"
    db.insert_event(
        conn, redactor, source="clip", method="wl-paste", text=text,
        meta={"truncated": True} if truncated else None,
    )
    return "stored"


# --- Atuin -------------------------------------------------------------------------

def default_atuin_db() -> Path:
    base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return Path(base) / "atuin" / "history.db"


def import_atuin(conn: sqlite3.Connection, redactor: Redactor, path: Path) -> tuple[int, int]:
    """Copy Atuin's history in. Returns (imported, skipped).

    Safe to repeat: a command already stored within 2 s of the same time,
    by an earlier import or by the hook, is skipped.
    """
    src = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        rows = src.execute(
            "SELECT timestamp, duration, exit, command, cwd FROM history "
            "WHERE deleted_at IS NULL ORDER BY timestamp"
        ).fetchall()
    finally:
        src.close()
    imported = skipped = 0
    conn.execute("BEGIN IMMEDIATE")
    try:
        for ts_ns, dur_ns, code, cmd, cwd in rows:
            cmd = (cmd or "").strip()
            if not cmd:
                skipped += 1
                continue
            ts = ts_ns // 1_000_000
            h = db.text_hash(redactor.redact(cmd))
            dup = conn.execute(
                "SELECT 1 FROM events WHERE source = 'shell' AND ts BETWEEN ? AND ? AND text_hash = ? LIMIT 1",
                (ts - 2000, ts + 2000, h),
            ).fetchone()
            if dup:
                skipped += 1
                continue
            dur = dur_ns // 1_000_000 if dur_ns is not None and dur_ns >= 0 else None
            db.insert_event(
                conn, redactor, source="shell", method="atuin", text=cmd, ts=ts,
                ts_end=ts + dur if dur is not None else None, duration_ms=dur,
                exit_code=code if code is not None and code >= 0 else None,
                cwd=cwd if cwd and cwd != "unknown" else None,
            )
            imported += 1
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    return imported, skipped
