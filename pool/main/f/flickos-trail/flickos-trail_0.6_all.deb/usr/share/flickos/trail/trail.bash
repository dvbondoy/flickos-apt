# Trail's shell hook (trail ADR-003). Add to the end of ~/.bashrc:
#
#   [[ -r /usr/share/flickos/trail/trail.bash ]] && source /usr/share/flickos/trail/trail.bash
#
# For each command it appends one record to $XDG_RUNTIME_DIR/flickos/trail/shell.spool
# using only bash builtins, then starts `trail ingest shell` in the background,
# so the prompt never waits for Python or the database.
#
# Not recorded: commands starting with a space (like HISTCONTROL=ignorespace),
# anything run while Trail is paused, and anything while it is turned off
# (~/.config/flickos/trail-shell.off exists while Trail or terminal commands
# are turned off: one file test per command).
#
# Settings (set before sourcing):
#   TRAIL_BIN            the trail command (default: trail)
#   TRAIL_BASH_PREEXEC   path to bash-preexec.sh, if it isn't loaded already

[[ $- == *i* ]] || return 0
[[ -n ${__trail_loaded:-} ]] && return 0
__trail_loaded=1

if [[ -z ${bash_preexec_imported:-}${__bp_imported:-} ]]; then
  for __trail_bp in "${TRAIL_BASH_PREEXEC:-}" ~/.bash-preexec.sh \
    "${BASH_SOURCE[0]%/*}/bash-preexec.sh" /usr/share/flickos/trail/bash-preexec.sh; do
    if [[ -n $__trail_bp && -r $__trail_bp ]]; then
      # shellcheck disable=SC1090
      source "$__trail_bp"
      break
    fi
  done
  unset __trail_bp
fi
if [[ -z ${bash_preexec_imported:-}${__bp_imported:-} ]]; then
  echo "trail: bash-preexec not found, so commands are not recorded" >&2
  return 0
fi

# The same places as trail's paths.py: relative XDG paths are ignored.
if [[ -n ${XDG_RUNTIME_DIR:-} && ${XDG_RUNTIME_DIR} == /* ]]; then
  __trail_dir=$XDG_RUNTIME_DIR/flickos/trail
else
  __trail_dir=/tmp/flickos-trail-$UID
fi
if [[ -n ${XDG_CONFIG_HOME:-} && ${XDG_CONFIG_HOME} == /* ]]; then
  __trail_off=$XDG_CONFIG_HOME/flickos/trail-shell.off
else
  __trail_off=$HOME/.config/flickos/trail-shell.off
fi
__trail_start=

__trail_preexec() {
  __trail_cmd=$1
  __trail_cwd=$PWD # before the command runs, so `cd` is recorded where it was typed
  __trail_start=$EPOCHREALTIME
}

__trail_precmd() {
  local code=$? start=$__trail_start cmd=${__trail_cmd:-} end=$EPOCHREALTIME
  __trail_start=
  [[ -n $start ]] || return 0 # empty prompt, Ctrl-C, etc.
  [[ -e $__trail_off ]] && return 0 # Trail or terminal commands are off
  [[ $cmd == ' '* ]] && return 0
  [[ -e $__trail_dir/paused ]] && return 0
  # EPOCHREALTIME is "seconds.microseconds"; the separator follows the locale.
  local s=${start//[.,]/} e=${end//[.,]/}
  cmd=${cmd//[$'\x1e\x1f']/}
  [[ -d $__trail_dir ]] || mkdir -p -m 700 "$__trail_dir" 2>/dev/null || return 0
  printf '%s\x1f%s\x1f%s\x1f%s\x1f%s\x1e' \
    "$((10#$s / 1000))" "$(((10#$e - 10#$s) / 1000))" "$code" "$__trail_cwd" "$cmd" \
    >>"$__trail_dir/shell.spool" 2>/dev/null || return 0
  ("${TRAIL_BIN:-trail}" ingest shell </dev/null >/dev/null 2>&1 &)
}

preexec_functions+=(__trail_preexec)
precmd_functions+=(__trail_precmd)
