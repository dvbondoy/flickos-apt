# Trail (flickos-trail)

An app for FlickOS: a searchable memory of what you did. It keeps
the commands you run in the terminal, the text you copy and, when you press
a key, the text on the screen (OCR). Secrets are removed before anything is
stored, everything stays in one SQLite database on the computer, and Super+S
finds it again. Proprietary, so it lives here and not under FlickOS's `packages/`
(ADR-001). Free of charge until the FlickOS store opens: FlickOS's
`repo/publish.sh` builds it from this folder and publishes it to the public
apt repo (FlickOS's `docs/design/flickos-store.md`, ADR-008).

Design, decisions and phases: FlickOS's `docs/design/flickos-trail.md`.
This was trail 0.3, a separate project (`../trail`); its own plan and README
are kept in `docs/` as the history of its decisions (*trail ADR-n*).

| Phase | State |
|---|---|
| 0 Spikes | done 2026-10-04 (the design's *Phase 0 results*) |
| 1 The move | done 2026-10-04 (0.4), installed on the maintainer's computer |
| 2 The settings window | built 2026-10-04 (0.5); tried with temporary folders, not yet installed |
| 3 Release through the store | waits for the store |

## What is where

- `src/trail/`: the program, a Python package (an exception to FlickOS's
  one-file rule, ADR-003). `cli.py` is the command; `session.py` is what
  runs in the desktop session (the switch, the clipboard watcher, the
  panel signal, the daily prune).
- `src/trail/window.py`: the settings window (*Trail* in the apps menu,
  `trail settings`), GTK 3, loaded by nothing else. It owns no settings:
  every control runs a `trail` command and reads `trail state` back.
- `usr/share/applications/flickos-trail.desktop`: *Trail* in the apps menu.
- `usr/share/flickos/trail/trail.bash`: the shell hook. `~/.bashrc` needs
  `[[ -r /usr/share/flickos/trail/trail.bash ]] && source /usr/share/flickos/trail/trail.bash`.
  `bash-preexec.sh` next to it is Ryan Caloras' (Expat).
- `usr/share/flickos/addons/flickos-trail/`: keys, panel button and its
  style, a flickos-layouts add-on (ADR-005).
- `etc/xdg/autostart/flickos-trail.desktop`: `trail clipboard` at login,
  which becomes `wl-paste --watch` while Trail is on and ends at once while
  it is off (ADR-006).
- `tests/`: pytest. Every XDG folder points into a temporary folder, and
  there is no Wayland session, no `/proc`, no flickos-layout, no
  notifications and no children, so the tests never touch your history,
  settings or desktop.

## What runs

Only wl-clipboard's watcher (`wl-paste --type text --watch trail ingest
clip`), asleep until a copy. Everything else runs when you do something:
`trail ingest shell` after each command (in the background), `trail ingest
clip` per copy, `trail prune` once a day, `trail status --panel` when the
panel is told something changed, and the commands behind the keys.

## Build and test

```sh
PYTHONPATH=src python3 -m pytest -q -p no:cacheprovider   # the tests alone
# the package, built in a copy so no build output lands here:
rm -rf /tmp/ft && rsync -a --exclude .git ./ /tmp/ft/ && (cd /tmp/ft && dpkg-buildpackage -us -uc -b)
lintian /tmp/flickos-trail_*.deb
```

## Moving from trail 0.3

1. Delete trail 0.3's experimental add-on, `~/.config/flickos/addons/trail/`,
   and its autostart entry, `~/.config/autostart/trail.desktop`, if they are
   still there: the add-on binds the same keys to the old commands, and the
   entry starts the old units. `trail doctor` reports both.
2. `systemctl --user disable --now trail.target trail-prune.timer` if trail
   0.3 is still installed.
3. `sudo apt install /tmp/flickos-trail_0.4_all.deb` (it replaces trail).
4. In `~/.bashrc`, change `/usr/share/trail/trail.bash` to
   `/usr/share/flickos/trail/trail.bash` (twice on the line).
5. Log out and in, or run `trail clipboard &` once. The first `trail`
   command moves `~/.local/share/trail/` and `~/.config/trail/config.toml`
   to the new places and says so. `trail doctor` checks everything.
