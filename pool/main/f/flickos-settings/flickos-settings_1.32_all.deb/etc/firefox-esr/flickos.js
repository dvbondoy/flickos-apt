// FlickOS defaults for Firefox. Debian's firefox-esr reads every .js file in
// /etc/firefox-esr/ as default prefs, so a choice you make in Firefox's
// settings or about:config still wins.

// Vertical tabs (Settings > General > Browser layout).
pref("sidebar.revamp", true);
pref("sidebar.verticalTabs", true);
