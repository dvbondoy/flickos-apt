# Start the FlickOS labwc session on tty1 login (live session and installed
# system alike). Other ttys and SSH logins get a plain shell.
if [ -z "${WAYLAND_DISPLAY:-}" ] && [ "$(tty)" = "/dev/tty1" ]; then
    # FlickOS defaults in /etc/xdg/flickos and /usr/share/flickos take priority
    # over Debian's defaults. User config in ~/.config still wins.
    XDG_CONFIG_DIRS="/etc/xdg/flickos:${XDG_CONFIG_DIRS:-/etc/xdg}"
    XDG_DATA_DIRS="/usr/share/flickos:${XDG_DATA_DIRS:-/usr/local/share:/usr/share}"

    # Live session only: flickos-installer adds a menu with "Install FlickOS".
    # The installer removes that package, so installed systems never see it.
    if [ -d /etc/xdg/flickos-live ]; then
        XDG_CONFIG_DIRS="/etc/xdg/flickos-live:$XDG_CONFIG_DIRS"
    fi

    # Desktop layout (flickos-layouts): files generated for this login in
    # $XDG_RUNTIME_DIR/flickos/xdg (e.g. rc.xml with the layout's window
    # buttons) come first. The folder is added even when empty, so
    # `flickos-layout set` can apply a layout without logging out.
    if command -v flickos-layout >/dev/null && [ -n "${XDG_RUNTIME_DIR:-}" ]; then
        if timeout 10 flickos-layout prepare; then
            XDG_CONFIG_DIRS="$XDG_RUNTIME_DIR/flickos/xdg:$XDG_CONFIG_DIRS"
        fi
    fi
    export XDG_CONFIG_DIRS XDG_DATA_DIRS

    # labwc ignores the system keyboard layout; pass it on explicitly.
    # /etc/default/keyboard is written by the installer and by live-config.
    if [ -r /etc/default/keyboard ]; then
        XKB_DEFAULT_MODEL="$(. /etc/default/keyboard; echo "${XKBMODEL:-}")"
        XKB_DEFAULT_LAYOUT="$(. /etc/default/keyboard; echo "${XKBLAYOUT:-}")"
        XKB_DEFAULT_VARIANT="$(. /etc/default/keyboard; echo "${XKBVARIANT:-}")"
        XKB_DEFAULT_OPTIONS="$(. /etc/default/keyboard; echo "${XKBOPTIONS:-}")"
        export XKB_DEFAULT_MODEL XKB_DEFAULT_LAYOUT XKB_DEFAULT_VARIANT XKB_DEFAULT_OPTIONS
    fi

    exec labwc
fi
