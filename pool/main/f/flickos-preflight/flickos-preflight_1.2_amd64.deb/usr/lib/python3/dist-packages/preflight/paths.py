"""XDG locations, in FlickOS's places, and the bundled tgpt. Read from the
environment on every call so tests can override them."""

import os
import shutil
from pathlib import Path

APP = "preflight"
OLD_APP = "turd-buster"  # the name up to 1.1; its settings file is moved once
VENDOR = "flickos"
# The package installs its own pinned tgpt here (HIG PKG-2: FlickOS paths only).
BUNDLED_TGPT = Path("/usr/libexec/flickos/preflight/tgpt")


class PathError(Exception):
    pass


def _xdg(var, fallback):
    value = os.environ.get(var)
    # The XDG spec says relative paths must be ignored.
    if value and os.path.isabs(value):
        return Path(value)
    return Path.home() / fallback


def config_dir():
    """~/.config/flickos: the user's preflight.conf lives here."""
    return _xdg("XDG_CONFIG_HOME", ".config") / VENDOR


def config_file():
    return config_dir() / f"{APP}.conf"


def old_config_file():
    return config_dir() / f"{OLD_APP}.conf"


def system_config_file():
    """The packaged defaults. PREFLIGHT_SYSTEM_CONF replaces the path in tests;
    an empty value means there is no system file."""
    override = os.environ.get("PREFLIGHT_SYSTEM_CONF")
    if override is not None:
        return Path(override) if override else None
    installed = Path("/etc/xdg/flickos") / f"{APP}.conf"
    if installed.is_file():
        return installed
    # Running from a checkout, before the package is installed.
    nearby = Path(__file__).resolve().parents[2] / "etc" / "xdg" / "flickos" / f"{APP}.conf"
    if nearby.is_file():
        return nearby
    return None


def tgpt():
    """The tgpt to run, or None. PREFLIGHT_TGPT replaces it in tests (empty: none).
    From a checkout, before the package is installed, the one on PATH."""
    override = os.environ.get("PREFLIGHT_TGPT")
    if override is not None:
        return override or None
    if os.access(BUNDLED_TGPT, os.X_OK):
        return str(BUNDLED_TGPT)
    return shutil.which("tgpt")


def runtime_dir():
    """$XDG_RUNTIME_DIR/flickos, where the window's lock lives (HIG CODE-8)."""
    base = os.environ.get("XDG_RUNTIME_DIR")
    if not base or not os.path.isabs(base):
        raise PathError("XDG_RUNTIME_DIR is not set, so the window cannot make sure it is open only once.")
    return Path(base) / VENDOR


def ensure_private_dir(path):
    """Create `path` (and parents) so only the owner can enter it."""
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.stat().st_mode & 0o077:
        path.chmod(0o700)
    return path


def write_atomic(path, text):
    """Write `text` then rename it into place, so a reader never sees half a file."""
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    tmp = path.with_name(f".{path.name}.tmp")
    tmp.write_text(text)
    os.replace(tmp, path)
