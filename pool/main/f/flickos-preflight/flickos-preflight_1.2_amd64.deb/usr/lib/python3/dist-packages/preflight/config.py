"""The settings: where the check runs, the local model, the time limit, and
whether the post is signed.

Built-in defaults, then /etc/xdg/flickos/preflight.conf, then
~/.config/flickos/preflight.conf. The user file is written only when a
setting changes. Absent means the default. A file that cannot be read is
ignored.

Up to 1.1 the app was Turd Buster, and the user file was turd-buster.conf
with a [TurdBuster] section. The first read moves it to preflight.conf.
"""

import configparser
import sys

from preflight import paths

# Keys the window and `preflight set` share. The system conf repeats these.
DEFAULTS = {
    "provider": "opencode",  # opencode (online, through tgpt) or ollama (this computer)
    "model": "llama3.2",     # an Ollama model; used only when provider is ollama
    "timeout": "120",        # seconds one model call may take, cold-loading a local model included
    "sign_off": "no",        # yes adds "Checked by Preflight using …" to the post
}
PROVIDERS = ("opencode", "ollama")
TIMEOUT_RANGE = (10, 3600)
YES_NO = ("yes", "no")
SECTION = "Preflight"
OLD_SECTION = "TurdBuster"
HEADER = (
    "# Preflight (flickos-preflight) writes this file when a setting changes.\n"
    "# Change it here, in the window, or with `preflight set KEY VALUE|default`.\n"
    "# Delete the file to go back to the defaults.\n\n"
)


class ConfigError(Exception):
    pass


def load():
    """The settings in effect: built-in, then system, then the user file."""
    _migrate()
    values = dict(DEFAULTS)
    for path, label in ((paths.system_config_file(), "system"), (paths.config_file(), "user")):
        parsed = _read(path, label)
        if parsed:
            values.update(parsed)
    return values


def get(key):
    if key not in DEFAULTS:
        raise ConfigError(f"Unknown setting {key}.")
    return load()[key]


def timeout():
    return int(get("timeout"))


def signs():
    return get("sign_off") == "yes"


def set_value(key, value):
    """Store one user choice. `default` removes it so the system value applies."""
    if key not in DEFAULTS:
        raise ConfigError(f"Unknown setting {key}.")
    chosen = _user_values()
    if value == "default":
        chosen.pop(key, None)
    else:
        chosen[key] = _validate(key, value)
    if not chosen:
        paths.config_file().unlink(missing_ok=True)
        return
    _write(chosen)


def _write(chosen):
    lines = [HEADER, f"[{SECTION}]\n"]
    for name in DEFAULTS:
        if name in chosen:
            lines.append(f"{name} = {chosen[name]}\n")
    paths.write_atomic(paths.config_file(), "".join(lines))


def _migrate():
    """Move turd-buster.conf to preflight.conf, once. An unreadable old file
    is left where it is."""
    old = paths.old_config_file()
    if paths.config_file().exists() or not old.is_file():
        return
    chosen = _read(old, "user", OLD_SECTION)
    if chosen is None:
        return
    try:
        if chosen:
            _write(chosen)
        old.unlink()
    except OSError as e:
        print(f"preflight: cannot move {old} ({e})", file=sys.stderr)


def _validate(key, value):
    value = str(value).strip()
    if key == "provider":
        if value not in PROVIDERS:
            raise ConfigError("Provider must be opencode or ollama.")
        return value
    if key == "timeout":
        low, high = TIMEOUT_RANGE
        if not value.isdigit() or not low <= int(value) <= high:
            raise ConfigError(f"The time limit must be {low} to {high} seconds.")
        return str(int(value))
    if key == "sign_off":
        if value not in YES_NO:
            raise ConfigError("sign_off must be yes or no.")
        return value
    if not value or any(c in value for c in "\n\r"):
        raise ConfigError("Enter a model name.")
    return value


def _user_values():
    _migrate()
    return _read(paths.config_file(), "user") or {}


def _read(path, label, section_name=SECTION):
    if path is None or not path.is_file():
        return None
    parser = configparser.ConfigParser()
    try:
        parser.read(path, encoding="utf-8")
        section = parser[section_name]
    except (configparser.Error, KeyError, UnicodeError, OSError):
        print(f"preflight: ignoring unreadable {label} settings in {path}", file=sys.stderr)
        return None
    found = {}
    for key in DEFAULTS:
        if key not in section:
            continue
        try:
            found[key] = _validate(key, section[key])
        except ConfigError:
            print(f"preflight: ignoring {key} in {path}", file=sys.stderr)
    return found
