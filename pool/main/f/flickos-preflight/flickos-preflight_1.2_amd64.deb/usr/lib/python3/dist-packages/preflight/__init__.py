"""Preflight (flickos-preflight): check a Reddit draft before you post."""

__version__ = "1.1"
