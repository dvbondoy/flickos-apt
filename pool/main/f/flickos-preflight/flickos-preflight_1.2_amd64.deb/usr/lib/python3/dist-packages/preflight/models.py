"""How a model is called: tgpt for an online provider, Ollama's HTTP API on
this computer.

tgpt is a separate program, the pinned copy this package bundles in
/usr/libexec/flickos/preflight/. It runs with -q and never with its tools or
shell mode, and the input goes on stdin so a long post is not an argument.

Ollama is called directly, not through tgpt, so its reply can be held to a
JSON schema and the draft never leaves this computer.

Both report what they do to on_output("log", text), for the window's Details.
"""

import contextlib
import http.client
import json
import os
import signal
import socket
import subprocess
import threading
import time
import urllib.parse

from preflight import paths

OLLAMA_DEFAULT = "127.0.0.1:11434"  # where `ollama serve` listens unless OLLAMA_HOST says otherwise
QUIET_SECONDS = 2  # a "Waiting" line in Details after this long without output
DETAIL_CAP = 500  # characters of a program's own error kept in a message
# Variables tgpt keeps (tgpt_env): locale, home, and how this computer reaches
# the network. LC_* are kept too.
TGPT_ENV = frozenset({
    "PATH", "HOME", "LANG", "LANGUAGE", "TZ", "TMPDIR",
    "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "all_proxy", "no_proxy",
    "SSL_CERT_FILE", "SSL_CERT_DIR",
})


class CheckError(Exception):
    def __init__(self, message, raw=""):
        super().__init__(message)
        self.raw = raw


def log(on_output, text):
    if on_output and text:
        on_output("log", text)


# --- tgpt -------------------------------------------------------------------


def tgpt_argv(program, provider, preprompt):
    # No -w: tgpt writes the reply as it arrives, so Details can show it working.
    # --config: without it tgpt reads ./config.conf or ~/.config/tgpt/config.conf,
    # a tgpt the user set up for themselves, into its environment.
    return [program, "-q", "--provider", provider, "--preprompt", preprompt, "--config", os.devnull]


def tgpt_env():
    """The environment tgpt runs with: only what reaching the network needs.
    tgpt reads keys, endpoints and models from variables (AI_API_KEY,
    OPENCODE_URL, …) a user may have set for their own tgpt and another
    provider; passed on, they would send the draft or the key elsewhere."""
    return {key: value for key, value in os.environ.items() if key in TGPT_ENV or key.startswith("LC_")}


def tgpt(text, preprompt, provider, timeout, cancel=None, on_output=None):
    program = paths.tgpt()
    if program is None:
        raise CheckError(
            "The online check cannot run because tgpt is missing. "
            "Reinstall flickos-preflight, or choose to check on this computer."
        )
    try:
        proc = subprocess.Popen(
            tgpt_argv(program, provider, preprompt),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=tgpt_env(),
            start_new_session=True,
        )
    except OSError as e:
        raise CheckError(f"The check could not start ({e}). Try again.") from e
    log(on_output, f"Started tgpt (pid {proc.pid}), provider {provider}.\n")
    buckets = {"stdout": [], "stderr": []}
    quiet = {"at": time.monotonic()}
    # Readers drain the pipes while we wait, so a long reply cannot fill them and stall tgpt.
    threads = [
        _reader(proc.stdout, buckets["stdout"], on_output, quiet),
        _reader(proc.stderr, buckets["stderr"], on_output, quiet),
    ]
    try:
        proc.stdin.write(text)
        proc.stdin.close()
    except BrokenPipeError:
        pass
    _watch(lambda: proc.poll() is not None, lambda: _kill(proc), cancel, timeout, on_output, quiet)
    for thread in threads:
        thread.join(timeout=2)
    out = "".join(buckets["stdout"])
    err = "".join(buckets["stderr"])
    log(on_output, f"tgpt exited {proc.returncode}.\n")
    if proc.returncode != 0:
        message = "The online check did not finish."
        detail = _shorten(err or out)
        if detail:
            message = f"{message} {detail}"
        raise CheckError(f"{message} Try again.", raw=out)
    return out


def _reader(pipe, bucket, on_output, quiet):
    def read():
        try:
            while True:
                chunk = pipe.read(64)
                if not chunk:
                    break
                bucket.append(chunk)
                quiet["at"] = time.monotonic()
                log(on_output, chunk)
        finally:
            pipe.close()

    thread = threading.Thread(target=read, daemon=True)
    thread.start()
    return thread


def _kill(proc):
    # The session includes anything tgpt started, so a timeout cannot leave it running.
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        with contextlib.suppress(OSError):
            proc.kill()
    with contextlib.suppress(subprocess.TimeoutExpired):
        proc.wait(timeout=2)


# --- Ollama -----------------------------------------------------------------


def ollama_address():
    """(host, port) from OLLAMA_HOST, as the ollama command reads it."""
    value = os.environ.get("OLLAMA_HOST", "").strip() or OLLAMA_DEFAULT
    if "://" not in value:
        value = f"http://{value}"
    parts = urllib.parse.urlsplit(value)
    try:
        port = parts.port or 11434
    except ValueError:
        port = 11434
    return parts.hostname or "127.0.0.1", port


def ollama(text, preprompt, model, schema, timeout, cancel=None, on_output=None):
    host, port = ollama_address()
    payload = json.dumps({
        "model": model,
        "stream": True,
        "format": schema,
        "options": {"temperature": 0},
        "messages": [
            {"role": "system", "content": preprompt},
            {"role": "user", "content": text},
        ],
    }).encode()
    conn = http.client.HTTPConnection(host, port, timeout=timeout)
    parts = []
    state = {"error": None, "status": 0, "detail": ""}
    quiet = {"at": time.monotonic()}

    def work():
        try:
            conn.request("POST", "/api/chat", body=payload, headers={"Content-Type": "application/json"})
            response = conn.getresponse()
            if response.status != 200:
                state["status"] = response.status
                state["detail"] = _error_text(response.read(4000))
                return
            # One JSON object per line while the model writes.
            for line in response:
                try:
                    item = json.loads(line)
                except ValueError:
                    continue
                if item.get("error"):
                    state["status"], state["detail"] = 500, str(item["error"])
                    return
                chunk = (item.get("message") or {}).get("content") or ""
                if chunk:
                    parts.append(chunk)
                    quiet["at"] = time.monotonic()
                    log(on_output, chunk)
                if item.get("done"):
                    return
        except (OSError, http.client.HTTPException) as e:
            state["error"] = e

    thread = threading.Thread(target=work, daemon=True)
    log(on_output, f"Asking Ollama at {host}:{port}, model {model}.\n")
    thread.start()
    _watch(lambda: not thread.is_alive(), lambda: _hang_up(conn), cancel, timeout, on_output, quiet)
    reply = "".join(parts)
    if state["error"] is not None:
        raise CheckError(_unreachable(state["error"], host, port), raw=reply)
    if state["status"]:
        raise CheckError(_refused(state["status"], state["detail"], model), raw=reply)
    log(on_output, "\nOllama finished.\n")
    return reply


def _hang_up(conn):
    # Closing the connection is how Ollama is told to stop writing.
    sock = conn.sock
    if sock is not None:
        with contextlib.suppress(OSError):
            sock.shutdown(socket.SHUT_RDWR)
    conn.close()


def _error_text(data):
    text = data.decode("utf-8", "replace")
    with contextlib.suppress(ValueError, AttributeError):
        return str(json.loads(text).get("error") or text)
    return text


def _unreachable(error, host, port):
    if isinstance(error, ConnectionRefusedError):
        return "Ollama is not running on this computer. Start it with `ollama serve`, then check again."
    return f"Ollama at {host}:{port} could not be reached ({error}). Check that it is running, then try again."


def _refused(status, detail, model):
    if status == 404 and "not found" in detail.lower():
        return f"The model {model} is not on this computer. Download it with `ollama pull {model}`, or choose another model."
    message = "Ollama did not finish the check."
    detail = _shorten(detail)
    if detail:
        message = f"{message} {detail}"
    return f"{message} Try again."


# --- Waiting ----------------------------------------------------------------


def _watch(done, stop, cancel, limit, on_output, quiet):
    """Wait until done(). On Cancel or past `limit` seconds, stop() the call."""
    started = time.monotonic()
    while not done():
        now = time.monotonic()
        if cancel is not None and cancel.is_set():
            stop()
            log(on_output, "Cancelled.\n")
            raise CheckError("The check was cancelled.")
        if now - started >= limit:
            stop()
            log(on_output, "Stopped: the model took too long.\n")
            raise CheckError(
                f"The model took longer than {limit:g} seconds and was stopped. "
                "Try again, or choose a longer time limit."
            )
        if now - quiet["at"] >= QUIET_SECONDS:
            log(on_output, f"Waiting for the model, {int(now - started)} s.\n")
            quiet["at"] = now
        time.sleep(0.1)


def _shorten(text):
    text = (text or "").strip()
    if len(text) > DETAIL_CAP:
        text = text[:DETAIL_CAP].rstrip() + "…"
    return text
