"""Turn a model's reply into verdicts or a fixed post.

The model is asked for one JSON object. Through tgpt it often wraps that
object in a markdown fence, or adds a sentence around it; Ollama is held to
a schema and returns the object alone. Anything that is not a verdict is
dropped. If nothing usable remains, the check failed: the app never invents
a pass.
"""

import json
import re

STATUSES = ("pass", "warn", "fail")
PARTS = ("title", "body", "both")
_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)


class ParseError(Exception):
    pass


def extract(text):
    """The one JSON object in a reply, or ParseError."""
    raw = (text or "").strip()
    if not raw:
        raise ParseError("The model returned nothing.")
    fenced = _FENCE.search(raw)
    body = fenced.group(1).strip() if fenced else raw
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        pass
    start, end = body.find("{"), body.rfind("}")
    if start >= 0 and end > start:
        try:
            return json.loads(body[start:end + 1])
        except json.JSONDecodeError:
            pass
    raise ParseError("The model did not return JSON.")


def parse(text):
    """Return {"summary", "verdicts"} or raise ParseError."""
    data = extract(text)
    if not isinstance(data, dict) or not isinstance(data.get("summary"), str):
        raise ParseError("The model did not return a check.")
    verdicts = []
    items = data.get("verdicts")
    if isinstance(items, list):
        for item in items:
            verdict = _verdict(item)
            if verdict is not None:
                verdicts.append(verdict)
    if not verdicts:
        raise ParseError("The model did not return a check.")
    return {"summary": data["summary"].strip(), "verdicts": verdicts}


def parse_fix(text):
    """Return {"title", "body"} from a rewrite or raise ParseError."""
    data = extract(text)
    title = data.get("title") if isinstance(data, dict) else None
    post = data.get("body") if isinstance(data, dict) else None
    if not isinstance(title, str) or not title.strip() or not isinstance(post, str):
        raise ParseError("The model did not return a fixed post.")
    return {"title": title.strip(), "body": post.strip()}


def _verdict(item):
    if not isinstance(item, dict):
        return None
    status = item.get("status")
    ident = item.get("id")
    reason = item.get("reason")
    if status not in STATUSES or not isinstance(ident, str) or not ident.strip():
        return None
    if not isinstance(reason, str) or not reason.strip():
        return None
    part = item.get("part")
    part = part.strip().lower() if isinstance(part, str) else ""
    if part not in PARTS:
        part = ""
    return {"id": ident.strip().upper(), "status": status, "reason": reason.strip(), "part": part}
