"""Preflight's window, opened from the apps menu.

GTK is imported only here, and only after the single-instance lock is held
(HIG WIN-2). The window paints with whatever GTK theme the session set
(Arc-Dark or Arc). It does not choose a theme, a font, or a color (VIS-2).

The draft is on the left and the result on the right, so the verdicts and
the fixed post are in view next to what they judge. The settings are rows at
the bottom of the draft side and apply at once (WIN-8). Editing the draft
after a check clears the result, so Copy and Post never act on a verdict
about older text.
"""

import fcntl
import subprocess
import sys
import threading
import traceback

from preflight import config, paths

TITLE = "Preflight"  # the desktop file's Name (HIG WIN-4)
APP_ID = "flickos-preflight"  # the desktop file's name, so the taskbar matches it
ICON = "text-x-generic"  # the desktop file's Icon
SIZE = (1100, 660)  # HIG WIN-3: at most 1280×680; two sides of about 550
LOCK = "preflight.lock"  # in $XDG_RUNTIME_DIR/flickos (HIG CODE-8)
COPY_SECONDS = 5  # wl-copy normally returns at once

# Symbolic icons take the text color in both Arc-Dark and Arc. The word goes
# next to the icon, so its shape is never the only signal (HIG A11Y-6).
STATUSES = {
    "pass": ("emblem-ok-symbolic", "Passes"),
    "warn": ("dialog-warning-symbolic", "Unsure"),
    "fail": ("dialog-error-symbolic", "Breaks it"),
    "unchecked": ("dialog-question-symbolic", "Not checked"),
}
# Which part of the draft a verdict is about, shown under a fail or warn.
PARTS = {"title": "Title", "body": "Body", "both": "Title and body"}
# Where the check runs: (config value, choice, the row's subtitle while chosen).
PROVIDERS = (
    ("ollama", "On this computer", "Ollama runs the model here. The draft stays on this computer."),
    ("opencode", "Online", "The draft is sent to OpenCode."),
)
# How long one model call may take, in config.py's seconds (HIG WIN-7: named values).
TIME_LIMITS = (("60", "1 minute"), ("120", "2 minutes"), ("300", "5 minutes"), ("600", "10 minutes"))
# What the spinner says, from checker.check's "phase" output.
PHASES = {
    "check": "Checking the draft…",
    "fix": "Writing a fixed post…",
    "recheck": "Checking the fixed post…",
}
REMOTE = "Check sends this draft to OpenCode, online. To keep it on this computer, choose On this computer under Settings."
RULES_HINT = ("Paste the community's rules, including rules about the title. "
              "A blank line starts a new rule. Anything you leave out is not checked.")
MODEL_HINT = "A model you have downloaded in Ollama, such as llama3.2."
SIGN_HINT = "Ends a post that passes with “Checked by Preflight using …”. It is checked with the post."
FIXED_HINT = "It passes every rule. Copy and Post use it, not the draft."
# A rewrite that still breaks a rule: one string for one rule, one for several (HIG TXT-8).
SUGGESTED_ONE = "It still breaks {rules}. Edit it, or press Use as Draft and check it again."
SUGGESTED_MANY = "It still breaks these rules: {rules}. Edit it, or press Use as Draft and check it again."
USED = "The suggestion is now the draft. Edit it if you like, then check it again."
SEND_HINT = "Post opens Reddit's submit page in your browser. Nothing is posted until you submit it there."
EMPTY = "No check yet. Fill in the draft and the rules, then press Check."
CHANGED = "The draft changed since the check. Check it again."
SIGN_CHANGED = "The checked-by line was turned on or off since the check. Check it again."
STOPPED = "The check did not finish."


def remote_notice(provider):
    """The privacy line, or None when the draft stays on this machine."""
    return None if provider == "ollama" else REMOTE


def take_lock():
    """The open lock file, or None while another Preflight window holds it."""
    folder = paths.ensure_private_dir(paths.runtime_dir())
    handle = open(folder / LOCK, "a")
    try:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        handle.close()
        return None
    return handle


def run():
    try:
        lock = take_lock()
    except paths.PathError as e:
        print(f"preflight: {e}", file=sys.stderr)
        return 1
    if lock is None:
        print(f"{TITLE} is already open.")
        return 0
    try:
        import gi

        gi.require_version("Gtk", "3.0")
        from gi.repository import GLib

        GLib.set_prgname(APP_ID)
        from gi.repository import Gtk
    except (ImportError, ValueError) as e:
        print(f"preflight: GTK 3 is not available ({e})", file=sys.stderr)
        return 1
    if not Gtk.init_check(sys.argv[:1])[0]:
        print("preflight: cannot open a window (no display)", file=sys.stderr)
        return 1
    Window(Gtk, GLib)
    Gtk.main()
    lock.close()
    return 0


class Window:
    def __init__(self, Gtk, GLib):
        self.Gtk = Gtk
        self.GLib = GLib
        self.generation = 0     # the newest check; output from older ones is dropped
        self.cancel = None      # threading.Event of the running check
        self.checking = False
        self.state = None       # what Copy and Post send: submit.STATES
        self.sign_off = ""      # the line a passed check was checked with
        self.settings = config.load()
        # Text fields in rows start at one edge, whatever their label's length.
        self.field_labels = Gtk.SizeGroup(mode=Gtk.SizeGroupMode.HORIZONTAL)

        window = self.window = Gtk.Window(title=TITLE)
        window.set_default_size(*SIZE)
        window.set_icon_name(ICON)
        window.connect("destroy", self._close)
        accel = Gtk.AccelGroup()
        accel.connect(*Gtk.accelerator_parse("<Control>w"), 0, lambda *_a: window.close() or True)
        accel.connect(*Gtk.accelerator_parse("<Control>Return"), 0, lambda *_a: self._start() or True)
        window.add_accel_group(accel)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.remote = self._bar(Gtk.MessageType.WARNING)
        self.remote.text.set_text(REMOTE)
        self.error = self._bar(Gtk.MessageType.ERROR)
        self.raw_expander = Gtk.Expander(label="Model reply", no_show_all=True)
        self.raw_label = self._label("", selectable=True)
        self.raw_expander.add(self.raw_label)
        self.raw_label.show()
        self.error.get_content_area().add(self.raw_expander)
        outer.pack_start(self.remote, False, False, 0)
        outer.pack_start(self.error, False, False, 0)

        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, wide_handle=True)
        paned.pack1(self._draft_side(), True, False)
        paned.pack2(self._result_side(), True, False)
        paned.set_position(SIZE[0] // 2)
        outer.pack_start(paned, True, True, 0)
        window.add(outer)
        window.show_all()
        self._apply_provider()
        self._show_rows(None, EMPTY)

    def _close(self, *_args):
        if self.cancel is not None:
            self.cancel.set()
        self.Gtk.main_quit()

    # --- The draft side -----------------------------------------------------

    def _draft_side(self):
        Gtk = self.Gtk
        scrolled, page = self._page()

        self.subreddit = Gtk.Entry(placeholder_text="python", activates_default=False)
        self.title = Gtk.Entry()
        page.add(self._group("Draft", self._framed_list(
            self._row("Co_mmunity", self.subreddit, expand=True),
            self._row("_Title", self.title, expand=True),
        )))
        self.body = self._text_view()
        page.add(self._group("_Body", self._framed(self.body), mnemonic=self.body))
        self.rules = self._text_view()
        page.add(self._group("_Rules", self._label(RULES_HINT, dim=True), self._framed(self.rules),
                             mnemonic=self.rules))

        buttons = Gtk.Box(spacing=12)
        self.check = Gtk.Button.new_with_mnemonic("_Check")
        self.check.get_style_context().add_class("suggested-action")
        self.check.set_tooltip_text("Ctrl+Enter")
        self.check.connect("clicked", lambda *_a: self._start())
        buttons.pack_start(self.check, False, False, 0)
        self.cancel_button = Gtk.Button.new_with_mnemonic("C_ancel")
        self.cancel_button.set_no_show_all(True)
        self.cancel_button.connect("clicked", lambda *_a: self.cancel.set() if self.cancel else None)
        buttons.pack_start(self.cancel_button, False, False, 0)
        page.add(buttons)

        self.provider = Gtk.ComboBoxText()
        for value, name, _subtitle in PROVIDERS:
            self.provider.append(value, name)
        self.provider.set_active_id(self.settings["provider"])
        self.provider_row = self._row("_Where to check", self.provider)
        self.model = Gtk.Entry(text=self.settings["model"], width_chars=16)
        self.model_row = self._row("Mo_del", self.model, subtitle=MODEL_HINT)
        self.limit = Gtk.ComboBoxText()
        limits = list(TIME_LIMITS)
        if self.settings["timeout"] not in dict(limits):
            limits.append((self.settings["timeout"], f"{self.settings['timeout']} seconds"))
        for value, name in limits:
            self.limit.append(value, name)
        self.limit.set_active_id(self.settings["timeout"])
        self.sign = Gtk.Switch(active=self.settings["sign_off"] == "yes")
        page.add(self._group("Settings", self._framed_list(
            self.provider_row,
            self.model_row,
            self._row("Time _limit", self.limit, subtitle="How long the model may take to answer."),
            self._row("Add a c_hecked-by line", self.sign, subtitle=SIGN_HINT),
        )))

        for entry in (self.subreddit, self.title):
            entry.connect("changed", self._draft_changed)
        for view in (self.body, self.rules):
            view.get_buffer().connect("changed", self._draft_changed)
        self.provider.connect("changed", self._provider_changed)
        self.model.connect("activate", self._model_changed)
        self.model.connect("focus-out-event", lambda *_a: self._model_changed() or False)
        self.limit.connect("changed", self._limit_changed)
        self.sign.connect("notify::active", self._sign_changed)
        return scrolled

    # --- The result side ----------------------------------------------------

    def _result_side(self):
        Gtk = self.Gtk
        scrolled, page = self._page()

        self.working = Gtk.Box(spacing=12, no_show_all=True)
        self.spinner = Gtk.Spinner()
        self.phase = self._label("")
        self.working.pack_start(self.spinner, False, False, 0)
        self.working.pack_start(self.phase, False, False, 0)
        self.spinner.show()
        self.phase.show()
        self.summary = self._label("", selectable=True)
        self.summary.set_no_show_all(True)
        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        self.list.set_header_func(lambda row, before: row.set_header(Gtk.Separator() if before else None))
        self.verdicts = Gtk.Frame()
        self.verdicts.add(self.list)
        page.add(self._group("Verdicts", self.working, self.summary, self.verdicts))

        self.fixed_title = Gtk.Entry()
        self.fixed_body = self._text_view()
        body_label = self._label("B_ody")
        body_label.set_use_underline(True)
        body_label.set_mnemonic_widget(self.fixed_body)
        self.fixed_hint = self._label(FIXED_HINT, dim=True)
        use = Gtk.Button.new_with_mnemonic("_Use as Draft")
        use.set_tooltip_text("Puts this title and body in the draft, to edit and check again")
        use.set_halign(Gtk.Align.START)
        use.connect("clicked", lambda *_a: self._use_fix())
        self.fixed_box = self._group(
            "Fixed post",
            self.fixed_hint,
            self._framed_list(self._row("T_itle", self.fixed_title, expand=True)),
            body_label,
            self._framed(self.fixed_body, height=160),
            use,
        )
        self.fixed_box.set_no_show_all(True)
        page.add(self.fixed_box)

        buttons = Gtk.Box(spacing=12)
        self.post = Gtk.Button.new_with_mnemonic("_Post…")
        self.post.connect("clicked", lambda *_a: self._post())
        buttons.pack_start(self.post, False, False, 0)
        self.copy_button = Gtk.Button.new_with_mnemonic("Cop_y Post")
        self.copy_button.set_tooltip_text("Copies the post's text, to paste on Reddit")
        self.copy_button.connect("clicked", lambda *_a: self._copy())
        buttons.pack_start(self.copy_button, False, False, 0)
        self.send_status = self._label("", dim=True, selectable=True)
        page.add(self._group("Send", self._label(SEND_HINT, dim=True), buttons, self.send_status))

        self.details = Gtk.Expander(label="D_etails", use_underline=True)
        self.log = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.WORD_CHAR,
                                monospace=True, accepts_tab=False)
        self.log.set_border_width(6)
        self.details.add(self._framed(self.log, height=140))
        page.add(self.details)
        return scrolled

    # --- Settings -----------------------------------------------------------

    def _store(self, key, value):
        try:
            config.set_value(key, value)
        except config.ConfigError as e:
            self._show_error(str(e))
            return False
        self.settings = config.load()
        return True

    def _provider_changed(self, combo):
        chosen = combo.get_active_id()
        if chosen and chosen != self.settings["provider"]:
            self._store("provider", chosen)
        self._apply_provider()

    def _model_changed(self, *_args):
        chosen = self.model.get_text().strip()
        if chosen != self.settings["model"]:
            self._store("model", chosen)

    def _limit_changed(self, combo):
        chosen = combo.get_active_id()
        if chosen and chosen != self.settings["timeout"]:
            self._store("timeout", chosen)

    def _sign_changed(self, switch, _param):
        if self._store("sign_off", "yes" if switch.get_active() else "no") and self.state is not None:
            # A passed check was made with or without the line; that no longer holds.
            self._clear_result(SIGN_CHANGED)

    def _apply_provider(self):
        provider = self.settings["provider"]
        self.remote.set_visible(remote_notice(provider) is not None)
        self.model_row.set_visible(provider == "ollama")
        subtitles = {value: subtitle for value, _name, subtitle in PROVIDERS}
        self.provider_row.subtitle.set_text(subtitles.get(provider, ""))
        self.provider_row.subtitle.show()

    # --- Checking -----------------------------------------------------------

    def _draft_changed(self, *_args):
        if self.state is not None:
            self._clear_result(CHANGED)

    def _start(self):
        if self.checking:
            return
        title = self.title.get_text()
        rules = self._text(self.rules)
        if not title.strip():
            self._show_error("Enter a title.")
            self.title.grab_focus()
            return
        if not rules.strip():
            self._show_error("Paste the community's rules.")
            self.rules.grab_focus()
            return
        self.generation += 1
        self.cancel = threading.Event()
        self._clear_result(EMPTY)
        self._busy(True)
        args = (self.generation, self.cancel, self.subreddit.get_text(), title, self._text(self.body), rules)
        threading.Thread(target=self._work, args=args, daemon=True).start()

    def _work(self, generation, cancel, name, title, body, rules):
        from preflight.checker import CheckError, check

        def on_output(kind, text):
            self.GLib.idle_add(self._output, generation, kind, text)

        try:
            result = check(name, title, body, rules, cancel=cancel, on_output=on_output)
        except CheckError as e:
            self.GLib.idle_add(self._finish, generation, None, str(e), e.raw)
            return
        except Exception as e:  # a bug: say so instead of spinning forever (HIG CODE-6)
            traceback.print_exc()
            self.GLib.idle_add(self._finish, generation, None, f"{type(e).__name__}: {e}", "")
            return
        self.GLib.idle_add(self._finish, generation, result, "", "")

    def _busy(self, on):
        self.checking = on
        for widget in (self.subreddit, self.title, self.body, self.rules, self.check, self.post, self.copy_button):
            widget.set_sensitive(not on)
        self.cancel_button.set_visible(on)
        self.working.set_visible(on)
        self.verdicts.set_visible(not on)
        if on:
            self.error.hide()
            self.spinner.start()
            self.phase.set_text(PHASES["check"])
            self.log.get_buffer().set_text("")
            self.send_status.set_text("")
        else:
            self.spinner.stop()

    def _output(self, generation, kind, text):
        if generation != self.generation:
            return False
        if kind == "phase":
            self.phase.set_text(PHASES.get(text, PHASES["check"]))
            return False
        buf = self.log.get_buffer()
        buf.insert(buf.get_end_iter(), text)
        buf.place_cursor(buf.get_end_iter())
        self.log.scroll_mark_onscreen(buf.get_insert())
        return False

    def _finish(self, generation, result, error, raw):
        if generation != self.generation:
            return False
        from preflight.checker import failed

        self._busy(False)
        if error:
            self._show_rows(None, STOPPED)
            self._show_error(error, raw)
            return False
        rows = result["rows"]
        lines = [f"r/{result['community']['name']}: {result['summary']}"]
        if result["community"]["truncated"]:
            lines.append("Some rule text was too long and was shortened.")
        if not failed(rows):
            self.state = "passed"
            self.sign_off = result["sign_off"]
            if self.sign_off:
                lines.append("Copy and Post add the checked-by line.")
        elif result["fixed"]:
            fixed = result["fixed"]
            self.fixed_title.set_text(fixed["title"])
            self.fixed_body.get_buffer().set_text(fixed["body"])
            if fixed["passed"]:
                self.state = "fixed"
                self._set_heading(self.fixed_box, "Fixed post")
                self.fixed_hint.set_text(FIXED_HINT)
                lines.append("A fixed post that passes is below.")
            else:
                self.state = "suggested"
                names = [rule["title"] for rule in fixed["still_breaks"]]
                hint = SUGGESTED_ONE if len(names) == 1 else SUGGESTED_MANY
                self._set_heading(self.fixed_box, "Suggested fix")
                self.fixed_hint.set_text(hint.format(rules=", ".join(names)))
                lines.append("No rewrite passed every rule. The closest one is below as a suggested fix.")
            self.fixed_box.set_no_show_all(False)
            self.fixed_box.show_all()
        else:
            self.state = "failed"
            self._show_error(result["fix_error"] or "This draft breaks a rule, and no fixed post passed.")
        self._show_rows(rows)
        self.summary.set_text("\n".join(lines))
        self.summary.show()
        return False

    def _use_fix(self):
        """Put the fixed post in the draft, to edit and check again."""
        from preflight.checker import strip_sign_off

        title = self.fixed_title.get_text()
        body = strip_sign_off(self._text(self.fixed_body))
        self.title.set_text(title)
        self.body.get_buffer().set_text(body)
        self._clear_result(USED)
        self.body.grab_focus()

    def _clear_result(self, empty_text):
        self.state = None
        self.sign_off = ""
        self.fixed_box.hide()
        self.fixed_box.set_no_show_all(True)
        self.summary.set_text("")
        self.summary.hide()
        self.send_status.set_text("")
        self._show_rows(None, empty_text)

    # --- Copy and Post ------------------------------------------------------

    def _chosen(self):
        from preflight.submit import draft_to_send

        return draft_to_send(
            self.state, self.title.get_text(), self._text(self.body),
            self.fixed_title.get_text(), self._text(self.fixed_body), self.sign_off,
        )

    def _copy(self):
        from preflight.submit import SubmitError

        try:
            _title, body = self._chosen()
        except SubmitError as e:
            self._show_error(str(e))
            return
        self._copy_text(body, "Copied the post.")

    def _post(self):
        from preflight.submit import SubmitError, open_submit

        try:
            title, body = self._chosen()
            left_out = open_submit(self.subreddit.get_text(), title, body)
        except SubmitError as e:
            self._show_error(str(e))
            return
        self.error.hide()
        if left_out and body.strip():
            self._copy_text(body, "Opened the submit page. The post was too long for the link, so it is copied. Paste it there.")
            return
        self.send_status.set_text("Opened the submit page. Nothing is posted until you submit it there.")

    def _copy_text(self, text, message):
        """wl-copy keeps the text after this window closes and needs no input
        event; GTK's clipboard fails silently on Wayland without one (HIG CODE-10),
        so it is only the fallback."""
        def work():
            try:
                subprocess.run(["wl-copy"], input=text, text=True, timeout=COPY_SECONDS, check=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                ok = True
            except (OSError, subprocess.SubprocessError):
                ok = False
            self.GLib.idle_add(done, ok)

        def done(ok):
            if not ok:
                from gi.repository import Gdk

                clipboard = self.Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
                clipboard.set_text(text, -1)
                clipboard.store()
            self.send_status.set_text(message)
            return False

        threading.Thread(target=work, daemon=True).start()

    # --- Pieces -------------------------------------------------------------

    def _text(self, view):
        buf = view.get_buffer()
        return buf.get_text(buf.get_start_iter(), buf.get_end_iter(), True)

    def _show_error(self, message, raw=""):
        self.error.text.set_text(message)
        self.raw_label.set_text(raw.strip())
        self.raw_expander.set_visible(bool(raw.strip()))
        self.error.show()

    def _show_rows(self, rows, empty_text=EMPTY):
        for child in self.list.get_children():
            self.list.remove(child)
        if not rows:
            row = self.Gtk.ListBoxRow(activatable=False)
            row.add(self._label(empty_text, dim=True, margin=10))
            self.list.add(row)
        else:
            for row in rows:
                self.list.add(self._verdict_row(row))
        self.list.show_all()

    def _verdict_row(self, row):
        Gtk = self.Gtk
        icon_name, word = STATUSES.get(row["status"], STATUSES["unchecked"])
        line = Gtk.Box(spacing=12)
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
        icon.set_valign(Gtk.Align.START)
        icon.get_accessible().set_name(word)
        line.pack_start(icon, False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(row["title"]), False, False, 0)
        text.pack_start(self._label(row["reason"], dim=True, selectable=True), False, False, 0)
        line.pack_start(text, True, True, 0)
        verdict = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.START)
        verdict.pack_start(self._label(word, wrap=False, xalign=1), False, False, 0)
        if row["status"] in ("fail", "warn") and row["part"] in PARTS:
            verdict.pack_start(self._label(PARTS[row["part"]], dim=True, wrap=False, xalign=1), False, False, 0)
        line.pack_end(verdict, False, False, 0)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin=10)
        box.pack_start(line, False, False, 0)
        if row["text"].strip() != row["title"]:
            expander = Gtk.Expander(label="Rule text")
            expander.add(self._label(row["text"], dim=True, selectable=True))
            box.pack_start(expander, False, False, 0)
        outer = Gtk.ListBoxRow(activatable=False)
        outer.add(box)
        return outer

    def _page(self):
        """A scrolled side; returns (scrolled window, content box)."""
        Gtk = self.Gtk
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18, margin=24)
        scrolled = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        scrolled.add(page)
        return scrolled, page

    def _group(self, heading, *widgets, mnemonic=None):
        """A heading and what it is about, 12 apart (HIG WIN-5)."""
        box = self.Gtk.Box(orientation=self.Gtk.Orientation.VERTICAL, spacing=12)
        label = self._label("", wrap=False)
        markup = f"<b>{self.GLib.markup_escape_text(heading)}</b>"
        if mnemonic is not None:
            label.set_markup_with_mnemonic(markup)
            label.set_mnemonic_widget(mnemonic)
        else:
            label.set_markup(markup)
        box.pack_start(label, False, False, 0)
        box.heading = label
        for widget in widgets:
            box.pack_start(widget, False, False, 0)
        return box

    def _set_heading(self, group, heading):
        group.heading.set_markup(f"<b>{self.GLib.markup_escape_text(heading)}</b>")

    def _framed_list(self, *rows):
        listing = self.Gtk.ListBox(selection_mode=self.Gtk.SelectionMode.NONE)
        listing.set_header_func(lambda row, before: row.set_header(self.Gtk.Separator() if before else None))
        for row in rows:
            listing.add(row)
        frame = self.Gtk.Frame()
        frame.add(listing)
        return frame

    def _row(self, title, control, subtitle=None, expand=False):
        """A settings row (HIG WIN-6): title and dimmed subtitle on the left,
        the control on the right. expand: a text field that takes the width."""
        Gtk = self.Gtk
        line = Gtk.Box(spacing=12, margin=10)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.CENTER)
        name = self._label(title, wrap=False)
        name.set_use_underline(True)
        name.set_mnemonic_widget(control)
        text.pack_start(name, False, False, 0)
        second = self._label(subtitle or "", dim=True)
        second.set_no_show_all(not subtitle)
        text.pack_start(second, False, False, 0)
        line.pack_start(text, not expand, True, 0)
        if expand:
            self.field_labels.add_widget(text)
        control.set_valign(Gtk.Align.CENTER)
        line.pack_end(control, expand, True, 0)
        # Screen readers name the control after its row (HIG A11Y-8).
        control.get_accessible().set_name(title.replace("_", ""))
        row = Gtk.ListBoxRow(activatable=False)
        row.add(line)
        row.subtitle = second
        return row

    def _text_view(self):
        # accepts_tab off: Tab moves on to the next control (HIG A11Y-1).
        view = self.Gtk.TextView(wrap_mode=self.Gtk.WrapMode.WORD_CHAR, accepts_tab=False)
        view.set_border_width(6)
        return view

    def _framed(self, view, height=120):
        scroll = self.Gtk.ScrolledWindow(hscrollbar_policy=self.Gtk.PolicyType.NEVER, min_content_height=height)
        scroll.add(view)
        # A frame, not a custom color, so the field stays visible in Arc-Dark and Arc.
        frame = self.Gtk.Frame()
        frame.add(scroll)
        return frame

    def _label(self, text, dim=False, selectable=False, wrap=True, xalign=0, margin=0):
        label = self.Gtk.Label(label=text, xalign=xalign, wrap=wrap, selectable=selectable, margin=margin)
        if wrap:
            label.set_max_width_chars(60)
        if dim:
            label.get_style_context().add_class("dim-label")
        return label

    def _bar(self, kind):
        """An info bar, hidden until shown; its label is selectable (HIG WIN-10)."""
        bar = self.Gtk.InfoBar(message_type=kind, show_close_button=False, no_show_all=True)
        text = self._label("", selectable=True)
        text.set_max_width_chars(100)
        bar.get_content_area().add(text)
        text.show()
        bar.text = text
        return bar
