"""Open Reddit's submit page. The app never posts by itself.

Check does not call this. Post does, and only when you press it. The draft
is placed in the browser address; Reddit posts it only after you submit there.
"""

import re
import shutil
import subprocess
import urllib.parse

from preflight.checker import with_sign_off

# Community names Reddit accepts.
SUB_RE = re.compile(r"^[A-Za-z0-9_]{2,21}$")
# Browsers drop very long addresses. Past that, the page opens with the title
# and the window copies the body so you can paste it.
MAX_URL = 6000
# What the window knows about the draft on screen (draft_to_send's `state`):
# None: not checked, or changed since. passed: no rule failed. fixed: a rule
# failed and a fixed post passed. suggested: a rule failed, and the rewrite
# still breaks one. failed: a rule failed and there is no rewrite.
STATES = (None, "passed", "fixed", "suggested", "failed")


class SubmitError(Exception):
    pass


def normalize(name):
    name = (name or "").strip()
    if name.lower().startswith("r/"):
        name = name[2:]
    if not SUB_RE.fullmatch(name):
        raise SubmitError("Enter a community name, such as python.")
    return name.lower()


def draft_to_send(state, title, body, fixed_title=None, fixed_body=None, sign_off=""):
    """The title and body Copy and Post use.

    A draft that failed is never sent: the fixed post is, or nothing. The
    sign-off line goes only on a draft that passed, as it was checked.
    """
    if state == "fixed":
        if fixed_title is None or not fixed_title.strip():
            raise SubmitError("Enter a title for the fixed post.")
        return fixed_title.strip(), fixed_body or ""
    if state == "suggested":
        raise SubmitError("The suggested fix still breaks a rule. Press Use as Draft, edit it, and check it again.")
    if state == "failed":
        raise SubmitError("This draft breaks a rule, and there is no fixed post. Edit the draft and check it again.")
    if state == "passed":
        return title.strip(), with_sign_off(body, sign_off)
    return title.strip(), body


def submit_target(name, title, body):
    """Return (url, body_left_out). body_left_out is true when the body did not fit."""
    title = (title or "").strip()
    if not title:
        raise SubmitError("Enter a title.")
    community = normalize(name)
    body = body or ""
    full = _url(community, title, body)
    if len(full) <= MAX_URL:
        return full, False
    return _url(community, title, ""), True


def open_submit(name, title, body):
    """Open the submit page. Return whether the body was left out of the address."""
    url, left_out = submit_target(name, title, body)
    if shutil.which("xdg-open") is None:
        raise SubmitError("The browser could not be opened (xdg-open is missing).")
    try:
        subprocess.Popen(
            ["xdg-open", url],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as e:
        raise SubmitError(f"Could not open the browser ({e}).") from e
    return left_out


def _url(community, title, body):
    query = urllib.parse.urlencode({"title": title, "text": body, "type": "TEXT"})
    return f"https://www.reddit.com/r/{community}/submit?{query}"
